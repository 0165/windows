
// WP_hw06Dlg.h : ���Y��
//

#pragma once


// CWP_hw06Dlg ��ܤ��
class CWP_hw06Dlg : public CDialogEx
{
// �غc
public:
	CWP_hw06Dlg(CWnd* pParent = NULL);	// �зǫغc�禡

// ��ܤ�����
	enum { IDD = IDD_WP_HW06_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV �䴩


// �{���X��@
protected:
	HICON m_hIcon;

	// ���ͪ��T�������禡
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnEnChangeEditAns();
	// store ans
	CString text;
	afx_msg void OnBnClickedButton0();
	afx_msg void OnBnClickedButtonRit();
	afx_msg void OnBnClickedButtonLef();
	afx_msg void OnBnClickedButtonOne();
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButton3();
	afx_msg void OnBnClickedButtonDot();
	afx_msg void OnBnClickedButtonInc();
	afx_msg void OnBnClickedButtonDec();
	afx_msg void OnBnClickedButtonMul();
	afx_msg void OnBnClickedButton6();
	afx_msg void OnBnClickedButton5();
	afx_msg void OnBnClickedButton4();
	afx_msg void OnBnClickedButtonNat();
	afx_msg void OnBnClickedButtonN();
	afx_msg void OnBnClickedButton7();
	afx_msg void OnBnClickedButton8();
	afx_msg void OnBnClickedButton9();
	afx_msg void OnBnClickedButtonDul();
	afx_msg void OnBnClickedButtonExp();
	afx_msg void OnBnClickedButtonPer();
	afx_msg void OnBnClickedButtonE();
	afx_msg void OnBnClickedButtonDel();
	afx_msg void OnBnClickedButtonClr();
	afx_msg void OnBnClickedButtonCom();
	afx_msg void OnBnClickedButtonLog();
	afx_msg void OnBnClickedButtonLog10();
	afx_msg void OnBnClickedButtonSqr();
	afx_msg void OnBnClickedButtonPow();
	afx_msg void OnBnClickedButtonEqu();
	afx_msg void Ongg();
	afx_msg void Onlu();
};
