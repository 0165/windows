/***************************
4103056005�L�����Ĥ@���@�~10/5
***************************/
#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
//===============================================================================
#define num 200
using namespace std;
//===============================================================================
void mode1();
void mode2();
void mode3();
void insys();						//����Jhotel�b�t�ή�
void ninsys();						//����Jhotel���b�t�ή�
void listInfor();					//�C�Xhotel��T
void modify(string,string,int,int);	//hotel��T�ק�(�W�r�P�K�X���i�ק�)
void Rmodify(int ,int ,int );		//�ק��`�ж���(room.txt��)
int getHid(int);					//���ohotel��id
void writeR(int ,int* );			//���o�ݼg�J�t�Τ��ж�����T
void listAllRoom(int);				//�C�X�Ҧ��i�����ж�(�H�֥i���H�h��)
void listBookR(string,bool*);		//�C�X�ӫȤH�ҭq���ж�
void cancel(string);				//�����q��
//===============================================================================
fstream myroom,myhotel,mydate,myguest;
char* p;
char temp[num];
//===============================================================================
int _tmain(int argc, _TCHAR* argv[])
{
	int a;	cout << "\n\trid is room's id\n\n";
	while (true){
start:
		cout << "input a number of mode\n\t1 for hotel infor\n\t2 for booking\n\t3 for check\n\t4 to exit\t";
		cin >> a;
		if (cin.fail()) a = 10;
		switch (a){
		case 1:	mode1(); break;
		case 2:	mode2(); break;
		case 3:	mode3(); break;
		case 4:	goto end;
		default: cout << "you have an error input\n"; cin.clear();cin.ignore(999,'\n');	goto start;
		}
		cout << "\n";
	}
end:
	return 0;
}
//===============================================================================
void mode1(){
	char a=' ';
again:
	cout << "have your hotel in this system? (Y/n)"; cin >> a;
	switch(a){
		case 'Y': case 'y':	insys();	break;
		case 'N': case 'n':	ninsys();	break;
		default : cout << "you have an error input\n";	goto again;
	}
}
//===============================================================================
void mode2(){
	myguest.open("./sourse/guest.txt",ios::out|ios::app);
	int a;	char tinput[20];
	cout << "whats your name? "; cin >> temp;
	cout << "which day do you want to book? (ex 1/1) "; cin >> tinput;
	myguest << tinput << "\t";
	cout << "how many people do you have? "; cin >> a;	myguest << a << "\t";
	listAllRoom(a);
	myguest.close();
}
//===============================================================================
void mode3(){
	bool non = true;
	string name;
	cout <<"what's your name? "; cin>>name;
	listBookR(name,&non);
	if (non){
		char a;
again:
		cout << "do you want to booking? (Y/n) ";
		cin >> a;
		switch (a){
			case 'Y': case 'y':	mode2();	break;
			case 'N': case 'n':	break;
			default: cout << "you have an error input\n";	goto again;
		}
	}
}
//===============================================================================
void insys(){
	int count=0;
	string name = "",password="";
	char a=' ';
	cout << "please input your hotel name:"; cin >> name;
	myhotel.open("./sourse/hotel_descrip/"+name+".txt");
	if(!myhotel){
		cout << "your hotel isn't in system\n";
		ninsys(); return void();
	}
	myhotel.getline(temp, num);	myhotel.getline(temp, num); myhotel.getline(temp, num);
	p=strtok(temp,"\t");	p=strtok(NULL,"\t");
tryAgain:
	cout << "please input your password:"; cin >> password;
	if(count==3){ cout << "you try too many times\n";	return void();}
	if(p==password)	listInfor();
	else{ cout << "wrong password\n";count++; goto tryAgain;}
again:	
	cout << "do you want to modify your infor? (Y/n):";
	cin >> a;
	switch(a){
		case 'Y': case 'y':	modify(name,password,getHid(1),1);	break;
		case 'N': case 'n':	myhotel.close(); break;
		default : cout << "you have an error input\n";	goto again;
	}
}
//===============================================================================
void ninsys(){
	int count = 0;
	string name = "";
	char password[9] = "";
	char a = ' ';
	cout << "please input your hotel name:"; cin >> name;
	myhotel.open("./sourse/hotel_descrip/" + name + ".txt");
	if (myhotel){
		cout << "your hotel is in system\n";
		myhotel.close();
		insys(); return void();
	}
	cout << "please input your password:"; cin >> password;
	modify(name, password,getHid(2),2);
}
//===============================================================================
void listInfor(){
	cout << "\nthis is your hotel infor:\n";
	myhotel.clear();	myhotel.seekg(0, ios::beg);
	while(myhotel.getline(temp,num))
		cout << temp << "\n";
}
//===============================================================================
void modify(string name,string password,int hid,int a){
	int k=0;
	char tempuse[num]=" ";
	string myinfor;
	fstream hotelHid;	hotelHid.open("./sourse/hotel.txt",ios::out|ios::app);
	myhotel.open("./sourse/hotel_descrip/"+name+".txt",ios::out);
	myhotel << hid << "\n";	hotelHid<<hid<<"\t"<<name<<"\n";hotelHid.close();
	myhotel << "����:\t" << name<<"\n";
	myhotel << "�K�X:\t" << password<<"\n";
	cout << "please input city:";
	cin >> tempuse;		myhotel << "city:\t" << tempuse<<"\n";
	cout << "please input country:";
	cin >> tempuse;		myhotel << "country:" << tempuse<<"\n";
	cout << "please input address:";
	cin >> tempuse;		myhotel << "address:" << tempuse << "\n";
	cout << "please input number of room's type:";
	cin >> k;	myhotel << "rooms:\t";	Rmodify(hid,a,k);	myhotel<<"\n";
	cout << "please input infor:";
	cin.ignore();
	getline(cin, myinfor);		myhotel << "infor:\n\t" << myinfor;
	myhotel.close();
}
//===============================================================================
int getHid(int a){
	int hid=0;
	switch (a){
		case 1:
			myhotel.clear();	myhotel.seekg(0, ios::beg);
			myhotel.getline(temp, num); hid = atoi(temp);	myhotel.close(); break;
		case 2:
			fstream tt; tt.open("./sourse/hotel_descrip/nextID.txt", ios::in);
			tt.getline(temp, num); hid = atoi(temp); tt.close();
			tt.open("./sourse/hotel_descrip/nextID.txt", ios::out); tt << hid + 1;
			tt.close(); break;
	}
	return hid;
}
//===============================================================================
void Rmodify(int hid,int a,int cc){
	int rid=0;
	bool lulu = true;
	if(a==2){
		myroom.open("./sourse/room.txt", ios::out|ios::app);
		for(cc=cc;cc>0;cc--)	writeR(hid,&rid);
		myroom.close();
	}
	else{
		mydate.open("./sourse/room.txt", ios::in);	mydate.getline(temp, num);
		myroom.open("./sourse/room1.txt", ios::out); myroom << "hid\trid\t�`��\t�H��\t���B\t�Ы�\n";
		while(!mydate.eof()){
			mydate.getline(temp,num);
			string ttt(temp);
			p=strtok(temp,"\t");
			if (p == NULL)break;
			if (hid == atoi(p) && lulu)	{ for (cc = cc; cc > 0; cc--)	writeR(hid, &rid); lulu = false; }
			else 	myroom << ttt<<"\n";
		}
		myroom.close();	mydate.close();
		remove("./sourse/room.txt");
		rename("./sourse/room1.txt", "./sourse/room.txt");
	}
}
//===============================================================================
void writeR(int hid,int* rid){
	int a;
	myroom << hid << "\t" << ((hid << 4)+(*rid)) << "\t"; *rid=*rid+1;
	cout << "what's name of room "<<(*rid)<<": ";	cin >> temp;
	myhotel << "(" << temp <<") ";
	cout <<"how many room is it: ";	cin >> a;	myroom << a <<"\t";
	cout <<"how many people can it live? ";
	cin>>a;	myroom << a <<"\t";
	cout << "hoe much is it? ";		cin >> a;	myroom << a <<"\t";
	myroom << temp<<"\n";
}
//===============================================================================
void listAllRoom(int a){
	char tt[num]; bool err= true;
	int rid, peo, pri,i=0, check[100] = {0};
	myroom.open("./sourse/room.txt", ios::in);
	myroom.getline(tt, num);
	cout << "\t�ЦW\trid\t�H��\t���B\n";
	while (!myroom.eof()){
		myroom.getline(tt, num);
		if (tt[0] == '\0') break;
		p = strtok(tt, "\t"); p = strtok(NULL, "\t"); 
		rid = atoi(p);
		p = strtok(NULL, "\t"); p = strtok(NULL, "\t"); peo = atoi(p);
		p = strtok(NULL, "\t"); pri = atoi(p);p = strtok(NULL, "\t");
		if (peo >= a){
			cout << "\t" << p<< "\t" << rid << "\t" << peo << "\t" << pri << "\n";
			check[i++] = rid;
		}
	}
	myroom.close();
Ivan:
	cout << "input the rid you want: ";	cin >> a;
	for (i = 0; i < 100; i++) if (a == check[i]) { err = false; break; }
	if (err){ cout << "your rid is error\n"; goto Ivan; }
	myguest << a << "\t" << temp << "\n";
}
//===============================================================================
void listBookR(string name,bool* non){
	char a;
	myguest.open("./sourse/guest.txt", ios::in);
	myguest.getline(temp, num);
	cout << "\t���\t�H��\trid\t�W�r\n";
	while (!myguest.eof()){
		myguest.getline(temp, num);
		string tt(temp);		p = strtok(temp, "\t");
		if (p == NULL) break;	p = strtok(NULL, "\t");
		p = strtok(NULL, "\t"); p = strtok(NULL, "\t");
		if (name == p){ cout << "\t" << tt << "\n"; *non = false; }
	}
	if (*non) { cout << "you haven't book a room\n"; return void(); }
again:
	cout << "do you want to cancel any booked? (Y/n)";
	cin >> a;
	switch (a){
		case 'Y': case 'y':	cancel(name);	 break;
		case 'N': case 'n':	break;
		default: cout << "you have an error input\n";	goto again;
	}
	myguest.close();
}
//===============================================================================
void cancel(string name){
	string rid,date;
	cout << "please input the rid you want to cancel: ";	cin >> rid;
	cout << "please input the date you want to cancel: ";	cin >> date;
	mydate.open("./sourse/guest1.txt", ios::out);
	myguest.clear();	myguest.seekg(0, ios::beg);
	while (!myguest.eof()){
again:
		myguest.getline(temp, num);
		string ttt(temp);
		p = strtok(temp, "\t");
		if (p == NULL)break;
		if (p == date){
			p = strtok(NULL, "\t");	p = strtok(NULL, "\t");
			if (p == rid){
				p = strtok(NULL, "\t");
				if (p == name)	goto again;
				else 	mydate << ttt<<"\n";
			}
			else 	mydate << ttt<<"\n";
		}
		else 	mydate << ttt<<"\n";
	}
	myguest.close();	mydate.close();
	remove("./sourse/guest.txt");
	rename("./sourse/guest1.txt", "./sourse/guest.txt");
}