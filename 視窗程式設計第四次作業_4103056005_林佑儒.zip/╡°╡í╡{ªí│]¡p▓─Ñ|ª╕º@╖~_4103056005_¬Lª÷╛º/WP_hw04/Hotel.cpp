#include "stdafx.h"
#include "Hotel.h"
//===============================================================================
CHotel::CHotel(void){
	name    = new string("");
	city    = new string("");
	country = new string("");
	address = new string("");
	infor   = new string("");
	pw      = new string("");
	region  = new string("");
	allname = new string("");
	hid     = new u_int(0);
	hroom   = new CRoom();
	myhotel = new fstream();
}
//===============================================================================
CHotel::~CHotel(void){
	delete hid;
	delete pw;
	delete name;
	delete city;
	delete region;
	delete country;
	delete allname;
	delete address;
	delete infor;
	delete hroom;
	delete myhotel;
}
//===============================================================================
bool CHotel::check(u_int* inputHid, string* inputpw){
	if (*inputHid == *hid && *inputpw == *pw)
		return _Ture;
	else
		return _False;
}
//===============================================================================
bool CHotel::onScreen(void){
	u_int* i = new u_int(0);
	char* temp = new char[MAX];
	cout << "==========================================================\n";
	cout << "this is your hotel data:\n";
	myhotel->open("./sourse/hotel_descrip/" + (*name) + ".txt", ios::in);
	if (!(*myhotel))
		goto a;
	myhotel->getline(temp, MAX);
	while (myhotel->getline(temp, MAX)){
		(*i) = 0;
		while ((*(temp + (*i))) != '\0')
			cout << (*(temp + ((*i)++)));
		cout << '\n';
	}
	myhotel->close();
	cout << "==========================================================\n";
	delete[] temp;
	delete i;
	return _Ture;
a:
	delete[] temp;
	delete i;
	return _False;
}
//===============================================================================
void CHotel::toFile(void){
	myhotel->open("./sourse/hotel_descrip/" + (*name) + ".txt", ios::out);
	(*myhotel) << (*hid) << '\n'
			   << "name:\t" << (*name) << "\n"
			   << "region:\t" << (*region) << "\n"
			   << "city:\t" << (*city) << "\n"
			   << "contry: " << (*country) << "\n"
			   << "addres: " << (*address) << "\n"
			   << "rooms:\t"<<(*allname) << "\n"
			   << "infor:\n\t" << (*infor);
	myhotel->close();
}
//===============================================================================
void CHotel::modify(){
	myhotel->open("./sourse/hotel_descrip/" + (*name) + ".txt", ios::in);
	(*myhotel) >> (*hid);
	deleteRoom();
	deleteFromFile();
	myhotel->close();
	bool* isinit = new bool(_Ture);
	getOther(isinit);
	toFile();
	delete isinit;
}
//===============================================================================
void CHotel::init(void){
	cout << "what's the name of hotle? : ";		cin >> (*name);
	gethid();
	bool* isinit = new bool(_Ture);
	getOther(isinit);
	toFile();
	delete isinit;
}
//===============================================================================
void CHotel::gethid(void){
	fstream* hidFile=new fstream;
	char* temp = new char[MAX];
	hidFile->open("./sourse/hotel_descrip/nextID.txt", ios::in);
	hidFile->getline(temp, MAX);
	(*hid) = atoi(temp); (*hidFile).close();
	hidFile->open("./sourse/hotel_descrip/nextID.txt", ios::out);
	(*hidFile) << (*hid) + 1;	hidFile->close();
	delete[] temp;
	delete hidFile;
}
//===============================================================================
void CHotel::getOther(bool *got){
	u_int *num = new u_int;
	cout << "what region you are? : ";					cin >> *region;
	cout << "what country you are? : ";					cin >> *country;
	cout << "what city you are? : ";					cin >> *city;
	cout << "what address you are? :  ";				cin >> *address;
	roomSet(got);
	cout << "what's infor of hotel " << (*name) << ": ";
	getline(cin, (*infor));
	delete num;
}
//===============================================================================
void CHotel::roomSet(bool *got){
	fstream* allroom=new fstream();
	u_int *num = new u_int;
	u_int *i = new u_int;
	if ((*got)){
		allroom->open("./sourse/allroom.txt",ios::out|ios::app);
		cout << "how many kinds of room you have? :  ";		cin >> *num;
		for ((*i) = 0; (*i)<(*num);){
			hroom->init(hid, i);
			(*allname) += to_string((*hroom->rid)) + " (" + (*hroom->name) + ")\t";
			(*allroom) << (*region) << '\t' << (*name) << '\t' << (*hroom->name) << '\t'
					   << (*hroom->people) << '\t' << (*hroom->cost) << '\n';
		}
		allroom->close();
	}
	else{
		cout << "which room you want to modify?(give rid) :  ";	cin >> *num;
		hroom->modify(hid, num);
	}
	delete allroom;
	delete i;
	delete num;
}
//===============================================================================
void CHotel::deleteRoom(void){
	string* temp = new string("");
	while ((*temp) != "rooms:")
		(*myhotel) >> (*temp);
	while (_Ture){
		(*myhotel) >> (*temp);
		if ((*temp)[0] == '(')
			continue;
		if ((*temp) == "infor:")
			break;
		(*temp) = "./sourse/room_descrip/" + (*temp) + ".txt";
		remove(temp->c_str());
	}
	delete temp;
}
//===============================================================================
void CHotel::deleteFromFile(){
	string* temp = new string("");
	string* t = new string("");
	string* tt = new string("");
	string* ttt = new string("");
	string* rr = new string("");
	fstream* all = new fstream();
	fstream* allr = new fstream();
	all->open("./sourse/allroom.txt", ios::in);
	allr->open("./sourse/allroom1.txt", ios::out);
	while (!all->eof()){
		*all >> *rr;
		if (*rr == "")
			break;
		*all >> *temp;
		if (*temp == *name){
			*all >> *t >> *tt >> *ttt;
		}
		else{
			*all >> *t >> *tt>>*ttt;
			*allr << *rr << '\t' << *temp << '\t' << *t << '\t' << *tt << '\t' << *ttt << '\n';
		}
	}
	all->close();
	allr->close();
	remove("./sourse/allroom.txt");
	rename("./sourse/allroom1.txt","./sourse/allroom.txt");
	delete all, allr;
	delete temp,rr,t,tt,ttt;
}
//===============================================================================