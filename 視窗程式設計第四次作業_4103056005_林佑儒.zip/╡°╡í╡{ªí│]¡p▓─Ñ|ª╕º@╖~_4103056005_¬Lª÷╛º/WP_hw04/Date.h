#pragma once // �O�Ҥޥ��� (*.h) �u�|�Q�ޥΤ@���A�p���N���ݭn�Ρu�ޤJ���@�v�F�C
#include "Mydefine.h"
#include "time.h"
//===============================================================================
class CDate{
public:
	u_int* rid;
	u_int* rlimete;
	bool* count;
	int* year;
	int* mounth;
	int* day;
	fstream* mydate;
//===============================================================================
public:
	CDate(void);
	~CDate(void);
	bool check(void);				//check if the room can be book that day
	bool checkDate(void);			//check if the day correct and is the day after to day
	void toFile(int*);				//write to file
//===============================================================================
private:
	void getRLimete(void);			//get room's people limete 
};