/***************************
4103056005�L�����ĥ|���@�~11/23
***************************/

#include "stdafx.h"
#include "Room.h"
#include "Hotel.h"
#include "Guest.h"
//===============================================================================
void mode1(void);			//hotel management
void mode2(void);			//booking
void mode3(void);			//booked management
//===============================================================================
CHotel *usehotel;
CGuest *useguest;
//===============================================================================
int _tmain(int argc, _TCHAR* argv[]){
	u_int* modelNum=new u_int(0);
	cout << "\n\trid is room's id\n"
		 <<"booking record will be sort by date,region,people(first,second,third order)  \n\n";
	while (true){
	start:
		cout << "input a number of mode\n"
		     << "\t1 for hotel infor\n\t2 for booking\n"
		     << "\t3 for check�Bcancel and pay if you want\n"
			 << "\t4 for exit\t";
		cin >> (*modelNum);
		if (cin.fail()) (*modelNum) = 1000;
		switch ( (*modelNum) ){
			case 1:	mode1(); break;
			case 2:	mode2(); break;
			case 3:	mode3(); break;
			case 4:	goto end;
			default: 
				cout << "you have an error input\n";
				cin.clear(); cin.ignore(999, '\n');
				goto start;
		}
		cout << "\n";
	}
end:
	delete modelNum;
	return 0;
}
//===============================================================================
void mode1(void){
	usehotel = new CHotel();
	string* name = new string("");
	char* a=new char;
again:
	cout << "have your hotel in this system? (Y/n)"; cin >> (*a);
	switch( (*a) ){
		case 'Y': case 'y':	
			cout << "what's the name of hotel? : ";		cin >> *name;
			(*usehotel->name) = (*name);
			if (!usehotel->onScreen()){
				cout << "==========================================================\n"
					<< "your hotel isn't in system\n";
				goto aaa;
			}
			break;
		case 'N': case 'n':	usehotel->init();	goto aaa;
		default : cout << "you have an error input\n";	goto again;
	}
aa:
	cout << "do you want to modify your hotel? (Y/n)";	cin >> (*a);
	switch ((*a)){
		case 'Y': case 'y':	usehotel->modify();	break;
		case 'N': case 'n':	break;
		default: cout << "you have an error input\n";	goto aa;
	}
aaa:
	delete name;
	delete a;
	delete usehotel;
}
//===============================================================================
void mode2(void){
	useguest = new CGuest();
	useguest->booking();
	delete useguest;
}
//===============================================================================
void mode3(void){
	char* a = new char;
	useguest = new CGuest();
	if (!(useguest->listBroom())){
		cout << "you haven't book anything\n";
		goto b;
	}
aa:
	cout << "do you want to cancel any room? (Y/n)";	cin >> (*a);
	switch ((*a)){
	case 'Y': case 'y':	useguest->cancelroom();	break;
	case 'N': case 'n':	break;
	default: cout << "you have an error input\n";	goto aa;
	}
aaa:
	cout << "do you want to pay for any room? (Y/n)";	cin >> (*a);
	switch ((*a)){
		case 'Y': case 'y':	useguest->payRoom();	break;
		case 'N': case 'n':	break;
		default: cout << "you have an error input\n";	goto aaa;
	}
b:	delete useguest;
	delete a;
}
//===============================================================================
