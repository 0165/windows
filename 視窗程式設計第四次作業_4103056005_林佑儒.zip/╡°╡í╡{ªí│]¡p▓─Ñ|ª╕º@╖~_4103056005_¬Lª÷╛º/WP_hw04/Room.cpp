#include "stdafx.h"
#include "Room.h"
//===============================================================================
CRoom::CRoom(void){
	hid = new u_int(0);
	rid = new u_int(0);
	num = new u_int(0);
	people = new u_int(0);
	cost = new u_int(0);
	name = new string("");
	infor= new string("");
	myroom=new fstream();
}
//===============================================================================
CRoom::~CRoom(){
	delete hid;
	delete rid;
	delete num;
	delete people;
	delete cost;
	delete name;
	delete infor;
	delete myroom;
}
//===============================================================================
void CRoom::onScreen(u_int* getrid){
	char* temp = new char[MAX];
	cout << "==========================================================\n";
	myroom->open("./sourse/room_descrip/" + to_string((*rid))+ ".txt", ios::in);
	myroom->getline(temp,MAX);
	while (myroom->getline(temp, MAX))
		cout << *temp << "\n";
	myroom->close();
	cout << "==========================================================\n";
	delete[] temp;
}
//===============================================================================
void CRoom::toFile(void){
	myroom->open("./sourse/room_descrip/" + to_string((*rid)) + ".txt", ios::out);
	(*myroom) << (*hid) << '\t' << (*rid) << "\n"
			  <<"name\t"<< (*name) << "\n"
			  << "num's\t"<< (*num) << "\npeople\t" << (*people) << "\n"
			  << "cost\t" << (*cost) << "\ninfor:\n\t"
			  << (*infor);
	myroom->close();
}
//===============================================================================
void CRoom::modify(u_int* gethid, u_int* getrid){
	*hid = *gethid;
	*rid = *getrid;
	cout << "what's name of room " << (*rid) << ": ";	cin >> *name;
	getOther();
	toFile();
}
//===============================================================================
void CRoom::init(u_int* gethid, u_int* now){
	*hid = *gethid;
	*rid = (( (*hid) << 4) + ( (*now)++) );
	cout << "what's name of room " << (*now) << ": ";	cin >> *name;
	getOther();
	toFile();
}
//===============================================================================
void CRoom::getOther(void){
	cout << "how many room is it: ";					cin >> *num;
	cout << "how many people can it live? ";			cin >> *people;
	cout << "hoe much is it? ";							cin >> *cost;
	cout << "what's infor of room " << (*name) << ": ";
	cin.ignore();	getline(cin, (*infor));
}
//===============================================================================
bool CRoom::getFormFile(void){
	myroom->open("./sourse/room_descrip/" + to_string((*rid)) + ".txt", ios::in);
	if (!(*myroom))
		return _False;
	string* tt = new string("");
	*myroom >> *hid >> *rid;
	*myroom >> *tt>> *name;
	*myroom >> *tt >> *num;
	*myroom >> *tt >> *people;
	*myroom >> *tt >> *cost;
	delete tt;
	return _Ture;
}
//===============================================================================