#pragma once // �O�Ҥޥ��� (*.h) �u�|�Q�ޥΤ@���A�p���N���ݭn�Ρu�ޤJ���@�v�F�C
#include "Room.h"
//===============================================================================
class CHotel{
public:
	string*	name;
	string*	city;
	string*	region;
	string*	country;
	string*	address;
	string*	infor;
	string*	allname;
	CRoom*	hroom;
	fstream* myhotel;
//===============================================================================
public:
	CHotel();
	~CHotel();
	bool	check(u_int*,string*);		//check password, but didn't use
	bool	onScreen(void);				//show hotel infor
	void	toFile(void);				//write to file
	void	init(void);					//setup hotel infor
	void	modify();					//modify hotel infor
//===============================================================================
private:
	u_int*	hid;						//hotel id
	string*	pw;							//password, but didn't use
//===============================================================================
private:
	void	gethid(void);				//get hotel id
	void	getOther(bool *);			//get everything except hid and name
	void	roomSet(bool *);			//setup room
	void	deleteRoom(void);			//delete all room
	void	deleteFromFile();			//delete all room form list
};