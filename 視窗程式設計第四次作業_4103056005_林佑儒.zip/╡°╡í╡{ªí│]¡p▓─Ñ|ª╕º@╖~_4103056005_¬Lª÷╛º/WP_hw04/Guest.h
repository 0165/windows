#pragma once // �O�Ҥޥ��� (*.h) �u�|�Q�ޥΤ@���A�p���N���ݭn�Ρu�ޤJ���@�v�F�C
#include "Mydefine.h"
#include "Date.h"
#include "Hotel.h"
//===============================================================================
class CGuest{
public:
	u_int* rid;
	u_int* people;
	bool* pay;
	CDate* usedate;
	string*	region;
	string*	name;
	CHotel* use;
	fstream* myguest;
//===============================================================================
public:
	CGuest(void);
	~CGuest(void);
	bool booking(void);						//booking hotel
	bool listroom(void);					//list the room that can be chose
	void cancelroom(void);					//cancel the booked room
	void payRoom(void);						//pay for the room
	bool listBroom(void);					//list the book room
private:
	void toFile(void);						//write to the file
	bool getCardInfor(void);				//get pay infor
};