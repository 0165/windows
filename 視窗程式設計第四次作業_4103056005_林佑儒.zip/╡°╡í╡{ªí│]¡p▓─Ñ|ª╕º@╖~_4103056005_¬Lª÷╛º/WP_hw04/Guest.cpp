#include "stdafx.h"
#include "Guest.h"
//===============================================================================
CGuest::CGuest(void){
	pay = new bool(_False);
	rid=new u_int(0);
	people = new u_int(0);
	usedate = new CDate();
	region = new string("");
	name = new string("");
	use = new CHotel();
	myguest = new fstream();
}
//===============================================================================
CGuest::~CGuest(void){
	delete pay;
	delete rid;
	delete people;
	delete usedate;
	delete region;
	delete use;
	delete name;
	delete myguest;
}
//===============================================================================
bool CGuest::booking(void){
	cout << "what's your name? :";
	cin >> (*name);
a:	cout << "how many people do you have? :";
	cin >> (*people);
	if (!listroom()){
		cout << "sorry, this region have no hotel for you\n";
		return _False;
	}
	cout << "rooms: rid (room name)\n";
	cout <<"input the rid you want: ";
	cin>>(*rid);
	(*use->hroom->rid) = (*rid);
	if (!use->hroom->getFormFile()){
		cout << "you have a wrong rid\n";
		return _False;
	}
	if (*people > *use->hroom->people){
		cout << "you have too many people for this room\n";
		goto a;
	}
	(*usedate->rid) = (*rid);
lulu:
	cout << "the day before today isn't allowed(include today)\n"
		 << "input the year you want(ex: 2016): ";
	cin >> (*usedate->year);
	cout << "input the mounth you want(ex: 1): ";	cin >> (*usedate->mounth);
	cout << "input the day you want(ex: 29): ";	cin >> (*usedate->day);
	if (usedate->checkDate())
		if (usedate->check()){
			int* k = new int(-1);
			usedate->toFile(k);
			toFile();
			cout << "booking success\n";
			delete k;
		}
		else
			cout << "the room that day is full booking\n";
	else{
		cout << "error input\n";
		goto lulu;
	}
	return _Ture;
}
//===============================================================================
bool CGuest::listBroom(void){
	cout << "what's your name? :";
	cin >> (*name);
	myguest->open("./sourse/guest_descrip/" + (*name) + ".txt", ios::in);
	if (!(*myguest))
		return _False;
	cout << "==========================================================\n"
		 << "0 means unpay\n1 means paied\n"
	     << "\tdate		region\tpeople\tname\trid\tpay\n";
	u_int* i = new u_int(0);
	u_int* j = new u_int(0);
	char* temp = new char[MAX];
	while (myguest->getline(temp, MAX)){
		(*i) = 0;
		cout << ++(*j) << '\t';
		while ((*(temp + (*i))) != '\0')
			cout << (*(temp + ((*i)++)));
		cout << '\n';
	}
	myguest->close();
	cout << "==========================================================\n";
	delete[] temp;
	delete i,j;
	return _Ture;
}
//===============================================================================
bool CGuest::listroom(void){
	myguest->open("./sourse/allroom.txt", ios::in);
	char* temp = new char[MAX];
	u_int* i = new u_int(0);
	cout <<"what region you want to book?: ";
	cin >> (*region);
	char* p;
	char* pp;
	cout << "==========================================================\n"
		 << "hotel\troom\tpeople\tcost\n";
	while (!myguest->eof()){
		myguest->getline(temp, MAX);
		if (*temp == NULL)
			break;
		p = strtok_s(temp,"\t",&pp);
		if (p == (*region)){
			p = strtok_s(NULL, "\t",&pp);
			cout << p << '\t';
			p = strtok_s(NULL, "\t", &pp);
			cout << p << '\t';
			p = strtok_s(NULL, "\t", &pp);
			cout << p << '\t';
			p = strtok_s(NULL, "\t", &pp);
			cout << p << '\n';
			(*i)++;
		}
	}
	myguest->close();
	cout << "==========================================================\n";
	if (*i == 0){
		delete[] temp;
		return _False;
	}
	cout << "what hotel you want to book?: ";
	cin >> (*use->name);
	use->onScreen();
	delete[] temp;
	return _Ture;
}
//===============================================================================
void CGuest::cancelroom(void){
	string* temp = new string("");	string* t1 = new string("");	string* t2 = new string("");
	string* tt = new string("");	string* t3 = new string("");	string* t4 = new string("");
	string* t5 = new string("");
	fstream* fp = new fstream();
	int* i = new int(0);
	cout << "input the line number you want to cancel :";
	cin >> *i;
	(*i)--;
	myguest->open("./sourse/guest_descrip/" + (*name) + ".txt", ios::in);
	fp->open("./sourse/guest_descrip/" + (*name) + "1.txt", ios::out);
	while (*i){
		*myguest >> *temp >> *t1 >> *t2 >> *t3 >> *t4 >> *t5;
		*fp << *temp << '\t' << *t1 << '\t' << *t2 << '\t' << *t3 << '\t' << *t4 << '\t' << *t5 << '\n';
		(*i)--;
	}
	*myguest >> *temp >> *t1 >> *t2 >> *t3 >> (*usedate->rid) >> *t5;
	(*usedate->year) = stoi(temp->substr(0,4));
	(*usedate->rid) = stoi(temp->substr(5, 2));
	(*usedate->rid) = stoi(temp->substr(8, 2)); *i = 1;
	usedate->toFile(i);
	while (!myguest->eof()){
		*myguest >> *temp >> *t1 >> *t2 >> *t3 >> *t4 >> *t5;
		if (myguest->eof())
			break;
		*fp << *temp << '\t' << *t1 << '\t' << *t2 << '\t' << *t3 << '\t' << *t4 << '\t' << *t5 << '\n';
	}
	myguest->close();
	fp->close();
	*temp = "./sourse/guest_descrip/" + (*name) + ".txt";
	*tt = "./sourse/guest_descrip/" + (*name) + "1.txt";
	remove(temp->c_str());
	rename(tt->c_str(), temp->c_str());
	cout << "cancel success\n";
	delete fp;
	delete temp, tt, t1, t2, t3, t4, t5;
}
//===============================================================================
void CGuest::payRoom(void){
	if(!getCardInfor())
		return void();
	string* temp = new string("");	string* t1 = new string("");	string* t2 = new string("");
	string* tt = new string("");	string* t3 = new string("");	string* t4 = new string("");
	string* t5 = new string("");
	fstream* fp = new fstream();
	u_int* i = new u_int(0);
	cout << "input the line number you want to pay :";
	cin >> *i;
	(*i)--;
	myguest->open("./sourse/guest_descrip/" + (*name) + ".txt", ios::in);
	fp->open("./sourse/guest_descrip/" + (*name) + "1.txt", ios::out);
	while (*i){
		*myguest >> *temp >> *t1 >> *t2 >> *t3 >> *t4 >> *t5;
		*fp << *temp << '\t' << *t1 << '\t' << *t2 << '\t' << *t3 << '\t' << *t4 << '\t' << *t5 << '\n';
		(*i)--;
	}
	*myguest >> *temp >> *t1 >> *t2 >> *t3 >> *t4 >> *t5;
	*t5 = '1';
	*fp << *temp << '\t' << *t1 << '\t' << *t2 << '\t' << *t3 << '\t' << *t4 << '\t' << *t5 << '\n';
	while (!myguest->eof()){
		*myguest >> *temp >> *t1 >> *t2 >> *t3 >> *t4 >> *t5;
		if (myguest->eof())
			break;
		*fp << *temp << '\t' << *t1 << '\t' << *t2 << '\t' << *t3 << '\t' << *t4 << '\t' << *t5 << '\n';
	}
	myguest->close();
	fp->close();
	*temp = "./sourse/guest_descrip/" + (*name) + ".txt";
	*tt = "./sourse/guest_descrip/" + (*name) + "1.txt";
	remove(temp->c_str());
	rename(tt->c_str(), temp->c_str());
	cout << "pay success\n";
	delete fp;
	delete temp, tt, t1, t2, t3, t4, t5;
}
//===============================================================================
void CGuest::toFile(void){
	bool* test = new bool(_Ture);
	string* temp = new string("");	string* t1 = new string("");	string* t2 = new string("");
	string* tt = new string("");	string* t3 = new string("");	string* t4 = new string("");
	string* t5 = new string("");
	fstream* fp = new fstream();
	myguest->open("./sourse/guest_descrip/" + (*name) + ".txt", ios::in);
	if (!(*myguest)){
		myguest->open("./sourse/guest_descrip/" + (*name) + ".txt", ios::out);
		*tt = to_string(*usedate->year) + '/' + to_string(*usedate->mounth) + '/' + to_string(*usedate->day);
		*myguest << *tt << '\t' << (*region) << '\t' << (*people) << '\t' << (*use->name) << '\t' << *rid << '\t' << *pay << '\n';
		myguest->close();
		goto a;
	}
	*tt = to_string(*usedate->year) + '/' + to_string(*usedate->mounth) + '/' + to_string(*usedate->day);
	fp->open("./sourse/guest_descrip/" + (*name) + "1.txt", ios::out);
	while (!myguest->eof()){
		*myguest >> *temp >> *t1 >> *t2 >> *t3 >> *t4 >> *t5;
		if (myguest->eof()){
			if (*test)
				*fp << *tt << '\t' << (*region) << '\t' << (*people) << '\t' << (*use->name) << '\t' << *rid << '\t' << *pay << '\n';
			break;
		}
		if (*test && *tt < *temp){
			*fp << *tt << '\t' << (*region) << '\t' << (*people) << '\t' << (*use->name) << '\t' << *rid << '\t' << *pay << '\n';
			*test = _False;
		}
		else if (*test && *tt == *temp){
			if (*region < *t1){
				*fp << *tt << '\t' << (*region) << '\t' << (*people) << '\t' << (*use->name) << '\t' << *rid << '\t' << *pay << '\n';
				*test = _False;
			}
			else if (to_string(*people) < *t2){
				*fp << *tt << '\t' << (*region) << '\t' << (*people) << '\t' << (*use->name) << '\t' << *rid << '\t' << *pay << '\n';
				*test = _False;
			}
		}
		*fp << *temp << '\t' << *t1 << '\t' << *t2 << '\t' << *t3 << '\t' << *t4 << '\t' << *t5 << '\n';
	}
	myguest->close();
	fp->close();
	*temp = "./sourse/guest_descrip/" + (*name) + ".txt";
	*tt = "./sourse/guest_descrip/" + (*name) + "1.txt";
	remove(temp->c_str());
	rename(tt->c_str(), temp->c_str());
a:	
	delete fp;
	delete temp,tt,t1,t2,t3,t4,t5;
	delete test;
}
//===============================================================================
bool CGuest::getCardInfor(void){
	string* temp = new string("");
a:	cout << "input the credit card number (ex: ASCS-ACFR-1234-4567) :";
	cin >> *temp;
	if (temp->length() != 19){
		cout << "error input\n";
		goto a;
	}
	cout << "input the valid date's year (ex: 2016) :";		cin >> (*usedate->year);
	cout << "input the valid date's mounth (ex: 01) :";		cin >> (*usedate->mounth);
	cout << "input the valid date's day (ex: 29) :";		cin >> (*usedate->day);
	if (!usedate->checkDate()){
		cout << "your card is invalid\n";
		delete temp;
		return _False;
	}
aaa:
	cout << "input the real name (ex:Frank) :";
	cin >> *temp;
	if (*temp==""){
		cout << "error input\n";
		goto aaa;
	}
	delete temp;
	return _Ture;
}
//===============================================================================