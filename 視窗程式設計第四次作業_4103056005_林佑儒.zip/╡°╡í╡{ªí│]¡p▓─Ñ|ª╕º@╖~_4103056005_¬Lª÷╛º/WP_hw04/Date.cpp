#include "stdafx.h"
#include "Date.h"
//===============================================================================
CDate::CDate(void){
	rid = new u_int;
	rlimete = new u_int(0);
	count = new bool(_False);
	year = new int;
	mounth = new int;
	day = new int;
	mydate = new fstream;
}
//===============================================================================
CDate::~CDate(void){
	delete year,mounth,day;
	delete rid, rlimete;
	delete mydate;
	delete count;
}
//===============================================================================
bool CDate::checkDate(void){
	int *arr = new int[12];
	u_int *i = new u_int(0);
	for ((*i) = 0; (*i) < 12; (*i)++){
		switch ((*i)){
		case 0:	case 2:	case 4:	case 6:	case 7:	case 9:	case 11:
			*(arr + (*i)) = 31;	break;
		case 1:
			*(arr + (*i)) = 29; break;
		default:
			*(arr + (*i)) = 30; break;
		}
	}
	time_t *now = new time_t(time(NULL));
	tm *ltm = new tm;
	(*year) -= 1900;	(*mounth) -= 1;
	localtime_s(ltm, now);
	if ((*day) > (*(arr + (*mounth))))
		goto a;
	if (ltm->tm_year > (*year))
		goto a;
	else if (ltm->tm_year < (*year))
		goto b;
	else if (ltm->tm_mon > (*mounth))
		goto a;
	else if (ltm->tm_mon < (*mounth))
		goto b;
	else if (ltm->tm_mday >= (*day))
		goto a;
b:	(*year) += 1900;	(*mounth) += 1;
	delete i;
	delete[] arr;
	delete now, ltm;
	return _Ture;
a:	
	(*year) += 1900;	(*mounth) += 1;
	delete i;
	delete[] arr;
	delete now, ltm;
	return _False;
}
//===============================================================================
bool CDate::check(void){
	int* gy, *gm, *gd,*gr,*gnum;
	gy = new int;	gm = new int;	*count = _False;
	gd = new int;	gr = new int;	gnum = new int;
	mydate->open("./sourse/date.txt", ios::in);
	while (!mydate->eof()){
		*mydate >> *gr >> *gy >> *gm >> *gd >> *gnum;
		if ((*gr) == (*rid) && (*gy) == (*year) && (*gm) == (*mounth) && (*gd) == (*day))
			if ((*gnum) >= 1){
				*count = _False;
				break;
			}
			else
				goto a;
		else
			*count = _Ture;
	}
	mydate->close();
	if ((*count) == _Ture)
		getRLimete();
	delete gy, gm, gd,gr,gnum;
	return _Ture;
a:	mydate->close();
	delete gy, gm, gd, gr, gnum;
	return _False;
}
//===============================================================================
void CDate::toFile(int* k){
	bool* test = new bool(_Ture);
	if (*count){
		mydate->open("./sourse/date.txt", ios::out | ios::app);
		*mydate << *rid << ' ' << *year << ' ' << *mounth << ' ' << *day << ' ' << (*rlimete)-1 << '\n';
		mydate->close();
		return void();
	}
	fstream* use = new fstream();
	int* gy, *gm, *gd, *gr, *gnum;
	gy = new int;	gm = new int;
	gd = new int;	gr = new int;	gnum = new int;
	use->open("./sourse/date1.txt", ios::out);
	mydate->open("./sourse/date.txt", ios::in);
	while (!mydate->eof()){
		*mydate >> *gr >> *gy >> *gm >> *gd >> *gnum;
		if (mydate->eof())
			break;
		if (*test && (*gr) == (*rid) && (*gy) == (*year) && (*gm) == (*mounth) && (*gd) == (*day)){
			*use << *gr << ' ' << *gy << ' ' << *gm << ' ' << *gd << ' ' << (*gnum) +(*k) << '\n';
			*test = _False;
		}
		else
			*use << *gr << ' ' << *gy << ' ' << *gm << ' ' << *gd << ' ' << (*gnum)  << '\n';
	}
	use->close();
	mydate->close();
	delete use;
	delete gy, gm, gd, gr, gnum;
	delete test;
	remove("./sourse/date.txt");
	rename("./sourse/date1.txt", "./sourse/date.txt");
}
//===============================================================================
void CDate::getRLimete(void){
	char* temp = new char[MAX];
	mydate->open("./sourse/room_descrip/" + to_string((*rid)) + ".txt", ios::in);
	mydate->getline(temp, MAX);
	mydate->getline(temp, MAX);
	*mydate >> temp >> *rlimete;
	mydate->close();
	delete[] temp;
}
//===============================================================================