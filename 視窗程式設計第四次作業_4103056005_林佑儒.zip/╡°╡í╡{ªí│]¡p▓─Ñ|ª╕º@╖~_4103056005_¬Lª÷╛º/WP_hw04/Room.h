#pragma once // �O�Ҥޥ��� (*.h) �u�|�Q�ޥΤ@���A�p���N���ݭn�Ρu�ޤJ���@�v�F�C

#ifndef u_int
	#include <iostream>
	#include <fstream>
	#include <string>
	#define u_int unsigned int
	#define MAX 500
	#define _Ture 1
	#define _False 0
	using namespace std;
#endif
//===============================================================================
class CRoom{
public:
	u_int*	hid;
	u_int*	rid;
	u_int*	num;
	u_int*	people;
	u_int*	cost;
	string*	name;
	string*	infor;
	fstream* myroom;
//===============================================================================
public:
	CRoom(void);
	~CRoom(void);
	void	onScreen(u_int *);				//show room infor
	void	modify(u_int *, u_int*);		//modify room infor, but didn't use
	void	init(u_int *, u_int*);			//setup room infor
	bool	getFormFile();					//get room infor from file
//===============================================================================
private:
	void	toFile(void);					//write to file
	void	getOther(void);					//get everything except rid and name
};