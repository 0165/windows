/***************************
4103056005�L�����ĤT���@�~11/2
***************************/
#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <cstdlib>				// For the exit() function
#include <cctype>				// For the isdigit() function
#include <cstring> 
#include <math.h>				// For the pow(), sqrt(),etc...
//===============================================================================
#define maxnum 501				//max lenght of input
using namespace std;
//===============================================================================
void mode1(char *);
void mode2(char *);
void eatSpace(char *);			// Function to delete all space
double* expr(char*);			// Function evaluating an expression
double* term(char*, int*);		// Function analyzing a term
double* number(char*, int*);	// Function to recognize a number
char* extract(char*, int*);		// Function to extract a substring
void mod(double*, double*);		// Function to cacul %
void layar(double*);			// Function to cacul !
//===============================================================================
int _tmain(int argc, _TCHAR* argv[])
{
	char *a = new char[maxnum];
again:
	cout << "\t{ and [ will been seen as ( ,} and ] will been seen as )\n"
		<< "\tlog() is using e(2.71828) as base\n"
		<< "\tevery input can have at most 500 words (include space)\n"
		<< "\n input the mode (1 for reading file, 2 for cmd input):\t";
	cin.getline(a, maxnum);
	if (*(a + 1) == '\0'){
		if (*a == '1')		mode1(a);
		else if (*a == '2')	mode2(a);
		else 				goto again;
	}
	else{
		cout << "error input"; goto again;
	}
	delete[] a;
	system("pause");
	return 0;
}
//===============================================================================
void mode1(char *a){
	ifstream * myfile = new ifstream;
ag:	cout << "input your file name(need Filename extension)\n(file must at the same directory):";
	cin.getline(a, maxnum);
	(*myfile).open(a);
	if (!(*myfile)){
		cout << "your file doesn't in the directory\n";
		goto ag;
	}
	while (!(*myfile).eof()){
		(*myfile).getline(a, maxnum);
		eatSpace(a);
		if (*a=='\0')
			break;
		double* temp = expr(a);
		cout << "\t= " << *temp << endl << endl;
		delete temp;
	}
	delete myfile;
}
//===============================================================================
void eatSpace(char *a){
	int *i = new int, *j = new int;
	*i = 0;	*j = 0;
	while ((*(a + *i) = *(a + (*j)++)) != '\0'){
		if (*(a + *i) == '[' || *(a + *i) == '{')
			*(a + *i) = '(';
		if (*(a + *i) == ']' || *(a + *i) == '}')
			*(a + *i) = ')';
		if (*(a + *i) != ' ')	(*i)++;
	}
	delete i;	delete j;
}
//===============================================================================
void mode2(char *buffer){
	while (true){
		cin.getline(buffer, maxnum);
		eatSpace(buffer);
		if (*buffer=='\0')
			return void();
		double* temp = expr(buffer);
		cout << "\t= " << *temp << endl << endl;
		delete temp;
	}
}
//===============================================================================
double* expr(char* str)
{
	double *value, *temp;
	int *index = new int(0);
	value = term(str, index);

	while (true){
		switch (*(str + (*index)++)){
		case '\0':										//for end of input
			delete index;
			return value;
		case '+':										//for x+y
			temp = term(str, index);
			*value += *temp;
			delete temp;
			break;
		case '-':										//for x-y
			temp = term(str, index);
			*value -= *temp;
			delete temp;
			break;
		default:
			cout << endl << "Arrrgh!*#!! There's an error" << endl;
			exit(1);
		}
	}
}
//===============================================================================
double* term(char* str, int* index){
	double* value, *temp;
	if (*(str + (*index)) == 'e'){
		value = new double(2.718281828459);				//for e^x
		(*index)++;
	}
	else if (isdigit(*(str + (*index))) || *(str + (*index)) == '(')
		value = number(str, index);
	else
		value = new double(0.0);
	while (true)
	{
		if (*(str + (*index)) == '*'){					//for x*y
			(*index)++;
			temp = number(str, index);
			*value *= *temp;
			delete temp;
		}
		else if (*(str + (*index)) == '/'){				//for x/y
			(*index)++;
			temp = number(str, index);
			*value /= *temp;
			delete temp;
		}
		else if (*(str + (*index)) == '%'){				//for x%y
			(*index)++;
			mod(value, number(str, index));
		}
		else if (*(str + (*index)) == '^'){				//for x^y
			(*index)++;
			temp = number(str, index);
			*value = pow(*value, *temp);
			delete temp;
		}
		else if (*(str + (*index)) == '!'){				//for x!
			layar(value);
			(*index)++;
		}
		else if (*(str + (*index)) == 'E'){
			(*index)++;
			if (*(str + (*index)) == '-'){				//for xE-y
				(*index)++;
				temp = number(str, index);
				*value *= pow(10, -*temp);
				delete temp;
			}
			else if (*(str + (*index)) == '+'){			//for xE+y
				(*index)++;
				temp = number(str, index);
				*value *= pow(10, *temp);
				delete temp;
			}
		}
		else if (*(str + (*index)) == 'l'){
			if (strncmp((str + (*index)), "log", 3) == 0){//for log()
				(*index) += 3;
				if (*(str + (*index)) == '('){
					(*index)++;
					temp = number(str, index);
					*value = log(*temp);
					delete temp;
				}
				else if (strncmp((str + (*index)), "10", 2) == 0){//for log10()
					(*index) += 3;
					temp = number(str, index);
					*value = log10(*temp);
					delete temp;
				}
				(*index)++;
			}
		}
		else if (*(str + (*index)) == 's'){				//for sqrt()
			if (strncmp((str + (*index)), "sqrt", 4) == 0){
				(*index) += 5;
				temp = number(str, index);
				*value = sqrt(*temp);
				(*index)++;
				delete temp;
			}
		}
		else if (*(str + (*index)) == 'p'){				//for power()
			if (strncmp((str + (*index)), "power", 5) == 0){
				(*index) += 6;
				temp = number(str, index);
				(*index)++;
				double* temp1 = number(str, index);
				*value = pow(*temp, *temp1);
				(*index)++;
				delete temp1;
				delete temp;
			}
		}
		else
			break;
	}
	return value;
}
//===============================================================================
double* number(char* str, int* index){
	double* value;
	if (*(str + (*index)) == 'p' || *(str + (*index)) == 's' || *(str + (*index)) == 'e' || *(str + (*index)) == 'l'){
		value = term(str, index);
		return value;
	}
	if (*(str + (*index)) == '(')
	{
		char* psubstr(nullptr);
		(*index)++;
		psubstr = extract(str, index);
		value = expr(psubstr);
		delete[]psubstr;
		return value;
	}
	if (!isdigit(*(str + (*index))))
	{
		cout << endl << "Arrrgh!*#!! There's an error" << endl;
		exit(1);
	}
	value = new double(0.0);
	while (isdigit(*(str + (*index))))
		*value = 10 * (*value) + (*(str + (*index)++) - '0');
	if (*(str + (*index)) == 'E'){			//for x^y
		(*index)++;
		double* temp;
		if (*(str + (*index)) == '-'){				//for xE-y
			(*index)++;
			temp = number(str, index);
			*value *= pow(10, -*temp);
			delete temp;
		}
		else if (*(str + (*index)) == '+'){			//for xE+y
			(*index)++;
			temp = number(str, index);
			*value *= pow(10, *temp);
			delete temp;
		}
	}
	if (*(str + (*index)) == '^'){				//for x^y
		(*index)++;
		double* temp = number(str, index);
		*value = pow(*value, *temp);
		delete temp;
	}
	if (*(str + (*index)) == '!'){				//for x!
		layar(value);
		(*index)++;
	}
	if (*(str + (*index)) != '.')
		return value;
	double factor(1.0);
	while (isdigit(*(str + (++(*index)))))
	{
		factor *= 0.1;
		*value = (*value) + (*(str + (*index)) - '0')*factor;
	}
	return value;
}
//===============================================================================
// Function to extract a substring between parentheses 
char* extract(char* str, int* index)
{
	char* buffer = new char[maxnum];
	char* pstr(nullptr);
	int* numL = new int(0);
	int* bufindex = new int((*index));
	do{
		*(buffer + ((*index) - (*bufindex))) = *(str + (*index));
		switch (*(buffer + ((*index) - (*bufindex))))
		{
		case ')':
			if (0 == (*numL))
			{
				*(buffer + ((*index) - (*bufindex))) = '\0';
				(*index)++;
				pstr = new char[(*index) - (*bufindex)];
				if (!pstr)
				{
					cout << "Memory allocation failed, program terminated.";
					delete bufindex;
					delete[] buffer;
					delete numL;
					exit(1);
				}
				strcpy_s(pstr, (*index) - (*bufindex), buffer);
				delete numL;
				delete bufindex;
				delete[] buffer;
				return pstr;
			}
			else
				(*numL)--;
			break;
		case '(':
			(*numL)++;
			break;
		}
	} while (*(str + (*index)++) != '\0');
	delete numL;
	delete bufindex;
	delete[] buffer;
	cout << "Ran off the end of the expression, must be bad input." << endl;
	exit(1);
}
//===============================================================================
void mod(double* first, double* end){
	*first = (*first) - (*end)*(int)((*first) / (*end));
	delete end;
}
//===============================================================================
void layar(double* num){
	int *ans = new int((int)(*num) - 1);
	while ((*ans) != 1)
		*num *= ((*ans)--);
	delete ans;
}