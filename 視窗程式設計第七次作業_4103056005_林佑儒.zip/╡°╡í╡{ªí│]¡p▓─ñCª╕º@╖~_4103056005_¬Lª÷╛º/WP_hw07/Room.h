#pragma once // �O�Ҥޥ��� (*.h) �u�|�Q�ޥΤ@���A�p���N���ݭn�Ρu�ޤJ���@�v�F�C
#include "Mydefine.h"
//===============================================================================
ref class CRoom{
public:
	u_int^	hid;
	u_int^	rid;
	u_int^	num;
	u_int^	people;
	u_int^	cost;
	String^	name;
	String^	infor;
//===============================================================================
public:
	CRoom(void);
	~CRoom(void);
	void	onScreen();				//show room infor
	void	init(u_int ^, u_int^, String^, String^, String^, String^, String^);			//setup room infor
	bool	getFormFile();					//get room infor from file
//===============================================================================
private:
	void	toFile(void);					//write to file
	void	getOther(String^, String^, String^, String^);					//get everything except rid and name
};