#include "stdafx.h"
#include "Hotel.h"
//===============================================================================
CHotel::CHotel(void){
	name    = gcnew String("");
	city    = gcnew String("");
	country = gcnew String("");
	address = gcnew String("");
	infor   = gcnew String("");
	pw      = gcnew String("");
	region  = gcnew String("");
	allname = gcnew String("");
	hid     = gcnew u_int(0);
	hroom   = gcnew CRoom();
}
//===============================================================================
CHotel::~CHotel(void){
	delete hid;
	delete pw;
	delete name;
	delete city;
	delete region;
	delete country;
	delete allname;
	delete address;
	delete infor;
	delete hroom;
}
//===============================================================================
bool CHotel::check(u_int^ inputHid, String^ inputpw){
	if (*inputHid == *hid && String::Compare(inputpw,pw)==0)
		return _Ture;
	else
		return _False;
}
//===============================================================================
bool CHotel::onScreen(void){
	StreamReader^ myhotel;
	try{
		myhotel = gcnew StreamReader("./sourse/hotel_descrip/" + (name)+".txt");
	}
	catch (Exception ^e){
		goto a;
	}
	String^ temp = gcnew String("");
	Console::WriteLine(L"==========================================================");
	Console::WriteLine(L"this is your hotel data:");
	temp=myhotel->ReadLine();
	while (temp = myhotel->ReadLine())
		Console::WriteLine(L"{0}",temp);
	myhotel->Close();
	Console::WriteLine(L"==========================================================");
	delete temp;
	delete myhotel;
	return _Ture;
a:
	delete myhotel;
	return _False;
}
//===============================================================================
void CHotel::toFile(void){
	StreamWriter^ myhotel = gcnew StreamWriter("./sourse/hotel_descrip/" + (name)+".txt");
	myhotel->WriteLine(L"{0}", *hid);
	myhotel->WriteLine(L"name:\t{0}", name);
	myhotel->WriteLine(L"region:\t{0}", region);
	myhotel->WriteLine(L"city:\t{0}", city);
	myhotel->WriteLine(L"contry:\t{0}", country);
	myhotel->WriteLine(L"addres:\t{0}", address);
	myhotel->WriteLine(L"rooms:\t{0}", allname);
	myhotel->WriteLine(L"infor:\n\t{0}", infor);
	myhotel->Close();
	delete myhotel;
}
//===============================================================================
void CHotel::modify(String^ a1, String^ a2, String^ a3, String^ a4, String^ a5, String^ a6){
	name = a1;
	StreamReader^ myhotel = gcnew StreamReader("./sourse/hotel_descrip/" + (name)+".txt");
	*hid = UInt32::Parse(myhotel->ReadLine());
	deleteRoom(myhotel);
	myhotel->Close();
	deleteFromFile();
	getOther(a2, a3, a4, a5, a6);
	delete myhotel;
}
//===============================================================================
void CHotel::init(String^ a1, String^ a2, String^ a3, String^ a4, String^ a5, String^ a6){
	name = a1;
	gethid();
	getOther(a2,a3,a4,a5,a6);
}
//===============================================================================
void CHotel::gethid(void){
	StreamReader^ hidFile = gcnew StreamReader("./sourse/hotel_descrip/nextID.txt");
	(*hid) = UInt32::Parse(hidFile->ReadLine()); (*hidFile).Close();
	StreamWriter^ hidFile1 = gcnew StreamWriter("./sourse/hotel_descrip/nextID.txt");
	hidFile1->WriteLine(L"{0}", (*hid) + 1);	hidFile->Close();
	delete hidFile;
	delete hidFile1;
}
//===============================================================================
void CHotel::getOther(String^ a2, String^ a3, String^ a4, String^ a5, String^ a6){
	region = a2;	country = a3;	city = a4;
	address = a5;	infor=a6;
}
//===============================================================================
void CHotel::roomSet(int ii,String^ a1, String^ a2, String^ a3, String^ a4, String^ a5){
	u_int ^i = gcnew u_int(ii);
	StreamWriter^ allroom = gcnew StreamWriter("./sourse/allroom.txt", _Ture);
	hroom->init(hid, i,a1,a2,a3,a4,a5);
	allname += (*hroom->rid).ToString() + " (" + hroom->name + ")\t";
	allroom->WriteLine(L"{0}\t{1}\t{2}\t{3}\t{4}", region, name, hroom->name, *hroom->people, *hroom->cost);
	allroom->Close();
	delete allroom;
	delete i;
}
//===============================================================================
void CHotel::deleteRoom(StreamReader^ myhotel){
	String^ temp = gcnew String("");
	array<String^>^ words;
	array<String^>^ words2;
	int^ i = gcnew int(1);
	myhotel->ReadLine();	myhotel->ReadLine();	myhotel->ReadLine();
	myhotel->ReadLine();	myhotel->ReadLine();	temp=myhotel->ReadLine();
	words = temp->Split('\t');
	while (_Ture){
		if (*i<words->Length)
			break;
		words2 = words[(*i)++]->Split(' ');
		File::Delete("./sourse/room_descrip/" + words2[0] + ".txt");
	}
	delete temp;
	delete words, words2;
	delete i;
}
//===============================================================================
void CHotel::deleteFromFile(){
	String^ temp = gcnew String("");
	array<String^>^ words;
	StreamReader^ all = gcnew StreamReader("./sourse/allroom.txt");
	StreamWriter^ allr = gcnew StreamWriter("./sourse/allroom1.txt");
	
	while (!all->EndOfStream){
		temp = all->ReadLine();
		if (temp == "")
			break;
		words = temp->Split('\t');
		if (words[1] == name)
			continue;
		else
			allr->WriteLine(L"{0}", temp);
	}
	all->Close();
	allr->Close();
	File::Delete("./sourse/allroom.txt");
	File::Move("./sourse/allroom1.txt","./sourse/allroom.txt");
	delete all;
	delete allr;
	delete temp;
	delete words;
}
//===============================================================================