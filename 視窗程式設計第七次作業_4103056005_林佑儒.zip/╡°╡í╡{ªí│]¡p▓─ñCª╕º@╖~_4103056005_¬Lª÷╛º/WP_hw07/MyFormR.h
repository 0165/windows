/***************************
4103056005�L�����ĤC���@�~12/30
***************************/
#pragma once
#include "Hotel.h"
#include "Mydefine.h"
#include "Room.h"
namespace WP_hw07 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// MyFormR ���K�n
	/// </summary>
	public ref class MyFormR : public System::Windows::Forms::Form
	{
	public:
		MyFormR(void)
		{
			InitializeComponent();
			//
			//TODO:  �b���[�J�غc�禡�{���X
			//
		}
		CHotel^ usehotel;
		int roomcc;
	protected:
		/// <summary>
		/// �M������ϥΤ����귽�C
		/// </summary>
		~MyFormR()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  textBox_Rpeo;
	protected:

	protected:
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::Button^  button_NHok;
	private: System::Windows::Forms::TextBox^  textBox_Rinf;

	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::TextBox^  textBox_Rcost;

	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::TextBox^  textBox_Rnum;

	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::TextBox^  textBox_Rname;





	public: System::Windows::Forms::Label^  label1;

	protected:
		
	private:
		/// <summary>
		/// �]�p�u��һݪ��ܼơC
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// �����]�p�u��䴩�һݪ���k - �ФŨϥε{���X�s�边
		/// �ק�o�Ӥ�k�����e�C
		/// </summary>
		void InitializeComponent(void)
		{
			this->textBox_Rpeo = (gcnew System::Windows::Forms::TextBox());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->button_NHok = (gcnew System::Windows::Forms::Button());
			this->textBox_Rinf = (gcnew System::Windows::Forms::TextBox());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->textBox_Rcost = (gcnew System::Windows::Forms::TextBox());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->textBox_Rnum = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->textBox_Rname = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// textBox_Rpeo
			// 
			this->textBox_Rpeo->Location = System::Drawing::Point(334, 73);
			this->textBox_Rpeo->Name = L"textBox_Rpeo";
			this->textBox_Rpeo->Size = System::Drawing::Size(240, 22);
			this->textBox_Rpeo->TabIndex = 29;
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(332, 57);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(62, 12);
			this->label7->TabIndex = 28;
			this->label7->Text = L"�e�ǤH�� : ";
			// 
			// button_NHok
			// 
			this->button_NHok->Location = System::Drawing::Point(499, 266);
			this->button_NHok->Name = L"button_NHok";
			this->button_NHok->Size = System::Drawing::Size(75, 23);
			this->button_NHok->TabIndex = 27;
			this->button_NHok->Text = L"�񧹤F";
			this->button_NHok->UseVisualStyleBackColor = true;
			this->button_NHok->Click += gcnew System::EventHandler(this, &MyFormR::button_NHok_Click);
			// 
			// textBox_Rinf
			// 
			this->textBox_Rinf->Location = System::Drawing::Point(15, 120);
			this->textBox_Rinf->Multiline = true;
			this->textBox_Rinf->Name = L"textBox_Rinf";
			this->textBox_Rinf->Size = System::Drawing::Size(559, 140);
			this->textBox_Rinf->TabIndex = 26;
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(13, 104);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(62, 12);
			this->label6->TabIndex = 25;
			this->label6->Text = L"���]��T : ";
			// 
			// textBox_Rcost
			// 
			this->textBox_Rcost->Location = System::Drawing::Point(15, 73);
			this->textBox_Rcost->Name = L"textBox_Rcost";
			this->textBox_Rcost->Size = System::Drawing::Size(240, 22);
			this->textBox_Rcost->TabIndex = 24;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(13, 57);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(62, 12);
			this->label5->TabIndex = 23;
			this->label5->Text = L"�@�ߪ��B : ";
			// 
			// textBox_Rnum
			// 
			this->textBox_Rnum->Location = System::Drawing::Point(334, 32);
			this->textBox_Rnum->Name = L"textBox_Rnum";
			this->textBox_Rnum->Size = System::Drawing::Size(240, 22);
			this->textBox_Rnum->TabIndex = 22;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(332, 16);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(62, 12);
			this->label4->TabIndex = 21;
			this->label4->Text = L"�@���X�� : ";
			// 
			// textBox_Rname
			// 
			this->textBox_Rname->Location = System::Drawing::Point(15, 32);
			this->textBox_Rname->Name = L"textBox_Rname";
			this->textBox_Rname->Size = System::Drawing::Size(240, 22);
			this->textBox_Rname->TabIndex = 16;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(13, 16);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(62, 12);
			this->label1->TabIndex = 15;
			this->label1->Text = L"�ж��W�� : ";
			// 
			// MyFormR
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 12);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(592, 299);
			this->ControlBox = false;
			this->Controls->Add(this->textBox_Rpeo);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->button_NHok);
			this->Controls->Add(this->textBox_Rinf);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->textBox_Rcost);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->textBox_Rnum);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->textBox_Rname);
			this->Controls->Add(this->label1);
			this->MaximizeBox = false;
			this->MinimizeBox = false;
			this->Name = L"MyFormR";
			this->StartPosition = System::Windows::Forms::FormStartPosition::Manual;
			this->Text = L"MyFormR";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button_NHok_Click(System::Object^  sender, System::EventArgs^  e) {
		if (textBox_Rinf->Text == "" || textBox_Rnum->Text == "" || textBox_Rcost->Text == "" || textBox_Rpeo->Text == "" ||  textBox_Rname->Text == ""){
			MessageBox::Show("�C��Ҷ���");
			return Void();
		}
		usehotel->roomSet(roomcc,textBox_Rname->Text,textBox_Rnum->Text,textBox_Rpeo->Text,textBox_Rcost->Text,textBox_Rinf->Text);
		this->Close();
	}
};
}
