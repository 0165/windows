#pragma once // �O�Ҥޥ��� (*.h) �u�|�Q�ޥΤ@���A�p���N���ݭn�Ρu�ޤJ���@�v�F�C
#include "Mydefine.h"
#include "Date.h"
#include "Hotel.h"
//===============================================================================
ref class CGuest{
public:
	u_int^ rid;
	u_int^ people;
	bool^ pay;
	CDate^ usedate;
	String^	region;
	String^	name;
	CHotel^ use;
//===============================================================================
public:
	CGuest(void);
	~CGuest(void);
	int booking(String^, String^, String^, String^, String^, String^);						//booking hotel
	bool listroom(void);					//list the room that can be chose
	void cancelroom(String^, String^);					//cancel the booked room
	void payRoom(String^,String^);						//pay for the room
	bool listBroom(void);					//list the book room
private:
	void toFile(void);						//write to the file
	bool getCardInfor(void);				//get pay infor
};