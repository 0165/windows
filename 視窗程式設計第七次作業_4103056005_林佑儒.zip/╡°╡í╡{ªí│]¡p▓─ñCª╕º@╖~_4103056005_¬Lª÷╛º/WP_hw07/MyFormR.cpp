#include "stdafx.h"
#include "MyFormR.h"

