#pragma once // �O�Ҥޥ��� (*.h) �u�|�Q�ޥΤ@���A�p���N���ݭn�Ρu�ޤJ���@�v�F�C
#include "Room.h"
//===============================================================================
ref class CHotel{
public:
	String^	name;
	String^	city;
	String^	region;
	String^	country;
	String^	address;
	String^	infor;
	String^	allname;
	CRoom^	hroom;
//===============================================================================
public:
	CHotel();
	~CHotel();
	bool	check(u_int^, String^);		//check password, but didn't use
	bool	onScreen(void);				//show hotel infor
	void	toFile(void);				//write to file
	void	init(String^, String^, String^, String^, String^, String^);					//setup hotel infor
	void	modify(String^, String^, String^, String^, String^, String^);					//modify hotel infor
	void	roomSet(int, String^, String^, String^, String^, String^);			//setup room
//===============================================================================
private:
	u_int^	hid;						//hotel id
	String^	pw;							//password, but didn't use
//===============================================================================
private:
	void	gethid(void);				//get hotel id
	void	getOther(String^, String^, String^, String^, String^);			//get everything except hid and name
	void	deleteRoom(StreamReader^);	//delete all room
	void	deleteFromFile();			//delete all room form list
};