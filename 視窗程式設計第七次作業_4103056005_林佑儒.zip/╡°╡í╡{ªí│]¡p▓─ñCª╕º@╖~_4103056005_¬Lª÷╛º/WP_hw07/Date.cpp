#include "stdafx.h"
#include "Date.h"
//===============================================================================
CDate::CDate(void){
	rid = gcnew u_int;
	rlimete = gcnew u_int(0);
	count = gcnew bool(_False);
	year = gcnew int;
	mounth = gcnew int;
	day = gcnew int;
}
//===============================================================================
CDate::~CDate(void){
	delete year,mounth,day;
	delete rid, rlimete;
	delete count;
}
//===============================================================================
bool CDate::checkDate(void){
	System::DateTime^ ltm = gcnew System::DateTime;
	ltm = System::DateTime::Now;
	System::DateTime^ intime; 
	try{
		intime = gcnew System::DateTime(*year, *mounth, *day);
	}
	catch (Exception^ e){
		goto a;
	}
	if (*day > intime->DaysInMonth(*year, *mounth))
		goto a;
	if (*ltm >= *intime)
		goto a;
	delete  ltm,intime;
	return _Ture;
a:	
	delete  ltm,intime;
	return _False;
}
//===============================================================================
bool CDate::check(void){
	int^ gy, ^gm, ^gd,^gr,^gnum;
	gy = gcnew int;	gm = gcnew int;	*count = _False;
	gd = gcnew int;	gr = gcnew int;	gnum = gcnew int;
	array<String^>^ words;
	String^ temp = gcnew String("");
	StreamReader^ mydate = gcnew StreamReader("./sourse/date.txt");
	while (!mydate->EndOfStream){
		temp = mydate->ReadLine(); words = temp->Split(' ');
		*gr = Int32::Parse(words[0]);	*gy = Int32::Parse(words[1]);
		*gm = Int32::Parse(words[2]);	*gd = Int32::Parse(words[3]);	*gnum = Int32::Parse(words[4]);
		if ((*gr) == (*rid) && (*gy) == (*year) && (*gm) == (*mounth) && (*gd) == (*day))
			if ((*gnum) >= 1){
				*count = _False;
				break;
			}
			else
				goto a;
		else
			*count = _Ture;
	}
	mydate->Close();
	delete mydate;
	if ((*count) == _Ture)
		getRLimete();
	delete gy, gm, gd,gr,gnum;
	delete temp;
	delete[] words;
	return _Ture;
a:	
	mydate->Close();
	delete mydate;
	delete gy, gm, gd, gr, gnum;
	delete temp;
	delete[] words;
	return _False;
}
//===============================================================================
void CDate::toFile(int^ k){
	bool^ test = gcnew bool(_Ture);
	if (*count){
		StreamWriter^ mydate = gcnew StreamWriter("./sourse/date.txt",_Ture);
		mydate->WriteLine("{0} {1} {2} {3} {4}",*rid,*year,*mounth,*day,(*rlimete)-1);
		mydate->Close();
		delete mydate;
		return void();
	}
	array<String^>^ words;
	String^ temp = gcnew String("");
	StreamWriter^ use = gcnew StreamWriter("./sourse/date1.txt");
	StreamReader^ mydate = gcnew StreamReader("./sourse/date.txt");
	int^ gy, ^gm, ^gd, ^gr, ^gnum;
	gy = gcnew int;	gm = gcnew int;
	gd = gcnew int;	gr = gcnew int;	gnum = gcnew int;

	while (_Ture){
		if (mydate->EndOfStream)
			break;
		temp = mydate->ReadLine();	words = temp->Split(' ');
		*gr = Int32::Parse(words[0]);	*gy = Int32::Parse(words[1]);
		*gm = Int32::Parse(words[2]);	*gd = Int32::Parse(words[3]);	*gnum = Int32::Parse(words[4]);
		if (*test && (*gr) == (*rid) && (*gy) == (*year) && (*gm) == (*mounth) && (*gd) == (*day)){
			use->WriteLine("{0} {1} {2} {3} {4}", *rid, *year, *mounth, *day, (*gnum) + (*k));
			*test = _False;
		}
		else
			use->WriteLine("{0} {1} {2} {3} {4}", *gr, *gy, *gm, *gd, *gnum);
	}
	use->Close();
	mydate->Close();
	delete use;
	delete mydate;
	delete gy, gm, gd, gr, gnum;
	delete test;
	delete temp;
	delete[] words;
	File::Delete("./sourse/date.txt");
	File::Move("./sourse/date1.txt", "./sourse/date.txt");
}
//===============================================================================
void CDate::getRLimete(void){
	array<String^>^ words;
	String^ temp = gcnew String("");
	StreamReader^ mydate = gcnew StreamReader("./sourse/room_descrip/" + (*rid).ToString() + ".txt");
	temp=mydate->ReadLine();
	temp = mydate->ReadLine();
	temp = mydate->ReadLine();
	words = temp->Split('\t');
	*rlimete=UInt32::Parse(words[1]);
	mydate->Close();
	delete mydate;
	delete[] words;
	delete temp;
}
//===============================================================================