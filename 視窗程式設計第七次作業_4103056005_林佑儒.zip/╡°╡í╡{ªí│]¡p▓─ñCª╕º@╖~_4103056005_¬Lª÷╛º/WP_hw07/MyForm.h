/***************************
4103056005�L�����ĤC���@�~12/30
***************************/
#pragma once
#include "Hotel.h"
#include "Mydefine.h"
#include "Room.h"
#include "Guest.h"
#include "Date.h"
#include "MyFormR.h"
namespace WP_hw07 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// MyForm ���K�n
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO:  �b���[�J�غc�禡�{���X
			//
		}

	protected:
		/// <summary>
		/// �M������ϥΤ����귽�C
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TabControl^  tabControl1;
	protected:
	private: System::Windows::Forms::TabPage^  NewH;
	private: System::Windows::Forms::TextBox^  textBox_Hadd;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::TextBox^  textBox_Hcon;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::TextBox^  textBox_Hcit;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  textBox_Hreg;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  textBox_Hname;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::TabPage^  tabPage2;
	private: System::Windows::Forms::TabPage^  tabPage3;
	private: System::Windows::Forms::TabPage^  tabPage4;
	private: System::Windows::Forms::TextBox^  textBox_Hnum;
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::Button^  button_NHok;
	private: System::Windows::Forms::TextBox^  textBox_Hinf;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::TextBox^  textBox_MHnum;
	private: System::Windows::Forms::Label^  label8;
	private: System::Windows::Forms::Button^  button_MHok;
	private: System::Windows::Forms::TextBox^  textBox_MHinf;
	private: System::Windows::Forms::Label^  label9;
	private: System::Windows::Forms::TextBox^  textBox_MHadd;
	private: System::Windows::Forms::Label^  label10;
	private: System::Windows::Forms::TextBox^  textBox_MHcon;
	private: System::Windows::Forms::Label^  label11;
	private: System::Windows::Forms::TextBox^  textBox_MHcit;
	private: System::Windows::Forms::Label^  label12;
	private: System::Windows::Forms::TextBox^  textBox_MHreg;
	private: System::Windows::Forms::Label^  label13;
	private: System::Windows::Forms::TextBox^  textBox_MHname;
	private: System::Windows::Forms::Label^  label14;

	private: System::Windows::Forms::ComboBox^  comboBox_Greg;
	private: System::Windows::Forms::Label^  label15;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::TextBox^  textBox_Grinf;

	private: System::Windows::Forms::Label^  label16;

	private: System::Windows::Forms::Label^  label17;
	private: System::Windows::Forms::TextBox^  textBox_Gpeo;
	private: System::Windows::Forms::Label^  label18;

	private: System::Windows::Forms::Label^  label19;
	private: System::Windows::Forms::Label^  label20;
	private: System::Windows::Forms::TextBox^  textBox_Gnam;
	private: System::Windows::Forms::Label^  label21;
	private: System::Windows::Forms::DateTimePicker^  dateTimePicker_Gtim;
	private: System::Windows::Forms::ComboBox^  comboBox_Groom;
	private: System::Windows::Forms::ComboBox^  comboBox_Ghot;
	private: System::Windows::Forms::Button^  button_RoomCan;
	private: System::Windows::Forms::Button^  button_Nam_ok;
	private: System::Windows::Forms::ComboBox^  comboBox_MRCL;

	private: System::Windows::Forms::Label^  label24;
	private: System::Windows::Forms::TextBox^  textBox_MRinf;

	private: System::Windows::Forms::Label^  label23;
	private: System::Windows::Forms::TextBox^  textBox_MRnam;



	private: System::Windows::Forms::Label^  label22;
	private: System::Windows::Forms::TabPage^  tabPage1;


	private: System::Windows::Forms::Button^  button_PRN_ok;
	private: System::Windows::Forms::ComboBox^  comboBox_PRC;


	private: System::Windows::Forms::Label^  label25;
	private: System::Windows::Forms::TextBox^  textBox_PRinf;

	private: System::Windows::Forms::Label^  label26;
	private: System::Windows::Forms::TextBox^  textBox_PRnam;

	private: System::Windows::Forms::Label^  label27;
private: System::Windows::Forms::TextBox^  textBox_C4;
private: System::Windows::Forms::Label^  label32;
private: System::Windows::Forms::TextBox^  textBox_C3;
private: System::Windows::Forms::Label^  label31;
private: System::Windows::Forms::TextBox^  textBox_C2;
private: System::Windows::Forms::Label^  label30;
private: System::Windows::Forms::TextBox^  textBox_C1;
private: System::Windows::Forms::Button^  button_PRCN;
private: System::Windows::Forms::Label^  label29;

private: System::Windows::Forms::DateTimePicker^  dateTimePicker1;
private: System::Windows::Forms::Label^  label28;
private: System::Windows::Forms::TabPage^  tabPage5;
private: System::Windows::Forms::Button^  button_SH;
private: System::Windows::Forms::TextBox^  textBox_SHinf;
private: System::Windows::Forms::Label^  label33;
private: System::Windows::Forms::TextBox^  textBox_SHnam;
private: System::Windows::Forms::Label^  label34;


	protected:

	private:
		/// <summary>
		/// �]�p�u��һݪ��ܼơC
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// �����]�p�u��䴩�һݪ���k - �ФŨϥε{���X�s�边
		/// �ק�o�Ӥ�k�����e�C
		/// </summary>
		void InitializeComponent(void)
		{
			this->tabControl1 = (gcnew System::Windows::Forms::TabControl());
			this->NewH = (gcnew System::Windows::Forms::TabPage());
			this->textBox_Hnum = (gcnew System::Windows::Forms::TextBox());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->button_NHok = (gcnew System::Windows::Forms::Button());
			this->textBox_Hinf = (gcnew System::Windows::Forms::TextBox());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->textBox_Hadd = (gcnew System::Windows::Forms::TextBox());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->textBox_Hcon = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->textBox_Hcit = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->textBox_Hreg = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->textBox_Hname = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->tabPage2 = (gcnew System::Windows::Forms::TabPage());
			this->textBox_MHnum = (gcnew System::Windows::Forms::TextBox());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->button_MHok = (gcnew System::Windows::Forms::Button());
			this->textBox_MHinf = (gcnew System::Windows::Forms::TextBox());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->textBox_MHadd = (gcnew System::Windows::Forms::TextBox());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->textBox_MHcon = (gcnew System::Windows::Forms::TextBox());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->textBox_MHcit = (gcnew System::Windows::Forms::TextBox());
			this->label12 = (gcnew System::Windows::Forms::Label());
			this->textBox_MHreg = (gcnew System::Windows::Forms::TextBox());
			this->label13 = (gcnew System::Windows::Forms::Label());
			this->textBox_MHname = (gcnew System::Windows::Forms::TextBox());
			this->label14 = (gcnew System::Windows::Forms::Label());
			this->tabPage3 = (gcnew System::Windows::Forms::TabPage());
			this->comboBox_Groom = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox_Ghot = (gcnew System::Windows::Forms::ComboBox());
			this->dateTimePicker_Gtim = (gcnew System::Windows::Forms::DateTimePicker());
			this->comboBox_Greg = (gcnew System::Windows::Forms::ComboBox());
			this->label15 = (gcnew System::Windows::Forms::Label());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->textBox_Grinf = (gcnew System::Windows::Forms::TextBox());
			this->label16 = (gcnew System::Windows::Forms::Label());
			this->label17 = (gcnew System::Windows::Forms::Label());
			this->textBox_Gpeo = (gcnew System::Windows::Forms::TextBox());
			this->label18 = (gcnew System::Windows::Forms::Label());
			this->label19 = (gcnew System::Windows::Forms::Label());
			this->label20 = (gcnew System::Windows::Forms::Label());
			this->textBox_Gnam = (gcnew System::Windows::Forms::TextBox());
			this->label21 = (gcnew System::Windows::Forms::Label());
			this->tabPage4 = (gcnew System::Windows::Forms::TabPage());
			this->button_RoomCan = (gcnew System::Windows::Forms::Button());
			this->button_Nam_ok = (gcnew System::Windows::Forms::Button());
			this->comboBox_MRCL = (gcnew System::Windows::Forms::ComboBox());
			this->label24 = (gcnew System::Windows::Forms::Label());
			this->textBox_MRinf = (gcnew System::Windows::Forms::TextBox());
			this->label23 = (gcnew System::Windows::Forms::Label());
			this->textBox_MRnam = (gcnew System::Windows::Forms::TextBox());
			this->label22 = (gcnew System::Windows::Forms::Label());
			this->tabPage1 = (gcnew System::Windows::Forms::TabPage());
			this->textBox_C4 = (gcnew System::Windows::Forms::TextBox());
			this->label32 = (gcnew System::Windows::Forms::Label());
			this->textBox_C3 = (gcnew System::Windows::Forms::TextBox());
			this->label31 = (gcnew System::Windows::Forms::Label());
			this->textBox_C2 = (gcnew System::Windows::Forms::TextBox());
			this->label30 = (gcnew System::Windows::Forms::Label());
			this->textBox_C1 = (gcnew System::Windows::Forms::TextBox());
			this->button_PRCN = (gcnew System::Windows::Forms::Button());
			this->label29 = (gcnew System::Windows::Forms::Label());
			this->dateTimePicker1 = (gcnew System::Windows::Forms::DateTimePicker());
			this->label28 = (gcnew System::Windows::Forms::Label());
			this->button_PRN_ok = (gcnew System::Windows::Forms::Button());
			this->comboBox_PRC = (gcnew System::Windows::Forms::ComboBox());
			this->label25 = (gcnew System::Windows::Forms::Label());
			this->textBox_PRinf = (gcnew System::Windows::Forms::TextBox());
			this->label26 = (gcnew System::Windows::Forms::Label());
			this->textBox_PRnam = (gcnew System::Windows::Forms::TextBox());
			this->label27 = (gcnew System::Windows::Forms::Label());
			this->tabPage5 = (gcnew System::Windows::Forms::TabPage());
			this->button_SH = (gcnew System::Windows::Forms::Button());
			this->textBox_SHinf = (gcnew System::Windows::Forms::TextBox());
			this->label33 = (gcnew System::Windows::Forms::Label());
			this->textBox_SHnam = (gcnew System::Windows::Forms::TextBox());
			this->label34 = (gcnew System::Windows::Forms::Label());
			this->tabControl1->SuspendLayout();
			this->NewH->SuspendLayout();
			this->tabPage2->SuspendLayout();
			this->tabPage3->SuspendLayout();
			this->tabPage4->SuspendLayout();
			this->tabPage1->SuspendLayout();
			this->tabPage5->SuspendLayout();
			this->SuspendLayout();
			// 
			// tabControl1
			// 
			this->tabControl1->Controls->Add(this->NewH);
			this->tabControl1->Controls->Add(this->tabPage5);
			this->tabControl1->Controls->Add(this->tabPage2);
			this->tabControl1->Controls->Add(this->tabPage3);
			this->tabControl1->Controls->Add(this->tabPage4);
			this->tabControl1->Controls->Add(this->tabPage1);
			this->tabControl1->Location = System::Drawing::Point(2, 2);
			this->tabControl1->Name = L"tabControl1";
			this->tabControl1->SelectedIndex = 0;
			this->tabControl1->Size = System::Drawing::Size(604, 372);
			this->tabControl1->TabIndex = 0;
			this->tabControl1->Selecting += gcnew System::Windows::Forms::TabControlCancelEventHandler(this, &MyForm::tabControl1_Selecting);
			// 
			// NewH
			// 
			this->NewH->Controls->Add(this->textBox_Hnum);
			this->NewH->Controls->Add(this->label7);
			this->NewH->Controls->Add(this->button_NHok);
			this->NewH->Controls->Add(this->textBox_Hinf);
			this->NewH->Controls->Add(this->label6);
			this->NewH->Controls->Add(this->textBox_Hadd);
			this->NewH->Controls->Add(this->label5);
			this->NewH->Controls->Add(this->textBox_Hcon);
			this->NewH->Controls->Add(this->label4);
			this->NewH->Controls->Add(this->textBox_Hcit);
			this->NewH->Controls->Add(this->label3);
			this->NewH->Controls->Add(this->textBox_Hreg);
			this->NewH->Controls->Add(this->label2);
			this->NewH->Controls->Add(this->textBox_Hname);
			this->NewH->Controls->Add(this->label1);
			this->NewH->Location = System::Drawing::Point(4, 22);
			this->NewH->Name = L"NewH";
			this->NewH->Padding = System::Windows::Forms::Padding(3);
			this->NewH->Size = System::Drawing::Size(596, 346);
			this->NewH->TabIndex = 0;
			this->NewH->Text = L"�s�W���]��T";
			this->NewH->UseVisualStyleBackColor = true;
			// 
			// textBox_Hnum
			// 
			this->textBox_Hnum->Location = System::Drawing::Point(336, 121);
			this->textBox_Hnum->MaxLength = 5;
			this->textBox_Hnum->Name = L"textBox_Hnum";
			this->textBox_Hnum->Size = System::Drawing::Size(240, 22);
			this->textBox_Hnum->TabIndex = 14;
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(334, 105);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(62, 12);
			this->label7->TabIndex = 13;
			this->label7->Text = L"�Ы��ƥ� : ";
			// 
			// button_NHok
			// 
			this->button_NHok->Location = System::Drawing::Point(501, 314);
			this->button_NHok->Name = L"button_NHok";
			this->button_NHok->Size = System::Drawing::Size(75, 23);
			this->button_NHok->TabIndex = 12;
			this->button_NHok->Text = L"�񧹤F";
			this->button_NHok->UseVisualStyleBackColor = true;
			this->button_NHok->Click += gcnew System::EventHandler(this, &MyForm::button_NHok_Click);
			// 
			// textBox_Hinf
			// 
			this->textBox_Hinf->Location = System::Drawing::Point(17, 168);
			this->textBox_Hinf->Multiline = true;
			this->textBox_Hinf->Name = L"textBox_Hinf";
			this->textBox_Hinf->Size = System::Drawing::Size(559, 140);
			this->textBox_Hinf->TabIndex = 11;
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(15, 152);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(62, 12);
			this->label6->TabIndex = 10;
			this->label6->Text = L"���]��T : ";
			// 
			// textBox_Hadd
			// 
			this->textBox_Hadd->Location = System::Drawing::Point(17, 121);
			this->textBox_Hadd->Name = L"textBox_Hadd";
			this->textBox_Hadd->Size = System::Drawing::Size(240, 22);
			this->textBox_Hadd->TabIndex = 9;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(15, 105);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(62, 12);
			this->label5->TabIndex = 8;
			this->label5->Text = L"���]�a�} : ";
			// 
			// textBox_Hcon
			// 
			this->textBox_Hcon->Location = System::Drawing::Point(336, 30);
			this->textBox_Hcon->Name = L"textBox_Hcon";
			this->textBox_Hcon->Size = System::Drawing::Size(240, 22);
			this->textBox_Hcon->TabIndex = 7;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(334, 14);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(62, 12);
			this->label4->TabIndex = 6;
			this->label4->Text = L"�Ҧb��a : ";
			// 
			// textBox_Hcit
			// 
			this->textBox_Hcit->Location = System::Drawing::Point(336, 76);
			this->textBox_Hcit->Name = L"textBox_Hcit";
			this->textBox_Hcit->Size = System::Drawing::Size(240, 22);
			this->textBox_Hcit->TabIndex = 5;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(334, 60);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(62, 12);
			this->label3->TabIndex = 4;
			this->label3->Text = L"�Ҧb���� : ";
			// 
			// textBox_Hreg
			// 
			this->textBox_Hreg->Location = System::Drawing::Point(17, 76);
			this->textBox_Hreg->Name = L"textBox_Hreg";
			this->textBox_Hreg->Size = System::Drawing::Size(240, 22);
			this->textBox_Hreg->TabIndex = 3;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(15, 60);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(62, 12);
			this->label2->TabIndex = 2;
			this->label2->Text = L"���]�a�� : ";
			// 
			// textBox_Hname
			// 
			this->textBox_Hname->Location = System::Drawing::Point(17, 30);
			this->textBox_Hname->Name = L"textBox_Hname";
			this->textBox_Hname->Size = System::Drawing::Size(240, 22);
			this->textBox_Hname->TabIndex = 1;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(15, 14);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(62, 12);
			this->label1->TabIndex = 0;
			this->label1->Text = L"���]�W�� : ";
			// 
			// tabPage2
			// 
			this->tabPage2->Controls->Add(this->textBox_MHnum);
			this->tabPage2->Controls->Add(this->label8);
			this->tabPage2->Controls->Add(this->button_MHok);
			this->tabPage2->Controls->Add(this->textBox_MHinf);
			this->tabPage2->Controls->Add(this->label9);
			this->tabPage2->Controls->Add(this->textBox_MHadd);
			this->tabPage2->Controls->Add(this->label10);
			this->tabPage2->Controls->Add(this->textBox_MHcon);
			this->tabPage2->Controls->Add(this->label11);
			this->tabPage2->Controls->Add(this->textBox_MHcit);
			this->tabPage2->Controls->Add(this->label12);
			this->tabPage2->Controls->Add(this->textBox_MHreg);
			this->tabPage2->Controls->Add(this->label13);
			this->tabPage2->Controls->Add(this->textBox_MHname);
			this->tabPage2->Controls->Add(this->label14);
			this->tabPage2->Location = System::Drawing::Point(4, 22);
			this->tabPage2->Name = L"tabPage2";
			this->tabPage2->Padding = System::Windows::Forms::Padding(3);
			this->tabPage2->Size = System::Drawing::Size(596, 346);
			this->tabPage2->TabIndex = 1;
			this->tabPage2->Text = L"�ק���]��T";
			this->tabPage2->UseVisualStyleBackColor = true;
			// 
			// textBox_MHnum
			// 
			this->textBox_MHnum->Location = System::Drawing::Point(336, 121);
			this->textBox_MHnum->Name = L"textBox_MHnum";
			this->textBox_MHnum->Size = System::Drawing::Size(240, 22);
			this->textBox_MHnum->TabIndex = 29;
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Location = System::Drawing::Point(334, 105);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(62, 12);
			this->label8->TabIndex = 28;
			this->label8->Text = L"�Ы��ƥ� : ";
			// 
			// button_MHok
			// 
			this->button_MHok->Location = System::Drawing::Point(501, 314);
			this->button_MHok->Name = L"button_MHok";
			this->button_MHok->Size = System::Drawing::Size(75, 23);
			this->button_MHok->TabIndex = 27;
			this->button_MHok->Text = L"�񧹤F";
			this->button_MHok->UseVisualStyleBackColor = true;
			this->button_MHok->Click += gcnew System::EventHandler(this, &MyForm::button_MHok_Click);
			// 
			// textBox_MHinf
			// 
			this->textBox_MHinf->Location = System::Drawing::Point(17, 168);
			this->textBox_MHinf->Multiline = true;
			this->textBox_MHinf->Name = L"textBox_MHinf";
			this->textBox_MHinf->Size = System::Drawing::Size(559, 140);
			this->textBox_MHinf->TabIndex = 26;
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Location = System::Drawing::Point(15, 152);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(62, 12);
			this->label9->TabIndex = 25;
			this->label9->Text = L"���]��T : ";
			// 
			// textBox_MHadd
			// 
			this->textBox_MHadd->Location = System::Drawing::Point(17, 121);
			this->textBox_MHadd->Name = L"textBox_MHadd";
			this->textBox_MHadd->Size = System::Drawing::Size(240, 22);
			this->textBox_MHadd->TabIndex = 24;
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Location = System::Drawing::Point(15, 105);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(62, 12);
			this->label10->TabIndex = 23;
			this->label10->Text = L"���]�a�} : ";
			// 
			// textBox_MHcon
			// 
			this->textBox_MHcon->Location = System::Drawing::Point(336, 30);
			this->textBox_MHcon->Name = L"textBox_MHcon";
			this->textBox_MHcon->Size = System::Drawing::Size(240, 22);
			this->textBox_MHcon->TabIndex = 22;
			// 
			// label11
			// 
			this->label11->AutoSize = true;
			this->label11->Location = System::Drawing::Point(334, 14);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(62, 12);
			this->label11->TabIndex = 21;
			this->label11->Text = L"�Ҧb��a : ";
			// 
			// textBox_MHcit
			// 
			this->textBox_MHcit->Location = System::Drawing::Point(336, 76);
			this->textBox_MHcit->Name = L"textBox_MHcit";
			this->textBox_MHcit->Size = System::Drawing::Size(240, 22);
			this->textBox_MHcit->TabIndex = 20;
			// 
			// label12
			// 
			this->label12->AutoSize = true;
			this->label12->Location = System::Drawing::Point(334, 60);
			this->label12->Name = L"label12";
			this->label12->Size = System::Drawing::Size(62, 12);
			this->label12->TabIndex = 19;
			this->label12->Text = L"�Ҧb���� : ";
			// 
			// textBox_MHreg
			// 
			this->textBox_MHreg->Location = System::Drawing::Point(17, 76);
			this->textBox_MHreg->Name = L"textBox_MHreg";
			this->textBox_MHreg->Size = System::Drawing::Size(240, 22);
			this->textBox_MHreg->TabIndex = 18;
			// 
			// label13
			// 
			this->label13->AutoSize = true;
			this->label13->Location = System::Drawing::Point(15, 60);
			this->label13->Name = L"label13";
			this->label13->Size = System::Drawing::Size(62, 12);
			this->label13->TabIndex = 17;
			this->label13->Text = L"���]�a�� : ";
			// 
			// textBox_MHname
			// 
			this->textBox_MHname->Location = System::Drawing::Point(17, 30);
			this->textBox_MHname->Name = L"textBox_MHname";
			this->textBox_MHname->Size = System::Drawing::Size(240, 22);
			this->textBox_MHname->TabIndex = 16;
			// 
			// label14
			// 
			this->label14->AutoSize = true;
			this->label14->Location = System::Drawing::Point(15, 14);
			this->label14->Name = L"label14";
			this->label14->Size = System::Drawing::Size(62, 12);
			this->label14->TabIndex = 15;
			this->label14->Text = L"���]�W�� : ";
			// 
			// tabPage3
			// 
			this->tabPage3->Controls->Add(this->comboBox_Groom);
			this->tabPage3->Controls->Add(this->comboBox_Ghot);
			this->tabPage3->Controls->Add(this->dateTimePicker_Gtim);
			this->tabPage3->Controls->Add(this->comboBox_Greg);
			this->tabPage3->Controls->Add(this->label15);
			this->tabPage3->Controls->Add(this->button1);
			this->tabPage3->Controls->Add(this->textBox_Grinf);
			this->tabPage3->Controls->Add(this->label16);
			this->tabPage3->Controls->Add(this->label17);
			this->tabPage3->Controls->Add(this->textBox_Gpeo);
			this->tabPage3->Controls->Add(this->label18);
			this->tabPage3->Controls->Add(this->label19);
			this->tabPage3->Controls->Add(this->label20);
			this->tabPage3->Controls->Add(this->textBox_Gnam);
			this->tabPage3->Controls->Add(this->label21);
			this->tabPage3->Location = System::Drawing::Point(4, 22);
			this->tabPage3->Name = L"tabPage3";
			this->tabPage3->Size = System::Drawing::Size(596, 346);
			this->tabPage3->TabIndex = 2;
			this->tabPage3->Text = L"�q��";
			this->tabPage3->UseVisualStyleBackColor = true;
			// 
			// comboBox_Groom
			// 
			this->comboBox_Groom->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox_Groom->FormattingEnabled = true;
			this->comboBox_Groom->Location = System::Drawing::Point(17, 121);
			this->comboBox_Groom->Name = L"comboBox_Groom";
			this->comboBox_Groom->Size = System::Drawing::Size(240, 20);
			this->comboBox_Groom->TabIndex = 33;
			this->comboBox_Groom->SelectedIndexChanged += gcnew System::EventHandler(this, &MyForm::comboBox_Groom_SelectedIndexChanged);
			// 
			// comboBox_Ghot
			// 
			this->comboBox_Ghot->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox_Ghot->FormattingEnabled = true;
			this->comboBox_Ghot->Location = System::Drawing::Point(336, 76);
			this->comboBox_Ghot->Name = L"comboBox_Ghot";
			this->comboBox_Ghot->Size = System::Drawing::Size(240, 20);
			this->comboBox_Ghot->TabIndex = 32;
			this->comboBox_Ghot->SelectedIndexChanged += gcnew System::EventHandler(this, &MyForm::comboBox_Ghot_SelectedIndexChanged);
			// 
			// dateTimePicker_Gtim
			// 
			this->dateTimePicker_Gtim->CustomFormat = L"yyyy/MM/dd";
			this->dateTimePicker_Gtim->Format = System::Windows::Forms::DateTimePickerFormat::Custom;
			this->dateTimePicker_Gtim->Location = System::Drawing::Point(336, 121);
			this->dateTimePicker_Gtim->MinDate = System::DateTime(2016, 12, 28, 8, 20, 12, 490);
			this->dateTimePicker_Gtim->Name = L"dateTimePicker_Gtim";
			this->dateTimePicker_Gtim->Size = System::Drawing::Size(240, 22);
			this->dateTimePicker_Gtim->TabIndex = 31;
			this->dateTimePicker_Gtim->Value = System::DateTime(2016, 12, 28, 8, 20, 12, 490);
			// 
			// comboBox_Greg
			// 
			this->comboBox_Greg->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox_Greg->FormattingEnabled = true;
			this->comboBox_Greg->Location = System::Drawing::Point(17, 76);
			this->comboBox_Greg->Name = L"comboBox_Greg";
			this->comboBox_Greg->Size = System::Drawing::Size(240, 20);
			this->comboBox_Greg->TabIndex = 30;
			this->comboBox_Greg->SelectedIndexChanged += gcnew System::EventHandler(this, &MyForm::comboBox_Greg_SelectedIndexChanged);
			// 
			// label15
			// 
			this->label15->AutoSize = true;
			this->label15->Location = System::Drawing::Point(334, 105);
			this->label15->Name = L"label15";
			this->label15->Size = System::Drawing::Size(62, 12);
			this->label15->TabIndex = 28;
			this->label15->Text = L"�J����� : ";
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(501, 314);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 27;
			this->button1->Text = L"�T�w�q��";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// textBox_Grinf
			// 
			this->textBox_Grinf->Enabled = false;
			this->textBox_Grinf->Location = System::Drawing::Point(17, 168);
			this->textBox_Grinf->Multiline = true;
			this->textBox_Grinf->Name = L"textBox_Grinf";
			this->textBox_Grinf->ReadOnly = true;
			this->textBox_Grinf->Size = System::Drawing::Size(559, 140);
			this->textBox_Grinf->TabIndex = 26;
			// 
			// label16
			// 
			this->label16->AutoSize = true;
			this->label16->Location = System::Drawing::Point(15, 152);
			this->label16->Name = L"label16";
			this->label16->Size = System::Drawing::Size(62, 12);
			this->label16->TabIndex = 25;
			this->label16->Text = L"�ж���T : ";
			// 
			// label17
			// 
			this->label17->AutoSize = true;
			this->label17->Location = System::Drawing::Point(15, 105);
			this->label17->Name = L"label17";
			this->label17->Size = System::Drawing::Size(74, 12);
			this->label17->TabIndex = 23;
			this->label17->Text = L"�i�諸�Ы� : ";
			// 
			// textBox_Gpeo
			// 
			this->textBox_Gpeo->Location = System::Drawing::Point(336, 30);
			this->textBox_Gpeo->Name = L"textBox_Gpeo";
			this->textBox_Gpeo->Size = System::Drawing::Size(240, 22);
			this->textBox_Gpeo->TabIndex = 22;
			// 
			// label18
			// 
			this->label18->AutoSize = true;
			this->label18->Location = System::Drawing::Point(334, 14);
			this->label18->Name = L"label18";
			this->label18->Size = System::Drawing::Size(62, 12);
			this->label18->TabIndex = 21;
			this->label18->Text = L"���J�H�� : ";
			// 
			// label19
			// 
			this->label19->AutoSize = true;
			this->label19->Location = System::Drawing::Point(334, 60);
			this->label19->Name = L"label19";
			this->label19->Size = System::Drawing::Size(74, 12);
			this->label19->TabIndex = 19;
			this->label19->Text = L"�i�諸���] : ";
			// 
			// label20
			// 
			this->label20->AutoSize = true;
			this->label20->Location = System::Drawing::Point(15, 60);
			this->label20->Name = L"label20";
			this->label20->Size = System::Drawing::Size(62, 12);
			this->label20->TabIndex = 17;
			this->label20->Text = L"���]�a�� : ";
			// 
			// textBox_Gnam
			// 
			this->textBox_Gnam->Location = System::Drawing::Point(17, 30);
			this->textBox_Gnam->Name = L"textBox_Gnam";
			this->textBox_Gnam->Size = System::Drawing::Size(240, 22);
			this->textBox_Gnam->TabIndex = 16;
			// 
			// label21
			// 
			this->label21->AutoSize = true;
			this->label21->Location = System::Drawing::Point(15, 14);
			this->label21->Name = L"label21";
			this->label21->Size = System::Drawing::Size(62, 12);
			this->label21->TabIndex = 15;
			this->label21->Text = L"�A���W�r : ";
			// 
			// tabPage4
			// 
			this->tabPage4->Controls->Add(this->button_RoomCan);
			this->tabPage4->Controls->Add(this->button_Nam_ok);
			this->tabPage4->Controls->Add(this->comboBox_MRCL);
			this->tabPage4->Controls->Add(this->label24);
			this->tabPage4->Controls->Add(this->textBox_MRinf);
			this->tabPage4->Controls->Add(this->label23);
			this->tabPage4->Controls->Add(this->textBox_MRnam);
			this->tabPage4->Controls->Add(this->label22);
			this->tabPage4->Location = System::Drawing::Point(4, 22);
			this->tabPage4->Name = L"tabPage4";
			this->tabPage4->Size = System::Drawing::Size(596, 346);
			this->tabPage4->TabIndex = 3;
			this->tabPage4->Text = L"�d�ݭq�и�T�P����";
			this->tabPage4->UseVisualStyleBackColor = true;
			// 
			// button_RoomCan
			// 
			this->button_RoomCan->Enabled = false;
			this->button_RoomCan->Location = System::Drawing::Point(415, 291);
			this->button_RoomCan->Name = L"button_RoomCan";
			this->button_RoomCan->Size = System::Drawing::Size(75, 23);
			this->button_RoomCan->TabIndex = 35;
			this->button_RoomCan->Text = L"�T�{�R��";
			this->button_RoomCan->UseVisualStyleBackColor = true;
			this->button_RoomCan->Click += gcnew System::EventHandler(this, &MyForm::button_RoomCan_Click);
			// 
			// button_Nam_ok
			// 
			this->button_Nam_ok->Location = System::Drawing::Point(415, 29);
			this->button_Nam_ok->Name = L"button_Nam_ok";
			this->button_Nam_ok->Size = System::Drawing::Size(75, 23);
			this->button_Nam_ok->TabIndex = 34;
			this->button_Nam_ok->Text = L"�T�{��J";
			this->button_Nam_ok->UseVisualStyleBackColor = true;
			this->button_Nam_ok->Click += gcnew System::EventHandler(this, &MyForm::button_Nam_ok_Click);
			// 
			// comboBox_MRCL
			// 
			this->comboBox_MRCL->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox_MRCL->FormattingEnabled = true;
			this->comboBox_MRCL->Location = System::Drawing::Point(17, 291);
			this->comboBox_MRCL->Name = L"comboBox_MRCL";
			this->comboBox_MRCL->Size = System::Drawing::Size(349, 20);
			this->comboBox_MRCL->TabIndex = 33;
			// 
			// label24
			// 
			this->label24->AutoSize = true;
			this->label24->Location = System::Drawing::Point(15, 275);
			this->label24->Name = L"label24";
			this->label24->Size = System::Drawing::Size(62, 12);
			this->label24->TabIndex = 29;
			this->label24->Text = L"�����q�� : ";
			// 
			// textBox_MRinf
			// 
			this->textBox_MRinf->Enabled = false;
			this->textBox_MRinf->Location = System::Drawing::Point(17, 76);
			this->textBox_MRinf->Multiline = true;
			this->textBox_MRinf->Name = L"textBox_MRinf";
			this->textBox_MRinf->ReadOnly = true;
			this->textBox_MRinf->Size = System::Drawing::Size(559, 182);
			this->textBox_MRinf->TabIndex = 28;
			// 
			// label23
			// 
			this->label23->AutoSize = true;
			this->label23->Location = System::Drawing::Point(15, 60);
			this->label23->Name = L"label23";
			this->label23->Size = System::Drawing::Size(62, 12);
			this->label23->TabIndex = 27;
			this->label23->Text = L"�q�и�T : ";
			// 
			// textBox_MRnam
			// 
			this->textBox_MRnam->Location = System::Drawing::Point(17, 30);
			this->textBox_MRnam->Name = L"textBox_MRnam";
			this->textBox_MRnam->Size = System::Drawing::Size(349, 22);
			this->textBox_MRnam->TabIndex = 18;
			// 
			// label22
			// 
			this->label22->AutoSize = true;
			this->label22->Location = System::Drawing::Point(15, 14);
			this->label22->Name = L"label22";
			this->label22->Size = System::Drawing::Size(62, 12);
			this->label22->TabIndex = 17;
			this->label22->Text = L"�A���W�r : ";
			// 
			// tabPage1
			// 
			this->tabPage1->Controls->Add(this->textBox_C4);
			this->tabPage1->Controls->Add(this->label32);
			this->tabPage1->Controls->Add(this->textBox_C3);
			this->tabPage1->Controls->Add(this->label31);
			this->tabPage1->Controls->Add(this->textBox_C2);
			this->tabPage1->Controls->Add(this->label30);
			this->tabPage1->Controls->Add(this->textBox_C1);
			this->tabPage1->Controls->Add(this->button_PRCN);
			this->tabPage1->Controls->Add(this->label29);
			this->tabPage1->Controls->Add(this->dateTimePicker1);
			this->tabPage1->Controls->Add(this->label28);
			this->tabPage1->Controls->Add(this->button_PRN_ok);
			this->tabPage1->Controls->Add(this->comboBox_PRC);
			this->tabPage1->Controls->Add(this->label25);
			this->tabPage1->Controls->Add(this->textBox_PRinf);
			this->tabPage1->Controls->Add(this->label26);
			this->tabPage1->Controls->Add(this->textBox_PRnam);
			this->tabPage1->Controls->Add(this->label27);
			this->tabPage1->Location = System::Drawing::Point(4, 22);
			this->tabPage1->Name = L"tabPage1";
			this->tabPage1->Padding = System::Windows::Forms::Padding(3);
			this->tabPage1->Size = System::Drawing::Size(596, 346);
			this->tabPage1->TabIndex = 4;
			this->tabPage1->Text = L"�I�O";
			this->tabPage1->UseVisualStyleBackColor = true;
			// 
			// textBox_C4
			// 
			this->textBox_C4->Location = System::Drawing::Point(284, 310);
			this->textBox_C4->MaxLength = 4;
			this->textBox_C4->Name = L"textBox_C4";
			this->textBox_C4->Size = System::Drawing::Size(60, 22);
			this->textBox_C4->TabIndex = 56;
			// 
			// label32
			// 
			this->label32->AutoSize = true;
			this->label32->Location = System::Drawing::Point(261, 315);
			this->label32->Name = L"label32";
			this->label32->Size = System::Drawing::Size(17, 12);
			this->label32->TabIndex = 55;
			this->label32->Text = L"�@";
			// 
			// textBox_C3
			// 
			this->textBox_C3->Location = System::Drawing::Point(195, 310);
			this->textBox_C3->MaxLength = 4;
			this->textBox_C3->Name = L"textBox_C3";
			this->textBox_C3->Size = System::Drawing::Size(60, 22);
			this->textBox_C3->TabIndex = 54;
			// 
			// label31
			// 
			this->label31->AutoSize = true;
			this->label31->Location = System::Drawing::Point(172, 315);
			this->label31->Name = L"label31";
			this->label31->Size = System::Drawing::Size(17, 12);
			this->label31->TabIndex = 53;
			this->label31->Text = L"�@";
			// 
			// textBox_C2
			// 
			this->textBox_C2->Location = System::Drawing::Point(106, 310);
			this->textBox_C2->MaxLength = 4;
			this->textBox_C2->Name = L"textBox_C2";
			this->textBox_C2->Size = System::Drawing::Size(60, 22);
			this->textBox_C2->TabIndex = 52;
			// 
			// label30
			// 
			this->label30->AutoSize = true;
			this->label30->Location = System::Drawing::Point(83, 315);
			this->label30->Name = L"label30";
			this->label30->Size = System::Drawing::Size(17, 12);
			this->label30->TabIndex = 51;
			this->label30->Text = L"�@";
			// 
			// textBox_C1
			// 
			this->textBox_C1->Location = System::Drawing::Point(17, 310);
			this->textBox_C1->MaxLength = 4;
			this->textBox_C1->Name = L"textBox_C1";
			this->textBox_C1->Size = System::Drawing::Size(60, 22);
			this->textBox_C1->TabIndex = 50;
			// 
			// button_PRCN
			// 
			this->button_PRCN->Enabled = false;
			this->button_PRCN->Location = System::Drawing::Point(415, 310);
			this->button_PRCN->Name = L"button_PRCN";
			this->button_PRCN->Size = System::Drawing::Size(98, 23);
			this->button_PRCN->TabIndex = 49;
			this->button_PRCN->Text = L"�T�w�I�O";
			this->button_PRCN->UseVisualStyleBackColor = true;
			this->button_PRCN->Click += gcnew System::EventHandler(this, &MyForm::button_PRCN_Click);
			// 
			// label29
			// 
			this->label29->AutoSize = true;
			this->label29->Location = System::Drawing::Point(15, 295);
			this->label29->Name = L"label29";
			this->label29->Size = System::Drawing::Size(62, 12);
			this->label29->TabIndex = 47;
			this->label29->Text = L"��ܥI�O : ";
			// 
			// dateTimePicker1
			// 
			this->dateTimePicker1->CustomFormat = L"yyyy/MM/dd";
			this->dateTimePicker1->Format = System::Windows::Forms::DateTimePickerFormat::Custom;
			this->dateTimePicker1->Location = System::Drawing::Point(17, 270);
			this->dateTimePicker1->MinDate = System::DateTime(2016, 12, 28, 8, 20, 12, 644);
			this->dateTimePicker1->Name = L"dateTimePicker1";
			this->dateTimePicker1->Size = System::Drawing::Size(327, 22);
			this->dateTimePicker1->TabIndex = 45;
			this->dateTimePicker1->Value = System::DateTime(2016, 12, 28, 8, 20, 12, 644);
			// 
			// label28
			// 
			this->label28->AutoSize = true;
			this->label28->Location = System::Drawing::Point(15, 254);
			this->label28->Name = L"label28";
			this->label28->Size = System::Drawing::Size(86, 12);
			this->label28->TabIndex = 44;
			this->label28->Text = L"�d�������� : ";
			// 
			// button_PRN_ok
			// 
			this->button_PRN_ok->Location = System::Drawing::Point(415, 29);
			this->button_PRN_ok->Name = L"button_PRN_ok";
			this->button_PRN_ok->Size = System::Drawing::Size(75, 23);
			this->button_PRN_ok->TabIndex = 42;
			this->button_PRN_ok->Text = L"�T�{��J";
			this->button_PRN_ok->UseVisualStyleBackColor = true;
			this->button_PRN_ok->Click += gcnew System::EventHandler(this, &MyForm::button_PRN_ok_Click);
			// 
			// comboBox_PRC
			// 
			this->comboBox_PRC->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox_PRC->FormattingEnabled = true;
			this->comboBox_PRC->Location = System::Drawing::Point(17, 229);
			this->comboBox_PRC->Name = L"comboBox_PRC";
			this->comboBox_PRC->Size = System::Drawing::Size(327, 20);
			this->comboBox_PRC->TabIndex = 41;
			// 
			// label25
			// 
			this->label25->AutoSize = true;
			this->label25->Location = System::Drawing::Point(15, 213);
			this->label25->Name = L"label25";
			this->label25->Size = System::Drawing::Size(62, 12);
			this->label25->TabIndex = 40;
			this->label25->Text = L"��ܥI�O : ";
			// 
			// textBox_PRinf
			// 
			this->textBox_PRinf->Enabled = false;
			this->textBox_PRinf->Location = System::Drawing::Point(17, 76);
			this->textBox_PRinf->Multiline = true;
			this->textBox_PRinf->Name = L"textBox_PRinf";
			this->textBox_PRinf->ReadOnly = true;
			this->textBox_PRinf->Size = System::Drawing::Size(559, 129);
			this->textBox_PRinf->TabIndex = 39;
			// 
			// label26
			// 
			this->label26->AutoSize = true;
			this->label26->Location = System::Drawing::Point(15, 60);
			this->label26->Name = L"label26";
			this->label26->Size = System::Drawing::Size(62, 12);
			this->label26->TabIndex = 38;
			this->label26->Text = L"�q�и�T : ";
			// 
			// textBox_PRnam
			// 
			this->textBox_PRnam->Location = System::Drawing::Point(17, 30);
			this->textBox_PRnam->Name = L"textBox_PRnam";
			this->textBox_PRnam->Size = System::Drawing::Size(327, 22);
			this->textBox_PRnam->TabIndex = 37;
			// 
			// label27
			// 
			this->label27->AutoSize = true;
			this->label27->Location = System::Drawing::Point(15, 14);
			this->label27->Name = L"label27";
			this->label27->Size = System::Drawing::Size(62, 12);
			this->label27->TabIndex = 36;
			this->label27->Text = L"�A���W�r : ";
			// 
			// tabPage5
			// 
			this->tabPage5->Controls->Add(this->button_SH);
			this->tabPage5->Controls->Add(this->textBox_SHinf);
			this->tabPage5->Controls->Add(this->label33);
			this->tabPage5->Controls->Add(this->textBox_SHnam);
			this->tabPage5->Controls->Add(this->label34);
			this->tabPage5->Location = System::Drawing::Point(4, 22);
			this->tabPage5->Name = L"tabPage5";
			this->tabPage5->Size = System::Drawing::Size(596, 346);
			this->tabPage5->TabIndex = 5;
			this->tabPage5->Text = L"�d�ݶ�����T";
			this->tabPage5->UseVisualStyleBackColor = true;
			// 
			// button_SH
			// 
			this->button_SH->Location = System::Drawing::Point(415, 29);
			this->button_SH->Name = L"button_SH";
			this->button_SH->Size = System::Drawing::Size(75, 23);
			this->button_SH->TabIndex = 39;
			this->button_SH->Text = L"�T�{��J";
			this->button_SH->UseVisualStyleBackColor = true;
			this->button_SH->Click += gcnew System::EventHandler(this, &MyForm::button_SH_Click);
			// 
			// textBox_SHinf
			// 
			this->textBox_SHinf->Enabled = false;
			this->textBox_SHinf->Location = System::Drawing::Point(17, 76);
			this->textBox_SHinf->Multiline = true;
			this->textBox_SHinf->Name = L"textBox_SHinf";
			this->textBox_SHinf->ReadOnly = true;
			this->textBox_SHinf->Size = System::Drawing::Size(559, 182);
			this->textBox_SHinf->TabIndex = 38;
			// 
			// label33
			// 
			this->label33->AutoSize = true;
			this->label33->Location = System::Drawing::Point(15, 60);
			this->label33->Name = L"label33";
			this->label33->Size = System::Drawing::Size(62, 12);
			this->label33->TabIndex = 37;
			this->label33->Text = L"������T : ";
			// 
			// textBox_SHnam
			// 
			this->textBox_SHnam->Location = System::Drawing::Point(17, 30);
			this->textBox_SHnam->Name = L"textBox_SHnam";
			this->textBox_SHnam->Size = System::Drawing::Size(349, 22);
			this->textBox_SHnam->TabIndex = 36;
			// 
			// label34
			// 
			this->label34->AutoSize = true;
			this->label34->Location = System::Drawing::Point(15, 14);
			this->label34->Name = L"label34";
			this->label34->Size = System::Drawing::Size(62, 12);
			this->label34->TabIndex = 35;
			this->label34->Text = L"�����W�r : ";
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 12);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(608, 377);
			this->Controls->Add(this->tabControl1);
			this->MaximizeBox = false;
			this->MinimizeBox = false;
			this->Name = L"MyForm";
			this->Text = L"MyForm";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			this->tabControl1->ResumeLayout(false);
			this->NewH->ResumeLayout(false);
			this->NewH->PerformLayout();
			this->tabPage2->ResumeLayout(false);
			this->tabPage2->PerformLayout();
			this->tabPage3->ResumeLayout(false);
			this->tabPage3->PerformLayout();
			this->tabPage4->ResumeLayout(false);
			this->tabPage4->PerformLayout();
			this->tabPage1->ResumeLayout(false);
			this->tabPage1->PerformLayout();
			this->tabPage5->ResumeLayout(false);
			this->tabPage5->PerformLayout();
			this->ResumeLayout(false);

		}
#pragma endregion
	
	private: System::Void button_RoomCan_Click(System::Object^  sender, System::EventArgs^  e) {
		CGuest^ useguest = gcnew CGuest();
		useguest->cancelroom(textBox_MRnam->Text,comboBox_MRCL->Text);
		MessageBox::Show("�R�����\");
		comboBox_MRCL->Items->Clear();
		comboBox_MRCL->Text="";
		textBox_MRinf->Text = "";
		button_RoomCan->Enabled = false;
	}
//===============================================================================
	private: System::Void button_NHok_Click(System::Object^  sender, System::EventArgs^  e) {
		if (textBox_Hinf->Text == "" || textBox_Hnum->Text == "" || textBox_Hreg->Text == "" || textBox_Hcit->Text == "" || textBox_Hcon->Text == "" || textBox_Hadd->Text == "" || textBox_Hname->Text == ""){
			MessageBox::Show("�C��Ҷ���");
			return Void();
		}
		CHotel^ usehotel = gcnew CHotel();
		usehotel->init(textBox_Hname->Text, textBox_Hreg->Text, textBox_Hcon->Text, textBox_Hcit->Text, textBox_Hadd->Text, textBox_Hinf->Text);
		int ii = Int32::Parse(textBox_Hnum->Text);
		for (int i = 0; i < ii;){
			MyFormR ^ setroom= gcnew MyFormR();
			setroom->usehotel = usehotel;
			setroom->roomcc = i;
			setroom->label1->Text = "room" + (++i).ToString() + "�W��";
			setroom->Location = Point(this->Location.X, this->Location.Y);
			setroom->ShowDialog();
			delete setroom;
		}
		usehotel->toFile();
		textBox_Hinf->Text = "";	textBox_Hnum->Text = "";	textBox_Hreg->Text = "";
		textBox_Hcit->Text = "";	textBox_Hcon->Text = "";	 textBox_Hadd->Text = "";	textBox_Hname->Text = "";
		MessageBox::Show("�ק令�\");
		delete usehotel;
	}
//===============================================================================
	private: System::Void button_MHok_Click(System::Object^  sender, System::EventArgs^  e) {
		if (textBox_MHinf->Text == "" || textBox_MHnum->Text == "" || textBox_MHreg->Text == "" || textBox_MHcit->Text == "" || textBox_MHcon->Text == "" || textBox_MHadd->Text == "" || textBox_MHname->Text == ""){
			MessageBox::Show("�C��Ҷ���");
			return Void();
		}
		CHotel^ usehotel = gcnew CHotel();
		usehotel->init(textBox_MHname->Text, textBox_MHreg->Text, textBox_MHcon->Text, textBox_MHcit->Text, textBox_MHadd->Text, textBox_MHinf->Text);
		int ii = Int32::Parse(textBox_MHnum->Text);
		for (int i = 0; i < ii;){
			MyFormR ^ setroom = gcnew MyFormR();
			setroom->usehotel = usehotel;
			setroom->roomcc = i;
			setroom->label1->Text = "room"+(++i).ToString()+"�W��";
			setroom->Location= Point(this->Location.X, this->Location.Y);
			setroom->ShowDialog();
			delete setroom;
		}
		usehotel->toFile();
		textBox_MHinf->Text = "";	textBox_MHnum->Text = "";	textBox_MHreg->Text = "";
		textBox_MHcit->Text = "";	textBox_MHcon->Text = "";	textBox_MHadd->Text = "";	textBox_MHname->Text = "";
		MessageBox::Show("�ק令�\");
		delete usehotel;
	}
//===============================================================================
	private: System::Void MyForm_Load(System::Object^  sender, System::EventArgs^  e) {
		dateTimePicker_Gtim->MinDate = System::DateTime::Now.AddDays(1);
		dateTimePicker1->MinDate = System::DateTime::Now.AddDays(1);
	}
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
		if (textBox_Gnam->Text == "" || textBox_Gpeo->Text == "" || comboBox_Greg->Text == "" || comboBox_Ghot->Text == "" || comboBox_Groom->Text == "" ){
			MessageBox::Show("�C��Ҷ���");
			return Void();
		}
		array<String^>^ words;
		CGuest^ useguest = gcnew CGuest();
		words = comboBox_Groom->Text->Split(' ');
		switch (useguest->booking(textBox_Gnam->Text, textBox_Gpeo->Text, words[0], dateTimePicker_Gtim->Text,comboBox_Greg->Text,comboBox_Ghot->Text)){
			case 10:
				MessageBox::Show("�H�ƶW�L�ж��W��");
				return Void();
			case 1:
				MessageBox::Show("�q�Ц��\");
				break;
			case -1:
				MessageBox::Show("���馹�ж��w�w��");
				return Void();
		}
		textBox_Gnam->Text = "";	textBox_Gpeo->Text = ""; textBox_Grinf->Text = "";
		comboBox_Greg->Items->Clear();		comboBox_Ghot->Items->Clear();		comboBox_Groom->Items->Clear();
		comboBox_Greg->Text="";		comboBox_Ghot->Text="";		comboBox_Groom->Text="";
	}
	private: System::Void comboBox_Greg_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
		comboBox_Ghot->Items->Clear();
		comboBox_Groom->Items->Clear();
		StreamReader^ myguest = gcnew StreamReader("./sourse/allroom.txt");
		array<String^>^ words;
		String^ temp = gcnew String("");
		while (!myguest->EndOfStream){
			temp = myguest->ReadLine();
			if (temp == "")
				break;
			words = temp->Split('\t');
			if (comboBox_Greg->Text==words[0] && !comboBox_Ghot->Items->Contains(words[1])){
				comboBox_Ghot->Items->Add(words[1]);
			}
		}
		myguest->Close();
		delete temp;
		delete myguest;
	}
	private: System::Void tabControl1_Selecting(System::Object^  sender, System::Windows::Forms::TabControlCancelEventArgs^  e) {
		comboBox_Greg->Items->Clear(); 
		comboBox_Ghot->Items->Clear();
		comboBox_Groom->Items->Clear();
		StreamReader^ myguest = gcnew StreamReader("./sourse/allroom.txt");
		array<String^>^ words;
		String^ temp = gcnew String("");
		while (!myguest->EndOfStream){
			temp = myguest->ReadLine();
			if (temp == "")
				break;
			words = temp->Split('\t');
			if (!comboBox_Greg->Items->Contains(words[0])){
				comboBox_Greg->Items->Add(words[0]);
			}
		}
		myguest->Close();
		delete temp;
		delete myguest;
	}
	private: System::Void comboBox_Ghot_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
		comboBox_Groom->Items->Clear();
		label16->Text = "������T";
		StreamReader^ myguest = gcnew StreamReader("./sourse/hotel_descrip/" + comboBox_Ghot->Text + ".txt");
		array<String^>^ words;
		String^ temp = gcnew String("");
		while (!myguest->EndOfStream){
			temp = myguest->ReadLine();
			if (temp == "")
				break;
			words = temp->Split('\t');
			if (words[0]=="rooms:"){
				for (int i = 1; i<words->Length; i++)
					comboBox_Groom->Items->Add(words[i]);
				break;
			}
		}
		myguest->Close();
		delete temp;
		delete myguest;
		myguest = gcnew StreamReader("./sourse/hotel_descrip/" + comboBox_Ghot->Text+".txt");
		myguest->ReadLine();
		textBox_Grinf->Text = myguest->ReadToEnd();
		myguest->Close();
		delete myguest;
	}
	private: System::Void comboBox_Groom_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
		label16->Text = "�ж���T";
		array<String^>^ words;
		words = comboBox_Groom->Text->Split(' ');
		StreamReader^ myguest = gcnew StreamReader("./sourse/room_descrip/" + words[0] + ".txt");
		myguest->ReadLine();
		textBox_Grinf->Text = myguest->ReadToEnd();
		myguest->Close();
		delete myguest;
	}
	private: System::Void button_Nam_ok_Click(System::Object^  sender, System::EventArgs^  e) {
		if (textBox_MRnam->Text == ""){
			MessageBox::Show("����J�W�r");
			return Void();
		}
		StreamReader^ myguest;
		try{
			myguest = gcnew StreamReader("./sourse/guest_descrip/" + textBox_MRnam->Text + ".txt");
		}
		catch (Exception^ e){
			MessageBox::Show("�z�q���q�L��");
			return Void();
		}
		String^ temp;
		try{
			do{
				temp = myguest->ReadLine();
				comboBox_MRCL->Items->Add(temp);
			} while (!myguest->EndOfStream);
			myguest->Close();
		}
		catch (Exception^ e){
			delete myguest;
			MessageBox::Show("�z�ثe�S�w����ж�");
			return Void();
		}
		delete myguest;
		myguest = gcnew StreamReader("./sourse/guest_descrip/" + textBox_MRnam->Text + ".txt");
		textBox_MRinf->Text =myguest->ReadToEnd();
		myguest->Close();
		delete myguest;
		button_RoomCan->Enabled = true;
	}
	private: System::Void button_PRN_ok_Click(System::Object^  sender, System::EventArgs^  e) {
		if (textBox_PRnam->Text == ""){
			MessageBox::Show("����J�W�r");
			return Void();
		}
		StreamReader^ myguest;
		try{
			myguest = gcnew StreamReader("./sourse/guest_descrip/" + textBox_PRnam->Text + ".txt");
		}
		catch (Exception^ e){
			MessageBox::Show("�z�q���q�L��");
			return Void();
		}
		String^ temp;
		try{
			do{
				temp = myguest->ReadLine();
				comboBox_PRC->Items->Add(temp);
			} while (!myguest->EndOfStream);
			myguest->Close();
		}
		catch (Exception^ e){
			delete myguest;
			MessageBox::Show("�z�ثe�S�w����ж�");
			return Void();
		}
		delete myguest;
		myguest = gcnew StreamReader("./sourse/guest_descrip/" + textBox_PRnam->Text + ".txt");
		textBox_PRinf->Text = myguest->ReadToEnd();
		myguest->Close();
		delete myguest;
		button_PRCN->Enabled = true;
	}
	private: System::Void button_PRCN_Click(System::Object^  sender, System::EventArgs^  e) {
		if (textBox_C1->Text->Length != 4 || textBox_C2->Text->Length != 4 || textBox_C3->Text->Length != 4 || textBox_C4->Text->Length != 4){
			MessageBox::Show("�ФJ���T�d��");
			return Void();
		}
		CGuest^ useguest = gcnew CGuest();
		useguest->payRoom(textBox_PRnam->Text,comboBox_PRC->Text);
		button_PRCN->Enabled = false;
		textBox_PRinf->Text = "";	textBox_PRnam->Text = "";	comboBox_PRC->Items->Clear();
		comboBox_PRC->Text = "";
		textBox_C1->Text = "";	textBox_C2->Text = "";	textBox_C3->Text = "";	textBox_C4->Text = "";
		MessageBox::Show("�I�O���\");
	}
	private: System::Void button_SH_Click(System::Object^  sender, System::EventArgs^  e) {
		if (textBox_SHnam->Text == ""){
			MessageBox::Show("����J�W�r");
			return Void();
		}
		StreamReader^ myguest;
		try{
			myguest = gcnew StreamReader("./sourse/hotel_descrip/" + textBox_SHnam->Text + ".txt");
		}
		catch (Exception^ e){
			MessageBox::Show("�����������U�L");
			return Void();
		}
		myguest->ReadLine();
		textBox_SHinf->Text = myguest->ReadToEnd();
		myguest->Close();
		delete myguest;
	}
};
}
