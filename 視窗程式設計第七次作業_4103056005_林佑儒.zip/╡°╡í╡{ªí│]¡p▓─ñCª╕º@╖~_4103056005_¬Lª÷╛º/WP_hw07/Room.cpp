#include "stdafx.h"
#include "Room.h"
//===============================================================================
CRoom::CRoom(void){
	hid = gcnew u_int(0);
	rid = gcnew u_int(0);
	num = gcnew u_int(0);
	people = gcnew u_int(0);
	cost = gcnew u_int(0);
	name = gcnew String("");
	infor= gcnew String("");
}
//===============================================================================
CRoom::~CRoom(){
	delete hid;
	delete rid;
	delete num;
	delete people;
	delete cost;
	delete name;
	delete infor;
}
//===============================================================================
void CRoom::onScreen(){
	StreamReader^ myroom = gcnew StreamReader("./sourse/room_descrip/" + (*rid).ToString() + ".txt");
	String^ temp = gcnew String("");
	Console::WriteLine(L"==========================================================");
	temp=myroom->ReadLine();
	while (temp = myroom->ReadLine())
		Console::WriteLine(L"{0}",temp);
	myroom->Close();
	Console::WriteLine(L"==========================================================");
	delete temp;
	delete myroom;
}
//===============================================================================
void CRoom::toFile(void){
	StreamWriter^ myroom = gcnew StreamWriter("./sourse/room_descrip/" + (*rid).ToString() + ".txt");
	myroom->WriteLine(L"{0}\t{1}", *hid, *rid);
	myroom->WriteLine(L"name\t{0}", name);
	myroom->WriteLine(L"num's\t{0}", *num);
	myroom->WriteLine(L"people\t{0}", *people);
	myroom->WriteLine(L"cost\t{0}", *cost);
	myroom->WriteLine(L"infor:\n\t{0}", infor);
	myroom->Close();
	delete myroom;
}
//===============================================================================
void CRoom::init(u_int^ gethid, u_int^ now, String^ a1, String^ a2, String^ a3, String^ a4, String^ a5){
	*hid = *gethid;
	*rid = (( (*hid) << 4) + ( (*now)++) );
	name = a1;
	getOther(a2,a3,a4,a5);
	toFile();
}
//===============================================================================
void CRoom::getOther(String^ a2, String^ a3, String^ a4, String^ a5){
	*num = UInt32::Parse(a2);
	*people = UInt32::Parse(a3);
	*cost = UInt32::Parse(a4);
	infor = a5;
}
//===============================================================================
bool CRoom::getFormFile(void){
	StreamReader^ myroom;
	try{
		myroom = gcnew StreamReader("./sourse/room_descrip/" + (*rid).ToString() + ".txt");
	}
	catch (Exception^ e){
		return _False;
	}
	String^ tt = gcnew String("");
	array<String^>^ words;
	tt = myroom->ReadLine();	words = tt->Split('\t');
	*hid = UInt32::Parse(words[0]);	*rid = UInt32::Parse(words[1]);
	tt = myroom->ReadLine();	words = tt->Split('\t');	name = words[1];
	tt = myroom->ReadLine();	words = tt->Split('\t');	*num = UInt32::Parse(words[1]);
	tt = myroom->ReadLine();	words = tt->Split('\t');	*people = UInt32::Parse(words[1]);
	tt = myroom->ReadLine();	words = tt->Split('\t');	*cost = UInt32::Parse(words[1]);
	delete myroom;
	delete words;
	delete tt;
	return _Ture;
}
//===============================================================================