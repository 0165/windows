/***************************
4103056005�L�����ĤC���@�~12 / 30
***************************/
#include "stdafx.h"
#include "MyForm.h"

using namespace WP_hw07;

int main(array<System::String ^> ^args)
{
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);
	Application::Run(gcnew MyForm());
    return 0;
}
