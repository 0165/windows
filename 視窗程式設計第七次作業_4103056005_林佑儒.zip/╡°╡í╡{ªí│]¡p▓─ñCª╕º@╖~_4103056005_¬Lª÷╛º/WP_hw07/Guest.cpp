#include "stdafx.h"
#include "Guest.h"
//===============================================================================
CGuest::CGuest(void){
	pay = gcnew bool(_False);
	rid=gcnew u_int(0);
	people = gcnew u_int(0);
	usedate = gcnew CDate();
	region = gcnew String("");
	name = gcnew String("");
	use = gcnew CHotel();
}
//===============================================================================
CGuest::~CGuest(void){
	delete pay;
	delete rid;
	delete people;
	delete usedate;
	delete region;
	delete use;
	delete name;
}
//===============================================================================
int CGuest::booking(String^ a1, String^ a2, String^ a3, String^ a4, String^ a5, String^ a6){
	name = a1;
	*people = UInt32::Parse(a2);
	*rid = UInt32::Parse(a3);
	region = a5;
	use->name = a6;
	(*use->hroom->rid) = (*rid);
	use->hroom->getFormFile();
	if (*people > *use->hroom->people)
		return 10;
	(*usedate->rid) = (*rid);
	array<String^>^ words;
	words = a4->Split('/');
	*usedate->year = Int32::Parse(words[0]);
	*usedate->mounth = Int32::Parse(words[1]);
	*usedate->day = Int32::Parse(words[2]);
	if (usedate->check()){
		int^ k = gcnew int(-1);
		usedate->toFile(k);
		toFile();
		delete k;
		return 1;
	}
	else
		return -1;
}
//===============================================================================
bool CGuest::listBroom(void){
	Console::Write(L"what's your name? :");
	name = Console::ReadLine();
	StreamReader^ myguest; 
	try{
		myguest = gcnew StreamReader("./sourse/guest_descrip/" + (name)+".txt");
	}
	catch (Exception^ e){
		return _False;
	}
	Console::WriteLine(L"==========================================================");
	Console::WriteLine(L"0 and True means unpay\n1 and false means paied");
	Console::WriteLine(L"\tdate		region\tpeople\tname\trid\tpay");
	u_int^ j = gcnew u_int(0);
	String^ temp = gcnew String("");
	while (temp=myguest->ReadLine())
		Console::WriteLine(L"{0}\t{1}",++(*j),temp);
	myguest->Close();
	Console::WriteLine(L"==========================================================");
	delete temp;
	delete j;
	delete myguest;
	return _Ture;
}
//===============================================================================
bool CGuest::listroom(void){
	StreamReader^ myguest = gcnew StreamReader("./sourse/allroom.txt");
	array<String^>^ words;
	String^ temp = gcnew String("");
	u_int^ i = gcnew u_int(0);
	Console::Write(L"what region you want to book?: ");
	region = Console::ReadLine();
	Console::WriteLine(L"==========================================================\nregion\thotel\troom\tpeople\tcost");
	while (!myguest->EndOfStream){
		temp=myguest->ReadLine();
		if (temp == "")
			break;
		words = temp->Split('\t');
		if (words[0] == region){
			Console::WriteLine(L"{0}",temp);
			(*i)++;
		}
	}
	myguest->Close();
	Console::WriteLine(L"==========================================================");
	if (*i == 0){
		delete temp;
		delete i;
		delete myguest; 
		return _False;
	}
	Console::Write(L"what hotel you want to book?: ");
	use->name = Console::ReadLine();
	use->onScreen();
	delete temp;
	delete i;
	delete myguest;
	return _Ture;
}
//===============================================================================
void CGuest::cancelroom(String^ a1, String^ a2){
	String^ temp = gcnew String("");
	array<String^>^ words,^ww;
	int ^ i = gcnew int();
	name = a1;
	StreamReader^ myguest = gcnew StreamReader("./sourse/guest_descrip/" + (name) + ".txt");
	StreamWriter^ fp = gcnew StreamWriter("./sourse/guest_descrip/" + (name) + "1.txt");
	while (!myguest->EndOfStream){
		temp=myguest->ReadLine();
		if (temp == a2)
			break;
		fp->WriteLine(L"{0}", temp);
	}
	words = temp->Split('\t');
	(*usedate->rid) = UInt32::Parse(words[4]);
	ww = words[0]->Split('/');
	(*usedate->year) = Int32::Parse(ww[0]);
	(*usedate->mounth) = Int32::Parse(ww[1]);
	(*usedate->day) = Int32::Parse(ww[2]);
	*i = 1;	*usedate->count = _False;
	usedate->toFile(i);
	while (_Ture){
		if (myguest->EndOfStream)
			break;
		temp = myguest->ReadLine();
		fp->WriteLine(L"{0}", temp);
	}
	myguest->Close();
	fp->Close();
	File::Delete("./sourse/guest_descrip/" + (name) + ".txt");
	File::Move("./sourse/guest_descrip/" + (name) + "1.txt", "./sourse/guest_descrip/" + (name)+".txt");
	Console::WriteLine(L"cancel success");
	delete i;
	delete fp;
	delete myguest;
	delete temp;
}
//===============================================================================
void CGuest::payRoom(String ^ a1,String^ a2){
	name = a1;
	String^ temp = gcnew String("");
	array<String^>^ words;
	StreamReader^ myguest = gcnew StreamReader("./sourse/guest_descrip/" + (name)+".txt");
	StreamWriter^ fp = gcnew StreamWriter("./sourse/guest_descrip/" + (name)+"1.txt");
	while (!myguest->EndOfStream){
		temp = myguest->ReadLine();
		if (temp == a2)
			break;
		fp->WriteLine(L"{0}", temp);
	}
	words = temp->Split('\t');
	fp->WriteLine(L"{0}\t{1}\t{2}\t{3}\t{4}\t{5}", words[0], words[1], words[2], words[3], words[4], 1);
	while (_Ture){
		if (myguest->EndOfStream)
			break;
		temp = myguest->ReadLine();
		fp->WriteLine(L"{0}", temp);
	}
	myguest->Close();
	fp->Close();
	File::Delete("./sourse/guest_descrip/" + (name)+".txt");
	File::Move("./sourse/guest_descrip/" + (name)+"1.txt", "./sourse/guest_descrip/" + (name)+".txt");
	delete fp;
	delete myguest;
	delete temp;
}
//===============================================================================
void CGuest::toFile(void){
	bool^ test = gcnew bool(_Ture);
	String^ temp = gcnew String("");	String^ tt = gcnew String("");
	array<String^>^ words;
	StreamWriter^ fp;
	StreamReader^ myguest;
	try{
		myguest = gcnew StreamReader("./sourse/guest_descrip/" + (name)+".txt");
	}
	catch (Exception^ e){
		fp = gcnew StreamWriter("./sourse/guest_descrip/" + (name)+".txt");
		fp->WriteLine(L"{0}/{1}/{2}\t{3}\t{4}\t{5}\t{6}\t{7}", (*usedate->year), (*usedate->mounth), (*usedate->day), region, (*people), use->name, *rid, *pay);
		fp->Close();
		goto a;
	}
	tt = (*usedate->year).ToString() + "/" + (*usedate->mounth).ToString() + "/" + (*usedate->day).ToString();
	fp = gcnew StreamWriter("./sourse/guest_descrip/" + (name)+"1.txt");
	while (_Ture){
		if (myguest->EndOfStream){
			if (*test)
				fp->WriteLine(L"{0}\t{1}\t{2}\t{3}\t{4}\t{5}", tt, region, (*people), use->name, *rid, *pay);
			break;
		}
		temp = myguest->ReadLine();	words = temp->Split('\t');
		if (*test && (String::Compare(tt,words[0])<0) ){
			fp->WriteLine(L"{0}\t{1}\t{2}\t{3}\t{4}\t{5}", tt, region, (*people), use->name, *rid, *pay);
			*test = _False;
		}
		else if (*test && (String::Compare(tt, words[0])==0) ){
			if (String::Compare(region, words[1])<0){
				fp->WriteLine(L"{0}\t{1}\t{2}\t{3}\t{4}\t{5}", tt, region, (*people), use->name, *rid, *pay);
				*test = _False;
			}
			else if (String::Compare((*people).ToString(), words[2])<0){
				fp->WriteLine(L"{0}\t{1}\t{2}\t{3}\t{4}\t{5}", tt, region, (*people), use->name, *rid, *pay);
				*test = _False;
			}
		}
		fp->WriteLine(L"{0}", temp);
	}
	myguest->Close();
	fp->Close();
	File::Delete("./sourse/guest_descrip/" + (name)+".txt");
	File::Move("./sourse/guest_descrip/" + (name)+"1.txt", "./sourse/guest_descrip/" + (name)+".txt");
a:	
	delete fp;
	delete myguest;
	delete temp,tt;
	delete test;
}
//===============================================================================
bool CGuest::getCardInfor(void){
	String^ temp = gcnew String("");
a:	Console::Write(L"input the credit card number (ex: ASCS-ACFR-1234-4567) :");
	temp = Console::ReadLine();
	if (temp->Length != 19){
		Console::WriteLine(L"error input");
		goto a;
	}
	Console::Write(L"input the valid date's year (ex: 2016) :");		*usedate->year = Int32::Parse(Console::ReadLine());
	Console::Write(L"input the valid date's mounth (ex: 01) :");		*usedate->mounth = Int32::Parse(Console::ReadLine());
	Console::Write(L"input the valid date's day (ex: 29) :");			*usedate->day = Int32::Parse(Console::ReadLine());
	if (!usedate->checkDate()){
		Console::WriteLine(L"your card is invalid");
		delete temp;
		return _False;
	}
aaa:
	Console::Write(L"input the real name (ex:Frank) :");
	temp = Console::ReadLine();
	if (temp==""){
		Console::WriteLine(L"error input");
		goto aaa;
	}
	delete temp;
	return _Ture;
}
//===============================================================================