#pragma once

namespace FinalProject {

	using namespace System;
	using namespace System::IO;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Note ���K�n
	/// </summary>
	public ref class Note : public System::Windows::Forms::Form
	{
	public:
		Note(void)
		{
			InitializeComponent();
			//
			//TODO:  �b���[�J�غc�禡�{���X
			//
		}

	protected:
		/// <summary>
		/// �M������ϥΤ����귽�C
		/// </summary>
		~Note()
		{
			if (components)
			{
				delete components;
			}
		}
	public: System::Windows::Forms::RichTextBox^  richTextBox1;
	protected:
	private: System::Windows::Forms::Button^  OkButton;
	public:

	private:
		/// <summary>
		/// �]�p�u��һݪ��ܼơC
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// �����]�p�u��䴩�һݪ���k - �ФŨϥε{���X�s�边
		/// �ק�o�Ӥ�k�����e�C
		/// </summary>
		void InitializeComponent(void)
		{
			this->richTextBox1 = (gcnew System::Windows::Forms::RichTextBox());
			this->OkButton = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// richTextBox1
			// 
			this->richTextBox1->BackColor = System::Drawing::Color::Thistle;
			this->richTextBox1->Font = (gcnew System::Drawing::Font(L"�s�ө���", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(136)));
			this->richTextBox1->Location = System::Drawing::Point(13, 11);
			this->richTextBox1->Name = L"richTextBox1";
			this->richTextBox1->ReadOnly = true;
			this->richTextBox1->Size = System::Drawing::Size(563, 246);
			this->richTextBox1->TabIndex = 4;
			this->richTextBox1->Text = L"";
			// 
			// OkButton
			// 
			this->OkButton->Location = System::Drawing::Point(510, 263);
			this->OkButton->Name = L"OkButton";
			this->OkButton->Size = System::Drawing::Size(66, 27);
			this->OkButton->TabIndex = 3;
			this->OkButton->Text = L"�T�w";
			this->OkButton->UseVisualStyleBackColor = true;
			this->OkButton->Click += gcnew System::EventHandler(this, &Note::OkButton_Click);
			// 
			// Note
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 12);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::Plum;
			this->ClientSize = System::Drawing::Size(593, 302);
			this->ControlBox = false;
			this->Controls->Add(this->richTextBox1);
			this->Controls->Add(this->OkButton);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
			this->MaximizeBox = false;
			this->MinimizeBox = false;
			this->Name = L"Note";
			this->Text = L"Note";
			this->Load += gcnew System::EventHandler(this, &Note::Note_Load);
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void OkButton_Click(System::Object^  sender, System::EventArgs^  e) {
		this->Close();
	}
	private: System::Void Note_Load(System::Object^  sender, System::EventArgs^  e) {
		StreamReader^ temp = gcnew StreamReader("ReadMe.txt", System::Text::Encoding::Default);
		richTextBox1->Text = temp->ReadToEnd();
		temp->Close();
		delete temp;
	}
	};
}
