/***************************
����project 1/13
4103056005 �L����
4103056030 �_�ç�
***************************/
#pragma once
#include "ChangeButtonForm.h"
#include "GetKey.h"
#include "ChangKey.h"
#include "Keydefine.h"
#include "Audio.h"
#include "Hotkey.h"
#include "PrintScreen.h"
#include "HotFun.h"
#include "HotKeyChange.h"
#include "Note.h"
namespace FinalProject {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Threading;

	/// <summary>
	/// MyForm ���K�n
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO:  �b���[�J�غc�禡�{���X
			//
			tempComboKey1 = "";
			tempComboKey2 = "";
			tempComboKey3 = "";
			tempComboKey4 = "";
			HotkeyPath1 = "";
			HotkeyPath2 = "";
			HotkeyPath3 = "";
			HotkeyPath4 = "";
			cc = 0;
		}
		static void shutdown(int HotkeyID)
		{
			CHotFun^ shotdown = gcnew CHotFun;
			shotdown->CHotFun::ShotDown();
			delete shotdown;
		}
		static void printfull(int HotkeyID)
		{
			CPrintScreen^ print = gcnew CPrintScreen;
			print->CPrintScreen::FullScreen(cc);
			delete print;
			cc++;
		}
		static void logout(int HotkeyID)
		{
			CHotFun^ shotdown = gcnew CHotFun;
			shotdown->CHotFun::LogOut();
			delete shotdown;
		}
		static void sleep(int HotkeyID)
		{
			CHotFun^ sleep = gcnew CHotFun;
			sleep->CHotFun::Sleep();
			delete sleep;
		}
		static void restart(int HotkeyID)
		{
			CHotFun^ restart = gcnew CHotFun;
			restart->CHotFun::Restart();
			delete restart;
		}
		static void user1(int HotkeyID)
		{
			CHotFun^ User1 = gcnew CHotFun;
			User1->CHotFun::User1(HotkeyPath1);
			delete User1;
		}
		static void user2(int HotkeyID)
		{
			CHotFun^ User2 = gcnew CHotFun;
			User2->CHotFun::User2(HotkeyPath2);
			delete User2;
		}
		static void user3(int HotkeyID)
		{
			CHotFun^ User3 = gcnew CHotFun;
			User3->CHotFun::User3(HotkeyPath3);
			delete User3;
		}
		static void user4(int HotkeyID)
		{
			CHotFun^ User4 = gcnew CHotFun;
			User4->CHotFun::User4(HotkeyPath4);
			delete User4;
		}
	
	private:	Thread^ useingTH;
	private:	Button^ usebutton;
	private:	CChangKey^	useChange;
	private:	static	int	cc;
	private:	int		keyValue;
	private:	int		count;
	private:	int		hotkey;
	private:	Keys	combokey1;
	private:	Keys	combokey2;
	private:	Keys	combokey3;
	private:	Keys	combokey4;
	private:	array<Button^>^ btnAry;
	private:	array<String^>^ strAry;
	private:	CHotkey^ Hotkey_ShotDown;
	private:	CHotkey^ Hotkey_PrintFull;
	private:	CHotkey^ Hotkey_LogOut;
	private:	CHotkey^ Hotkey_Sleep;
	private:	CHotkey^ Hotkey_Restart;
	private:	CHotkey^ Hotkey_User1;
	private:	CHotkey^ Hotkey_User2;
	private:	CHotkey^ Hotkey_User3;
	private:	CHotkey^ Hotkey_User4;
	public:		static	String^ HotkeyPath1;
	public:		static	String^ HotkeyPath2;
	public:		static	String^ HotkeyPath3;
	public:		static	String^ HotkeyPath4;
	public:		String^ tempComboKey1;
	public:		String^ tempComboKey2;
	public:		String^ tempComboKey3;
	public:		String^ tempComboKey4;
	public:		String^ tempHotkey;
	public:		String^ msg;
	public:		CHotkey::KeyFlags hotkeyflags;
	protected:	
		/// <summary>
		/// �M������ϥΤ����귽�C
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	public: String^ a;
	private: System::Windows::Forms::Button^  button_del;
	private: System::Windows::Forms::Button^  button_Check;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::Button^  button4;
	private: System::Windows::Forms::Button^  button5;
	private: System::Windows::Forms::Button^  button6;
	private: System::Windows::Forms::Button^  button7;
	private: System::Windows::Forms::Button^  button8;
	private: System::Windows::Forms::Button^  button9;
	private: System::Windows::Forms::Button^  button10;
	private: System::Windows::Forms::Button^  button11;
	private: System::Windows::Forms::Button^  button12;
	private: System::Windows::Forms::Button^  button13;
	private: System::Windows::Forms::Button^  button14;
	private: System::Windows::Forms::Button^  button15;
	private: System::Windows::Forms::Button^  button16;
	private: System::Windows::Forms::Button^  button17;
	private: System::Windows::Forms::Button^  button18;
	private: System::Windows::Forms::Button^  button19;
	private: System::Windows::Forms::Button^  button20;
	private: System::Windows::Forms::Button^  button21;
	private: System::Windows::Forms::Button^  button22;
	private: System::Windows::Forms::Button^  button23;
	private: System::Windows::Forms::Button^  button24;
	private: System::Windows::Forms::Button^  button25;
	private: System::Windows::Forms::Button^  button26;
	private: System::Windows::Forms::Button^  button27;
	private: System::Windows::Forms::Button^  button28;
	private: System::Windows::Forms::Button^  button29;
	private: System::Windows::Forms::Button^  button30;
	private: System::Windows::Forms::Button^  button31;
	private: System::Windows::Forms::Button^  button32;
	private: System::Windows::Forms::Button^  button33;
	private: System::Windows::Forms::Button^  button34;
	private: System::Windows::Forms::Button^  button35;
	private: System::Windows::Forms::Button^  button36;
	private: System::Windows::Forms::Button^  button37;
	private: System::Windows::Forms::Button^  button38;
	private: System::Windows::Forms::Button^  button39;
	private: System::Windows::Forms::Button^  button40;
	private: System::Windows::Forms::Button^  button41;
	private: System::Windows::Forms::Button^  button42;
	private: System::Windows::Forms::Button^  button43;
	private: System::Windows::Forms::Button^  button44;
	private: System::Windows::Forms::Button^  button45;
	private: System::Windows::Forms::Button^  button46;
	private: System::Windows::Forms::Button^  button47;
	private: System::Windows::Forms::Button^  button48;
	private: System::Windows::Forms::Button^  button49;
	private: System::Windows::Forms::Button^  button50;
	private: System::Windows::Forms::Button^  button51;
	private: System::Windows::Forms::Button^  button52;
	private: System::Windows::Forms::Button^  button53;
	private: System::Windows::Forms::Button^  button54;
	private: System::Windows::Forms::Button^  button55;
	private: System::Windows::Forms::Button^  button56;
	private: System::Windows::Forms::Button^  button57;
	private: System::Windows::Forms::Button^  button58;
	private: System::Windows::Forms::Button^  button59;
	private: System::Windows::Forms::Button^  button60;
	private: System::Windows::Forms::Button^  button61;
	private: System::Windows::Forms::Button^  button62;
	private: System::Windows::Forms::Button^  button63;
	private: System::Windows::Forms::Button^  button64;
	private: System::Windows::Forms::Button^  button65;
	private: System::Windows::Forms::Button^  button66;
	private: System::Windows::Forms::Button^  button67;
	private: System::Windows::Forms::Button^  button68;
	private: System::Windows::Forms::Button^  button69;
	private: System::Windows::Forms::Button^  button70;
	private: System::Windows::Forms::Button^  button71;
	private: System::Windows::Forms::Button^  button72;
	private: System::Windows::Forms::Button^  button73;
	private: System::Windows::Forms::Button^  button74;
	private: System::Windows::Forms::Button^  button75;
	private: System::Windows::Forms::Button^  button76;
	private: System::Windows::Forms::Button^  button77;
	private: System::Windows::Forms::Button^  button78;
	private: System::Windows::Forms::Button^  button79;
	private: System::Windows::Forms::Button^  button80;
	private: System::Windows::Forms::Button^  button81;
	private: System::Windows::Forms::Button^  button82;
	private: System::Windows::Forms::Button^  button83;
	private: System::Windows::Forms::Button^  button84;
	private: System::Windows::Forms::Button^  button85;
	private: System::Windows::Forms::Button^  button86;
	private: System::Windows::Forms::Button^  button87;
	private: System::Windows::Forms::Button^  button88;
	private: System::Windows::Forms::Button^  button89;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::ComboBox^  comboBox1;
	private: System::Windows::Forms::Button^  button_ChOk;
	private: System::Windows::Forms::Button^  button_Reset;
	private: System::Windows::Forms::Button^  button_GStr;
	private: System::Windows::Forms::Button^  button_GStop;
	private: System::Windows::Forms::Button^  button_GChe;
	private: System::Windows::Forms::Button^  button_GClr;

	private:
		/// <summary>
		/// �]�p�u��һݪ��ܼơC
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// �����]�p�u��䴩�һݪ���k - �ФŨϥε{���X�s�边
		/// �ק�o�Ӥ�k�����e�C
		/// </summary>
		void InitializeComponent(void)
		{
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->button7 = (gcnew System::Windows::Forms::Button());
			this->button8 = (gcnew System::Windows::Forms::Button());
			this->button9 = (gcnew System::Windows::Forms::Button());
			this->button10 = (gcnew System::Windows::Forms::Button());
			this->button11 = (gcnew System::Windows::Forms::Button());
			this->button12 = (gcnew System::Windows::Forms::Button());
			this->button13 = (gcnew System::Windows::Forms::Button());
			this->button14 = (gcnew System::Windows::Forms::Button());
			this->button15 = (gcnew System::Windows::Forms::Button());
			this->button16 = (gcnew System::Windows::Forms::Button());
			this->button17 = (gcnew System::Windows::Forms::Button());
			this->button18 = (gcnew System::Windows::Forms::Button());
			this->button19 = (gcnew System::Windows::Forms::Button());
			this->button20 = (gcnew System::Windows::Forms::Button());
			this->button21 = (gcnew System::Windows::Forms::Button());
			this->button22 = (gcnew System::Windows::Forms::Button());
			this->button23 = (gcnew System::Windows::Forms::Button());
			this->button24 = (gcnew System::Windows::Forms::Button());
			this->button25 = (gcnew System::Windows::Forms::Button());
			this->button26 = (gcnew System::Windows::Forms::Button());
			this->button27 = (gcnew System::Windows::Forms::Button());
			this->button28 = (gcnew System::Windows::Forms::Button());
			this->button29 = (gcnew System::Windows::Forms::Button());
			this->button30 = (gcnew System::Windows::Forms::Button());
			this->button31 = (gcnew System::Windows::Forms::Button());
			this->button32 = (gcnew System::Windows::Forms::Button());
			this->button33 = (gcnew System::Windows::Forms::Button());
			this->button34 = (gcnew System::Windows::Forms::Button());
			this->button35 = (gcnew System::Windows::Forms::Button());
			this->button36 = (gcnew System::Windows::Forms::Button());
			this->button37 = (gcnew System::Windows::Forms::Button());
			this->button38 = (gcnew System::Windows::Forms::Button());
			this->button39 = (gcnew System::Windows::Forms::Button());
			this->button40 = (gcnew System::Windows::Forms::Button());
			this->button41 = (gcnew System::Windows::Forms::Button());
			this->button42 = (gcnew System::Windows::Forms::Button());
			this->button43 = (gcnew System::Windows::Forms::Button());
			this->button44 = (gcnew System::Windows::Forms::Button());
			this->button45 = (gcnew System::Windows::Forms::Button());
			this->button46 = (gcnew System::Windows::Forms::Button());
			this->button47 = (gcnew System::Windows::Forms::Button());
			this->button48 = (gcnew System::Windows::Forms::Button());
			this->button49 = (gcnew System::Windows::Forms::Button());
			this->button50 = (gcnew System::Windows::Forms::Button());
			this->button51 = (gcnew System::Windows::Forms::Button());
			this->button52 = (gcnew System::Windows::Forms::Button());
			this->button53 = (gcnew System::Windows::Forms::Button());
			this->button54 = (gcnew System::Windows::Forms::Button());
			this->button55 = (gcnew System::Windows::Forms::Button());
			this->button56 = (gcnew System::Windows::Forms::Button());
			this->button57 = (gcnew System::Windows::Forms::Button());
			this->button58 = (gcnew System::Windows::Forms::Button());
			this->button59 = (gcnew System::Windows::Forms::Button());
			this->button60 = (gcnew System::Windows::Forms::Button());
			this->button61 = (gcnew System::Windows::Forms::Button());
			this->button62 = (gcnew System::Windows::Forms::Button());
			this->button63 = (gcnew System::Windows::Forms::Button());
			this->button64 = (gcnew System::Windows::Forms::Button());
			this->button65 = (gcnew System::Windows::Forms::Button());
			this->button66 = (gcnew System::Windows::Forms::Button());
			this->button67 = (gcnew System::Windows::Forms::Button());
			this->button68 = (gcnew System::Windows::Forms::Button());
			this->button69 = (gcnew System::Windows::Forms::Button());
			this->button70 = (gcnew System::Windows::Forms::Button());
			this->button71 = (gcnew System::Windows::Forms::Button());
			this->button72 = (gcnew System::Windows::Forms::Button());
			this->button73 = (gcnew System::Windows::Forms::Button());
			this->button74 = (gcnew System::Windows::Forms::Button());
			this->button75 = (gcnew System::Windows::Forms::Button());
			this->button76 = (gcnew System::Windows::Forms::Button());
			this->button77 = (gcnew System::Windows::Forms::Button());
			this->button78 = (gcnew System::Windows::Forms::Button());
			this->button79 = (gcnew System::Windows::Forms::Button());
			this->button80 = (gcnew System::Windows::Forms::Button());
			this->button81 = (gcnew System::Windows::Forms::Button());
			this->button82 = (gcnew System::Windows::Forms::Button());
			this->button83 = (gcnew System::Windows::Forms::Button());
			this->button84 = (gcnew System::Windows::Forms::Button());
			this->button85 = (gcnew System::Windows::Forms::Button());
			this->button86 = (gcnew System::Windows::Forms::Button());
			this->button87 = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->button_ChOk = (gcnew System::Windows::Forms::Button());
			this->button_Reset = (gcnew System::Windows::Forms::Button());
			this->button_GStr = (gcnew System::Windows::Forms::Button());
			this->button_GStop = (gcnew System::Windows::Forms::Button());
			this->button_GChe = (gcnew System::Windows::Forms::Button());
			this->button_GClr = (gcnew System::Windows::Forms::Button());
			this->button_del = (gcnew System::Windows::Forms::Button());
			this->button_Check = (gcnew System::Windows::Forms::Button());
			this->button88 = (gcnew System::Windows::Forms::Button());
			this->button89 = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// button1
			// 
			this->button1->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button1->FlatAppearance->BorderSize = 10;
			this->button1->Location = System::Drawing::Point(12, 74);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(50, 50);
			this->button1->TabIndex = 0;
			this->button1->Text = L"~";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button2
			// 
			this->button2->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button2->FlatAppearance->BorderSize = 10;
			this->button2->Location = System::Drawing::Point(68, 74);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(50, 50);
			this->button2->TabIndex = 1;
			this->button2->Text = L"1";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button3
			// 
			this->button3->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button3->FlatAppearance->BorderSize = 10;
			this->button3->Location = System::Drawing::Point(124, 74);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(50, 50);
			this->button3->TabIndex = 2;
			this->button3->Text = L"2";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button4
			// 
			this->button4->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button4->FlatAppearance->BorderSize = 10;
			this->button4->Location = System::Drawing::Point(180, 74);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(50, 50);
			this->button4->TabIndex = 3;
			this->button4->Text = L"3";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button5
			// 
			this->button5->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button5->FlatAppearance->BorderSize = 10;
			this->button5->Location = System::Drawing::Point(236, 74);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(50, 50);
			this->button5->TabIndex = 4;
			this->button5->Text = L"4";
			this->button5->UseVisualStyleBackColor = true;
			this->button5->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button6
			// 
			this->button6->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button6->FlatAppearance->BorderSize = 10;
			this->button6->Location = System::Drawing::Point(292, 74);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(50, 50);
			this->button6->TabIndex = 5;
			this->button6->Text = L"5";
			this->button6->UseVisualStyleBackColor = true;
			this->button6->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button7
			// 
			this->button7->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button7->FlatAppearance->BorderSize = 10;
			this->button7->Location = System::Drawing::Point(348, 74);
			this->button7->Name = L"button7";
			this->button7->Size = System::Drawing::Size(50, 50);
			this->button7->TabIndex = 6;
			this->button7->Text = L"6";
			this->button7->UseVisualStyleBackColor = true;
			this->button7->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button8
			// 
			this->button8->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button8->FlatAppearance->BorderSize = 10;
			this->button8->Location = System::Drawing::Point(404, 74);
			this->button8->Name = L"button8";
			this->button8->Size = System::Drawing::Size(50, 50);
			this->button8->TabIndex = 7;
			this->button8->Text = L"7";
			this->button8->UseVisualStyleBackColor = true;
			this->button8->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button9
			// 
			this->button9->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button9->FlatAppearance->BorderSize = 10;
			this->button9->Location = System::Drawing::Point(460, 74);
			this->button9->Name = L"button9";
			this->button9->Size = System::Drawing::Size(50, 50);
			this->button9->TabIndex = 8;
			this->button9->Text = L"8";
			this->button9->UseVisualStyleBackColor = true;
			this->button9->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button10
			// 
			this->button10->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button10->FlatAppearance->BorderSize = 10;
			this->button10->Location = System::Drawing::Point(516, 74);
			this->button10->Name = L"button10";
			this->button10->Size = System::Drawing::Size(50, 50);
			this->button10->TabIndex = 9;
			this->button10->Text = L"9";
			this->button10->UseVisualStyleBackColor = true;
			this->button10->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button11
			// 
			this->button11->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button11->FlatAppearance->BorderSize = 10;
			this->button11->Location = System::Drawing::Point(572, 74);
			this->button11->Name = L"button11";
			this->button11->Size = System::Drawing::Size(50, 50);
			this->button11->TabIndex = 10;
			this->button11->Text = L"0";
			this->button11->UseVisualStyleBackColor = true;
			this->button11->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button12
			// 
			this->button12->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button12->FlatAppearance->BorderSize = 10;
			this->button12->Location = System::Drawing::Point(628, 74);
			this->button12->Name = L"button12";
			this->button12->Size = System::Drawing::Size(50, 50);
			this->button12->TabIndex = 11;
			this->button12->Text = L"-";
			this->button12->UseVisualStyleBackColor = true;
			this->button12->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button13
			// 
			this->button13->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button13->FlatAppearance->BorderSize = 10;
			this->button13->Location = System::Drawing::Point(684, 74);
			this->button13->Name = L"button13";
			this->button13->Size = System::Drawing::Size(50, 50);
			this->button13->TabIndex = 12;
			this->button13->Text = L"=";
			this->button13->UseVisualStyleBackColor = true;
			this->button13->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button14
			// 
			this->button14->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button14->FlatAppearance->BorderSize = 10;
			this->button14->Location = System::Drawing::Point(740, 74);
			this->button14->Name = L"button14";
			this->button14->Size = System::Drawing::Size(100, 50);
			this->button14->TabIndex = 13;
			this->button14->Text = L"<-";
			this->button14->UseVisualStyleBackColor = true;
			this->button14->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button15
			// 
			this->button15->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button15->FlatAppearance->BorderSize = 10;
			this->button15->Location = System::Drawing::Point(12, 130);
			this->button15->Name = L"button15";
			this->button15->Size = System::Drawing::Size(75, 50);
			this->button15->TabIndex = 14;
			this->button15->Text = L"Tab";
			this->button15->UseVisualStyleBackColor = true;
			this->button15->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button16
			// 
			this->button16->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button16->FlatAppearance->BorderSize = 10;
			this->button16->Location = System::Drawing::Point(93, 130);
			this->button16->Name = L"button16";
			this->button16->Size = System::Drawing::Size(50, 50);
			this->button16->TabIndex = 15;
			this->button16->Text = L"Q";
			this->button16->UseVisualStyleBackColor = true;
			this->button16->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button17
			// 
			this->button17->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button17->FlatAppearance->BorderSize = 10;
			this->button17->Location = System::Drawing::Point(149, 130);
			this->button17->Name = L"button17";
			this->button17->Size = System::Drawing::Size(50, 50);
			this->button17->TabIndex = 16;
			this->button17->Text = L"W";
			this->button17->UseVisualStyleBackColor = true;
			this->button17->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button18
			// 
			this->button18->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button18->FlatAppearance->BorderSize = 10;
			this->button18->Location = System::Drawing::Point(205, 130);
			this->button18->Name = L"button18";
			this->button18->Size = System::Drawing::Size(50, 50);
			this->button18->TabIndex = 17;
			this->button18->Text = L"E";
			this->button18->UseVisualStyleBackColor = true;
			this->button18->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button19
			// 
			this->button19->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button19->FlatAppearance->BorderSize = 10;
			this->button19->Location = System::Drawing::Point(261, 130);
			this->button19->Name = L"button19";
			this->button19->Size = System::Drawing::Size(50, 50);
			this->button19->TabIndex = 18;
			this->button19->Text = L"R";
			this->button19->UseVisualStyleBackColor = true;
			this->button19->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button20
			// 
			this->button20->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button20->FlatAppearance->BorderSize = 10;
			this->button20->Location = System::Drawing::Point(317, 130);
			this->button20->Name = L"button20";
			this->button20->Size = System::Drawing::Size(50, 50);
			this->button20->TabIndex = 19;
			this->button20->Text = L"T";
			this->button20->UseVisualStyleBackColor = true;
			this->button20->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button21
			// 
			this->button21->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button21->FlatAppearance->BorderSize = 10;
			this->button21->Location = System::Drawing::Point(373, 130);
			this->button21->Name = L"button21";
			this->button21->Size = System::Drawing::Size(50, 50);
			this->button21->TabIndex = 20;
			this->button21->Text = L"Y";
			this->button21->UseVisualStyleBackColor = true;
			this->button21->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button22
			// 
			this->button22->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button22->FlatAppearance->BorderSize = 10;
			this->button22->Location = System::Drawing::Point(429, 130);
			this->button22->Name = L"button22";
			this->button22->Size = System::Drawing::Size(50, 50);
			this->button22->TabIndex = 21;
			this->button22->Text = L"U";
			this->button22->UseVisualStyleBackColor = true;
			this->button22->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button23
			// 
			this->button23->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button23->FlatAppearance->BorderSize = 10;
			this->button23->Location = System::Drawing::Point(485, 130);
			this->button23->Name = L"button23";
			this->button23->Size = System::Drawing::Size(50, 50);
			this->button23->TabIndex = 22;
			this->button23->Text = L"I";
			this->button23->UseVisualStyleBackColor = true;
			this->button23->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button24
			// 
			this->button24->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button24->FlatAppearance->BorderSize = 10;
			this->button24->Location = System::Drawing::Point(541, 130);
			this->button24->Name = L"button24";
			this->button24->Size = System::Drawing::Size(50, 50);
			this->button24->TabIndex = 23;
			this->button24->Text = L"O";
			this->button24->UseVisualStyleBackColor = true;
			this->button24->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button25
			// 
			this->button25->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button25->FlatAppearance->BorderSize = 10;
			this->button25->Location = System::Drawing::Point(597, 130);
			this->button25->Name = L"button25";
			this->button25->Size = System::Drawing::Size(50, 50);
			this->button25->TabIndex = 24;
			this->button25->Text = L"P";
			this->button25->UseVisualStyleBackColor = true;
			this->button25->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button26
			// 
			this->button26->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button26->FlatAppearance->BorderSize = 10;
			this->button26->Location = System::Drawing::Point(653, 130);
			this->button26->Name = L"button26";
			this->button26->Size = System::Drawing::Size(50, 50);
			this->button26->TabIndex = 25;
			this->button26->Text = L"[";
			this->button26->UseVisualStyleBackColor = true;
			this->button26->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button27
			// 
			this->button27->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button27->FlatAppearance->BorderSize = 10;
			this->button27->Location = System::Drawing::Point(709, 130);
			this->button27->Name = L"button27";
			this->button27->Size = System::Drawing::Size(50, 50);
			this->button27->TabIndex = 26;
			this->button27->Text = L"]";
			this->button27->UseVisualStyleBackColor = true;
			this->button27->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button28
			// 
			this->button28->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button28->FlatAppearance->BorderSize = 10;
			this->button28->Location = System::Drawing::Point(765, 130);
			this->button28->Name = L"button28";
			this->button28->Size = System::Drawing::Size(75, 50);
			this->button28->TabIndex = 27;
			this->button28->Text = L"|";
			this->button28->UseVisualStyleBackColor = true;
			this->button28->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button29
			// 
			this->button29->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button29->FlatAppearance->BorderSize = 10;
			this->button29->Location = System::Drawing::Point(12, 186);
			this->button29->Name = L"button29";
			this->button29->Size = System::Drawing::Size(89, 50);
			this->button29->TabIndex = 28;
			this->button29->Text = L"Caps Lock";
			this->button29->UseVisualStyleBackColor = true;
			this->button29->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button30
			// 
			this->button30->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button30->FlatAppearance->BorderSize = 10;
			this->button30->Location = System::Drawing::Point(107, 186);
			this->button30->Name = L"button30";
			this->button30->Size = System::Drawing::Size(50, 50);
			this->button30->TabIndex = 29;
			this->button30->Text = L"A";
			this->button30->UseVisualStyleBackColor = true;
			this->button30->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button31
			// 
			this->button31->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button31->FlatAppearance->BorderSize = 10;
			this->button31->Location = System::Drawing::Point(163, 186);
			this->button31->Name = L"button31";
			this->button31->Size = System::Drawing::Size(50, 50);
			this->button31->TabIndex = 30;
			this->button31->Text = L"S";
			this->button31->UseVisualStyleBackColor = true;
			this->button31->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button32
			// 
			this->button32->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button32->FlatAppearance->BorderSize = 10;
			this->button32->Location = System::Drawing::Point(219, 186);
			this->button32->Name = L"button32";
			this->button32->Size = System::Drawing::Size(50, 50);
			this->button32->TabIndex = 31;
			this->button32->Text = L"D";
			this->button32->UseVisualStyleBackColor = true;
			this->button32->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button33
			// 
			this->button33->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button33->FlatAppearance->BorderSize = 10;
			this->button33->Location = System::Drawing::Point(275, 186);
			this->button33->Name = L"button33";
			this->button33->Size = System::Drawing::Size(50, 50);
			this->button33->TabIndex = 32;
			this->button33->Text = L"F";
			this->button33->UseVisualStyleBackColor = true;
			this->button33->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button34
			// 
			this->button34->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button34->FlatAppearance->BorderSize = 10;
			this->button34->Location = System::Drawing::Point(331, 186);
			this->button34->Name = L"button34";
			this->button34->Size = System::Drawing::Size(50, 50);
			this->button34->TabIndex = 33;
			this->button34->Text = L"G";
			this->button34->UseVisualStyleBackColor = true;
			this->button34->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button35
			// 
			this->button35->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button35->FlatAppearance->BorderSize = 10;
			this->button35->Location = System::Drawing::Point(387, 186);
			this->button35->Name = L"button35";
			this->button35->Size = System::Drawing::Size(50, 50);
			this->button35->TabIndex = 34;
			this->button35->Text = L"H";
			this->button35->UseVisualStyleBackColor = true;
			this->button35->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button36
			// 
			this->button36->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button36->FlatAppearance->BorderSize = 10;
			this->button36->Location = System::Drawing::Point(443, 186);
			this->button36->Name = L"button36";
			this->button36->Size = System::Drawing::Size(50, 50);
			this->button36->TabIndex = 35;
			this->button36->Text = L"J";
			this->button36->UseVisualStyleBackColor = true;
			this->button36->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button37
			// 
			this->button37->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button37->FlatAppearance->BorderSize = 10;
			this->button37->Location = System::Drawing::Point(499, 186);
			this->button37->Name = L"button37";
			this->button37->Size = System::Drawing::Size(50, 50);
			this->button37->TabIndex = 36;
			this->button37->Text = L"K";
			this->button37->UseVisualStyleBackColor = true;
			this->button37->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button38
			// 
			this->button38->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button38->FlatAppearance->BorderSize = 10;
			this->button38->Location = System::Drawing::Point(555, 186);
			this->button38->Name = L"button38";
			this->button38->Size = System::Drawing::Size(50, 50);
			this->button38->TabIndex = 37;
			this->button38->Text = L"L";
			this->button38->UseVisualStyleBackColor = true;
			this->button38->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button39
			// 
			this->button39->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button39->FlatAppearance->BorderSize = 10;
			this->button39->Location = System::Drawing::Point(611, 186);
			this->button39->Name = L"button39";
			this->button39->Size = System::Drawing::Size(50, 50);
			this->button39->TabIndex = 38;
			this->button39->Text = L";";
			this->button39->UseVisualStyleBackColor = true;
			this->button39->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button40
			// 
			this->button40->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button40->FlatAppearance->BorderSize = 10;
			this->button40->Location = System::Drawing::Point(667, 186);
			this->button40->Name = L"button40";
			this->button40->Size = System::Drawing::Size(50, 50);
			this->button40->TabIndex = 39;
			this->button40->Text = L"\'";
			this->button40->UseVisualStyleBackColor = true;
			this->button40->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button41
			// 
			this->button41->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button41->FlatAppearance->BorderSize = 10;
			this->button41->Location = System::Drawing::Point(724, 187);
			this->button41->Name = L"button41";
			this->button41->Size = System::Drawing::Size(116, 49);
			this->button41->TabIndex = 40;
			this->button41->Text = L"Enter";
			this->button41->UseVisualStyleBackColor = true;
			this->button41->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button42
			// 
			this->button42->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button42->FlatAppearance->BorderSize = 10;
			this->button42->Location = System::Drawing::Point(13, 242);
			this->button42->Name = L"button42";
			this->button42->Size = System::Drawing::Size(113, 50);
			this->button42->TabIndex = 41;
			this->button42->Text = L"Shift1";
			this->button42->UseVisualStyleBackColor = true;
			this->button42->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button43
			// 
			this->button43->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button43->FlatAppearance->BorderSize = 10;
			this->button43->Location = System::Drawing::Point(132, 242);
			this->button43->Name = L"button43";
			this->button43->Size = System::Drawing::Size(50, 50);
			this->button43->TabIndex = 42;
			this->button43->Text = L"Z";
			this->button43->UseVisualStyleBackColor = true;
			this->button43->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button44
			// 
			this->button44->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button44->FlatAppearance->BorderSize = 10;
			this->button44->Location = System::Drawing::Point(188, 242);
			this->button44->Name = L"button44";
			this->button44->Size = System::Drawing::Size(50, 50);
			this->button44->TabIndex = 43;
			this->button44->Text = L"X";
			this->button44->UseVisualStyleBackColor = true;
			this->button44->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button45
			// 
			this->button45->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button45->FlatAppearance->BorderSize = 10;
			this->button45->Location = System::Drawing::Point(244, 242);
			this->button45->Name = L"button45";
			this->button45->Size = System::Drawing::Size(50, 50);
			this->button45->TabIndex = 44;
			this->button45->Text = L"C";
			this->button45->UseVisualStyleBackColor = true;
			this->button45->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button46
			// 
			this->button46->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button46->FlatAppearance->BorderSize = 10;
			this->button46->Location = System::Drawing::Point(300, 242);
			this->button46->Name = L"button46";
			this->button46->Size = System::Drawing::Size(50, 50);
			this->button46->TabIndex = 45;
			this->button46->Text = L"V";
			this->button46->UseVisualStyleBackColor = true;
			this->button46->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button47
			// 
			this->button47->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button47->FlatAppearance->BorderSize = 10;
			this->button47->Location = System::Drawing::Point(356, 242);
			this->button47->Name = L"button47";
			this->button47->Size = System::Drawing::Size(50, 50);
			this->button47->TabIndex = 46;
			this->button47->Text = L"B";
			this->button47->UseVisualStyleBackColor = true;
			this->button47->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button48
			// 
			this->button48->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button48->FlatAppearance->BorderSize = 10;
			this->button48->Location = System::Drawing::Point(412, 242);
			this->button48->Name = L"button48";
			this->button48->Size = System::Drawing::Size(50, 50);
			this->button48->TabIndex = 47;
			this->button48->Text = L"N";
			this->button48->UseVisualStyleBackColor = true;
			this->button48->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button49
			// 
			this->button49->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button49->FlatAppearance->BorderSize = 10;
			this->button49->Location = System::Drawing::Point(468, 242);
			this->button49->Name = L"button49";
			this->button49->Size = System::Drawing::Size(50, 50);
			this->button49->TabIndex = 48;
			this->button49->Text = L"M";
			this->button49->UseVisualStyleBackColor = true;
			this->button49->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button50
			// 
			this->button50->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button50->FlatAppearance->BorderSize = 10;
			this->button50->Location = System::Drawing::Point(524, 242);
			this->button50->Name = L"button50";
			this->button50->Size = System::Drawing::Size(50, 50);
			this->button50->TabIndex = 49;
			this->button50->Text = L",";
			this->button50->UseVisualStyleBackColor = true;
			this->button50->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button51
			// 
			this->button51->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button51->FlatAppearance->BorderSize = 10;
			this->button51->Location = System::Drawing::Point(580, 242);
			this->button51->Name = L"button51";
			this->button51->Size = System::Drawing::Size(50, 50);
			this->button51->TabIndex = 50;
			this->button51->Text = L".";
			this->button51->UseVisualStyleBackColor = true;
			this->button51->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button52
			// 
			this->button52->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button52->FlatAppearance->BorderSize = 10;
			this->button52->Location = System::Drawing::Point(636, 242);
			this->button52->Name = L"button52";
			this->button52->Size = System::Drawing::Size(50, 50);
			this->button52->TabIndex = 51;
			this->button52->Text = L"/";
			this->button52->UseVisualStyleBackColor = true;
			this->button52->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button53
			// 
			this->button53->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button53->FlatAppearance->BorderSize = 10;
			this->button53->Location = System::Drawing::Point(692, 242);
			this->button53->Name = L"button53";
			this->button53->Size = System::Drawing::Size(148, 50);
			this->button53->TabIndex = 52;
			this->button53->Text = L"Shift2";
			this->button53->UseVisualStyleBackColor = true;
			this->button53->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button54
			// 
			this->button54->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button54->FlatAppearance->BorderSize = 10;
			this->button54->Location = System::Drawing::Point(12, 298);
			this->button54->Name = L"button54";
			this->button54->Size = System::Drawing::Size(75, 50);
			this->button54->TabIndex = 53;
			this->button54->Text = L"Ctrl1";
			this->button54->UseVisualStyleBackColor = true;
			this->button54->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button55
			// 
			this->button55->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button55->FlatAppearance->BorderSize = 10;
			this->button55->Location = System::Drawing::Point(93, 298);
			this->button55->Name = L"button55";
			this->button55->Size = System::Drawing::Size(50, 50);
			this->button55->TabIndex = 54;
			this->button55->Text = L"win1";
			this->button55->UseVisualStyleBackColor = true;
			this->button55->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button56
			// 
			this->button56->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button56->FlatAppearance->BorderSize = 10;
			this->button56->Location = System::Drawing::Point(149, 298);
			this->button56->Name = L"button56";
			this->button56->Size = System::Drawing::Size(75, 49);
			this->button56->TabIndex = 55;
			this->button56->Text = L"Alt1";
			this->button56->UseVisualStyleBackColor = true;
			this->button56->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button57
			// 
			this->button57->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button57->FlatAppearance->BorderSize = 10;
			this->button57->Location = System::Drawing::Point(230, 298);
			this->button57->Name = L"button57";
			this->button57->Size = System::Drawing::Size(336, 50);
			this->button57->TabIndex = 56;
			this->button57->Text = L"space";
			this->button57->UseVisualStyleBackColor = true;
			this->button57->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button58
			// 
			this->button58->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button58->FlatAppearance->BorderSize = 10;
			this->button58->Location = System::Drawing::Point(572, 298);
			this->button58->Name = L"button58";
			this->button58->Size = System::Drawing::Size(75, 49);
			this->button58->TabIndex = 57;
			this->button58->Text = L"Alt2";
			this->button58->UseVisualStyleBackColor = true;
			this->button58->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button59
			// 
			this->button59->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button59->FlatAppearance->BorderSize = 10;
			this->button59->Location = System::Drawing::Point(653, 298);
			this->button59->Name = L"button59";
			this->button59->Size = System::Drawing::Size(50, 50);
			this->button59->TabIndex = 58;
			this->button59->Text = L"win2";
			this->button59->UseVisualStyleBackColor = true;
			this->button59->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button60
			// 
			this->button60->Enabled = false;
			this->button60->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button60->FlatAppearance->BorderSize = 10;
			this->button60->Location = System::Drawing::Point(709, 298);
			this->button60->Name = L"button60";
			this->button60->Size = System::Drawing::Size(50, 50);
			this->button60->TabIndex = 59;
			this->button60->Text = L"�L��";
			this->button60->UseVisualStyleBackColor = true;
			this->button60->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button61
			// 
			this->button61->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button61->FlatAppearance->BorderSize = 10;
			this->button61->Location = System::Drawing::Point(765, 298);
			this->button61->Name = L"button61";
			this->button61->Size = System::Drawing::Size(75, 50);
			this->button61->TabIndex = 60;
			this->button61->Text = L"Ctrl2";
			this->button61->UseVisualStyleBackColor = true;
			this->button61->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button62
			// 
			this->button62->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button62->FlatAppearance->BorderSize = 10;
			this->button62->Location = System::Drawing::Point(854, 74);
			this->button62->Name = L"button62";
			this->button62->Size = System::Drawing::Size(50, 50);
			this->button62->TabIndex = 61;
			this->button62->Text = L"Insert";
			this->button62->UseVisualStyleBackColor = true;
			this->button62->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button63
			// 
			this->button63->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button63->FlatAppearance->BorderSize = 10;
			this->button63->Location = System::Drawing::Point(910, 74);
			this->button63->Name = L"button63";
			this->button63->Size = System::Drawing::Size(50, 50);
			this->button63->TabIndex = 62;
			this->button63->Text = L"Home";
			this->button63->UseVisualStyleBackColor = true;
			this->button63->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button64
			// 
			this->button64->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button64->FlatAppearance->BorderSize = 10;
			this->button64->Location = System::Drawing::Point(966, 74);
			this->button64->Name = L"button64";
			this->button64->Size = System::Drawing::Size(50, 50);
			this->button64->TabIndex = 63;
			this->button64->Text = L"Page  Up";
			this->button64->UseVisualStyleBackColor = true;
			this->button64->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button65
			// 
			this->button65->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button65->FlatAppearance->BorderSize = 10;
			this->button65->Location = System::Drawing::Point(854, 131);
			this->button65->Name = L"button65";
			this->button65->Size = System::Drawing::Size(50, 50);
			this->button65->TabIndex = 64;
			this->button65->Text = L"Delete";
			this->button65->UseVisualStyleBackColor = true;
			this->button65->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button66
			// 
			this->button66->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button66->FlatAppearance->BorderSize = 10;
			this->button66->Location = System::Drawing::Point(910, 131);
			this->button66->Name = L"button66";
			this->button66->Size = System::Drawing::Size(50, 50);
			this->button66->TabIndex = 65;
			this->button66->Text = L"End";
			this->button66->UseVisualStyleBackColor = true;
			this->button66->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button67
			// 
			this->button67->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button67->FlatAppearance->BorderSize = 10;
			this->button67->Location = System::Drawing::Point(966, 131);
			this->button67->Name = L"button67";
			this->button67->Size = System::Drawing::Size(50, 50);
			this->button67->TabIndex = 66;
			this->button67->Text = L"Page Down";
			this->button67->UseVisualStyleBackColor = true;
			this->button67->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button68
			// 
			this->button68->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button68->FlatAppearance->BorderSize = 10;
			this->button68->Location = System::Drawing::Point(910, 242);
			this->button68->Name = L"button68";
			this->button68->Size = System::Drawing::Size(50, 50);
			this->button68->TabIndex = 67;
			this->button68->Text = L"up";
			this->button68->UseVisualStyleBackColor = true;
			this->button68->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button69
			// 
			this->button69->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button69->FlatAppearance->BorderSize = 10;
			this->button69->Location = System::Drawing::Point(854, 298);
			this->button69->Name = L"button69";
			this->button69->Size = System::Drawing::Size(50, 50);
			this->button69->TabIndex = 68;
			this->button69->Text = L"left";
			this->button69->UseVisualStyleBackColor = true;
			this->button69->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button70
			// 
			this->button70->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button70->FlatAppearance->BorderSize = 10;
			this->button70->Location = System::Drawing::Point(910, 297);
			this->button70->Name = L"button70";
			this->button70->Size = System::Drawing::Size(50, 50);
			this->button70->TabIndex = 69;
			this->button70->Text = L"down";
			this->button70->UseVisualStyleBackColor = true;
			this->button70->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button71
			// 
			this->button71->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button71->FlatAppearance->BorderSize = 10;
			this->button71->Location = System::Drawing::Point(966, 297);
			this->button71->Name = L"button71";
			this->button71->Size = System::Drawing::Size(50, 50);
			this->button71->TabIndex = 70;
			this->button71->Text = L"right";
			this->button71->UseVisualStyleBackColor = true;
			this->button71->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button72
			// 
			this->button72->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button72->FlatAppearance->BorderSize = 10;
			this->button72->Location = System::Drawing::Point(13, 13);
			this->button72->Name = L"button72";
			this->button72->Size = System::Drawing::Size(50, 50);
			this->button72->TabIndex = 71;
			this->button72->Text = L"Esc";
			this->button72->UseVisualStyleBackColor = true;
			this->button72->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button73
			// 
			this->button73->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button73->FlatAppearance->BorderSize = 10;
			this->button73->Location = System::Drawing::Point(124, 13);
			this->button73->Name = L"button73";
			this->button73->Size = System::Drawing::Size(50, 50);
			this->button73->TabIndex = 72;
			this->button73->Text = L"F1";
			this->button73->UseVisualStyleBackColor = true;
			this->button73->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button74
			// 
			this->button74->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button74->FlatAppearance->BorderSize = 10;
			this->button74->Location = System::Drawing::Point(180, 13);
			this->button74->Name = L"button74";
			this->button74->Size = System::Drawing::Size(50, 50);
			this->button74->TabIndex = 73;
			this->button74->Text = L"F2";
			this->button74->UseVisualStyleBackColor = true;
			this->button74->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button75
			// 
			this->button75->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button75->FlatAppearance->BorderSize = 10;
			this->button75->Location = System::Drawing::Point(236, 11);
			this->button75->Name = L"button75";
			this->button75->Size = System::Drawing::Size(50, 50);
			this->button75->TabIndex = 74;
			this->button75->Text = L"F3";
			this->button75->UseVisualStyleBackColor = true;
			this->button75->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button76
			// 
			this->button76->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button76->FlatAppearance->BorderSize = 10;
			this->button76->Location = System::Drawing::Point(292, 12);
			this->button76->Name = L"button76";
			this->button76->Size = System::Drawing::Size(50, 50);
			this->button76->TabIndex = 75;
			this->button76->Text = L"F4";
			this->button76->UseVisualStyleBackColor = true;
			this->button76->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button77
			// 
			this->button77->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button77->FlatAppearance->BorderSize = 10;
			this->button77->Location = System::Drawing::Point(373, 11);
			this->button77->Name = L"button77";
			this->button77->Size = System::Drawing::Size(50, 50);
			this->button77->TabIndex = 76;
			this->button77->Text = L"F5";
			this->button77->UseVisualStyleBackColor = true;
			this->button77->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button78
			// 
			this->button78->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button78->FlatAppearance->BorderSize = 10;
			this->button78->Location = System::Drawing::Point(429, 11);
			this->button78->Name = L"button78";
			this->button78->Size = System::Drawing::Size(50, 50);
			this->button78->TabIndex = 77;
			this->button78->Text = L"F6";
			this->button78->UseVisualStyleBackColor = true;
			this->button78->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button79
			// 
			this->button79->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button79->FlatAppearance->BorderSize = 10;
			this->button79->Location = System::Drawing::Point(485, 11);
			this->button79->Name = L"button79";
			this->button79->Size = System::Drawing::Size(50, 50);
			this->button79->TabIndex = 78;
			this->button79->Text = L"F7";
			this->button79->UseVisualStyleBackColor = true;
			this->button79->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button80
			// 
			this->button80->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button80->FlatAppearance->BorderSize = 10;
			this->button80->Location = System::Drawing::Point(541, 11);
			this->button80->Name = L"button80";
			this->button80->Size = System::Drawing::Size(50, 50);
			this->button80->TabIndex = 79;
			this->button80->Text = L"F8";
			this->button80->UseVisualStyleBackColor = true;
			this->button80->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button81
			// 
			this->button81->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button81->FlatAppearance->BorderSize = 10;
			this->button81->Location = System::Drawing::Point(622, 11);
			this->button81->Name = L"button81";
			this->button81->Size = System::Drawing::Size(50, 50);
			this->button81->TabIndex = 80;
			this->button81->Text = L"F9";
			this->button81->UseVisualStyleBackColor = true;
			this->button81->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button82
			// 
			this->button82->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button82->FlatAppearance->BorderSize = 10;
			this->button82->Location = System::Drawing::Point(678, 11);
			this->button82->Name = L"button82";
			this->button82->Size = System::Drawing::Size(50, 50);
			this->button82->TabIndex = 81;
			this->button82->Text = L"F10";
			this->button82->UseVisualStyleBackColor = true;
			this->button82->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button83
			// 
			this->button83->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button83->FlatAppearance->BorderSize = 10;
			this->button83->Location = System::Drawing::Point(734, 11);
			this->button83->Name = L"button83";
			this->button83->Size = System::Drawing::Size(50, 50);
			this->button83->TabIndex = 82;
			this->button83->Text = L"F11";
			this->button83->UseVisualStyleBackColor = true;
			this->button83->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button84
			// 
			this->button84->FlatAppearance->BorderColor = System::Drawing::Color::White;
			this->button84->FlatAppearance->BorderSize = 0;
			this->button84->Location = System::Drawing::Point(790, 11);
			this->button84->Name = L"button84";
			this->button84->Size = System::Drawing::Size(50, 50);
			this->button84->TabIndex = 83;
			this->button84->Text = L"F12";
			this->button84->UseVisualStyleBackColor = false;
			this->button84->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button85
			// 
			this->button85->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button85->FlatAppearance->BorderSize = 10;
			this->button85->Location = System::Drawing::Point(854, 11);
			this->button85->Name = L"button85";
			this->button85->Size = System::Drawing::Size(50, 50);
			this->button85->TabIndex = 84;
			this->button85->Text = L"Print Screen";
			this->button85->UseVisualStyleBackColor = true;
			this->button85->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button86
			// 
			this->button86->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button86->FlatAppearance->BorderSize = 10;
			this->button86->Location = System::Drawing::Point(910, 11);
			this->button86->Name = L"button86";
			this->button86->Size = System::Drawing::Size(50, 50);
			this->button86->TabIndex = 85;
			this->button86->Text = L"Scroll Lock";
			this->button86->UseVisualStyleBackColor = true;
			this->button86->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button87
			// 
			this->button87->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->button87->FlatAppearance->BorderSize = 10;
			this->button87->Location = System::Drawing::Point(966, 11);
			this->button87->Name = L"button87";
			this->button87->Size = System::Drawing::Size(50, 50);
			this->button87->TabIndex = 86;
			this->button87->Text = L"Pause";
			this->button87->UseVisualStyleBackColor = true;
			this->button87->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"�s�ө���", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(136)));
			this->label1->Location = System::Drawing::Point(1050, 13);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(68, 16);
			this->label1->TabIndex = 87;
			this->label1->Text = L"������ : ";
			// 
			// comboBox1
			// 
			this->comboBox1->BackColor = System::Drawing::Color::Plum;
			this->comboBox1->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox1->Font = (gcnew System::Drawing::Font(L"�s�ө���", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(136)));
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Items->AddRange(gcnew cli::array< System::Object^  >(87) {
				L"~", L"1", L"2", L"3", L"4", L"5", L"6", L"7",
					L"8", L"9", L"0", L"-", L"=", L"<-", L"Tab", L"Q", L"W", L"E", L"R", L"T", L"Y", L"U", L"I", L"O", L"P", L"[", L"]", L"|", L"CapsLock",
					L"A", L"S", L"D", L"F", L"G", L"H", L"J", L"K", L"L", L";", L"\'", L"Enter", L"Shift1", L"Z", L"X", L"C", L"V", L"B", L"N", L"M",
					L",", L".", L"/", L"Shift2", L"Ctrl1", L"win1", L"Alt1", L"space", L"Alt2", L"win2", L"Ctrl2", L"Esc", L"F1", L"F2", L"F3", L"F4",
					L"F5", L"F6", L"F7", L"F8", L"F9", L"F10", L"F11", L"F12", L"Print Screen", L"Scroll Lock", L"Pause", L"Insert", L"Home", L"Page  Up",
					L"Delete", L"End", L"Page Down", L"up", L"left", L"down", L"right", L"�L��"
			});
			this->comboBox1->Location = System::Drawing::Point(1053, 32);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(120, 24);
			this->comboBox1->TabIndex = 88;
			// 
			// button_ChOk
			// 
			this->button_ChOk->Font = (gcnew System::Drawing::Font(L"�s�ө���", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(136)));
			this->button_ChOk->Location = System::Drawing::Point(1053, 70);
			this->button_ChOk->Name = L"button_ChOk";
			this->button_ChOk->Size = System::Drawing::Size(120, 29);
			this->button_ChOk->TabIndex = 89;
			this->button_ChOk->Text = L"�T�w�s�W";
			this->button_ChOk->UseVisualStyleBackColor = true;
			this->button_ChOk->Click += gcnew System::EventHandler(this, &MyForm::button_ChOk_Click);
			// 
			// button_Reset
			// 
			this->button_Reset->Font = (gcnew System::Drawing::Font(L"�s�ө���", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(136)));
			this->button_Reset->Location = System::Drawing::Point(1053, 130);
			this->button_Reset->Name = L"button_Reset";
			this->button_Reset->Size = System::Drawing::Size(120, 29);
			this->button_Reset->TabIndex = 90;
			this->button_Reset->Text = L"�M�ū᭫��";
			this->button_Reset->UseVisualStyleBackColor = true;
			this->button_Reset->Click += gcnew System::EventHandler(this, &MyForm::button_Reset_Click);
			// 
			// button_GStr
			// 
			this->button_GStr->Font = (gcnew System::Drawing::Font(L"�s�ө���", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(136)));
			this->button_GStr->Location = System::Drawing::Point(1053, 220);
			this->button_GStr->Name = L"button_GStr";
			this->button_GStr->Size = System::Drawing::Size(120, 29);
			this->button_GStr->TabIndex = 91;
			this->button_GStr->Text = L"�}�l����";
			this->button_GStr->UseVisualStyleBackColor = true;
			this->button_GStr->Click += gcnew System::EventHandler(this, &MyForm::button_GStr_Click);
			// 
			// button_GStop
			// 
			this->button_GStop->Enabled = false;
			this->button_GStop->Font = (gcnew System::Drawing::Font(L"�s�ө���", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(136)));
			this->button_GStop->Location = System::Drawing::Point(1053, 253);
			this->button_GStop->Name = L"button_GStop";
			this->button_GStop->Size = System::Drawing::Size(120, 29);
			this->button_GStop->TabIndex = 92;
			this->button_GStop->Text = L"�����";
			this->button_GStop->UseVisualStyleBackColor = true;
			this->button_GStop->Click += gcnew System::EventHandler(this, &MyForm::button_GStop_Click);
			// 
			// button_GChe
			// 
			this->button_GChe->Font = (gcnew System::Drawing::Font(L"�s�ө���", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(136)));
			this->button_GChe->Location = System::Drawing::Point(1053, 286);
			this->button_GChe->Name = L"button_GChe";
			this->button_GChe->Size = System::Drawing::Size(120, 29);
			this->button_GChe->TabIndex = 93;
			this->button_GChe->Text = L"�d�ݰ������";
			this->button_GChe->UseVisualStyleBackColor = true;
			this->button_GChe->Click += gcnew System::EventHandler(this, &MyForm::button_GChe_Click);
			// 
			// button_GClr
			// 
			this->button_GClr->Font = (gcnew System::Drawing::Font(L"�s�ө���", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(136)));
			this->button_GClr->Location = System::Drawing::Point(1053, 318);
			this->button_GClr->Name = L"button_GClr";
			this->button_GClr->Size = System::Drawing::Size(120, 29);
			this->button_GClr->TabIndex = 94;
			this->button_GClr->Text = L"�M���������";
			this->button_GClr->UseVisualStyleBackColor = true;
			this->button_GClr->Click += gcnew System::EventHandler(this, &MyForm::button_GClr_Click);
			// 
			// button_del
			// 
			this->button_del->Font = (gcnew System::Drawing::Font(L"�s�ө���", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(136)));
			this->button_del->Location = System::Drawing::Point(1053, 161);
			this->button_del->Name = L"button_del";
			this->button_del->Size = System::Drawing::Size(120, 29);
			this->button_del->TabIndex = 95;
			this->button_del->Text = L"�^�_��t�]�w";
			this->button_del->UseVisualStyleBackColor = true;
			this->button_del->Click += gcnew System::EventHandler(this, &MyForm::button_del_Click);
			// 
			// button_Check
			// 
			this->button_Check->Enabled = false;
			this->button_Check->Font = (gcnew System::Drawing::Font(L"�s�ө���", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(136)));
			this->button_Check->Location = System::Drawing::Point(1053, 100);
			this->button_Check->Name = L"button_Check";
			this->button_Check->Size = System::Drawing::Size(120, 29);
			this->button_Check->TabIndex = 96;
			this->button_Check->Text = L"�T�w�g�J";
			this->button_Check->UseVisualStyleBackColor = true;
			this->button_Check->Click += gcnew System::EventHandler(this, &MyForm::button_Check_Click);
			// 
			// button88
			// 
			this->button88->Location = System::Drawing::Point(854, 187);
			this->button88->Margin = System::Windows::Forms::Padding(2);
			this->button88->Name = L"button88";
			this->button88->Size = System::Drawing::Size(77, 29);
			this->button88->TabIndex = 97;
			this->button88->Text = L"�_�μ���";
			this->button88->UseVisualStyleBackColor = true;
			this->button88->Click += gcnew System::EventHandler(this, &MyForm::button88_Click);
			// 
			// button89
			// 
			this->button89->Location = System::Drawing::Point(939, 187);
			this->button89->Margin = System::Windows::Forms::Padding(2);
			this->button89->Name = L"button89";
			this->button89->Size = System::Drawing::Size(77, 29);
			this->button89->TabIndex = 98;
			this->button89->Text = L"����]�w";
			this->button89->UseVisualStyleBackColor = true;
			this->button89->Click += gcnew System::EventHandler(this, &MyForm::button89_Click);
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 12);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::Plum;
			this->ClientSize = System::Drawing::Size(1192, 364);
			this->Controls->Add(this->button89);
			this->Controls->Add(this->button88);
			this->Controls->Add(this->button_Check);
			this->Controls->Add(this->button_del);
			this->Controls->Add(this->button_GClr);
			this->Controls->Add(this->button_GChe);
			this->Controls->Add(this->button_GStop);
			this->Controls->Add(this->button_GStr);
			this->Controls->Add(this->button_Reset);
			this->Controls->Add(this->button_ChOk);
			this->Controls->Add(this->comboBox1);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->button87);
			this->Controls->Add(this->button86);
			this->Controls->Add(this->button85);
			this->Controls->Add(this->button84);
			this->Controls->Add(this->button83);
			this->Controls->Add(this->button82);
			this->Controls->Add(this->button81);
			this->Controls->Add(this->button80);
			this->Controls->Add(this->button79);
			this->Controls->Add(this->button78);
			this->Controls->Add(this->button77);
			this->Controls->Add(this->button76);
			this->Controls->Add(this->button75);
			this->Controls->Add(this->button74);
			this->Controls->Add(this->button73);
			this->Controls->Add(this->button72);
			this->Controls->Add(this->button71);
			this->Controls->Add(this->button70);
			this->Controls->Add(this->button69);
			this->Controls->Add(this->button68);
			this->Controls->Add(this->button67);
			this->Controls->Add(this->button66);
			this->Controls->Add(this->button65);
			this->Controls->Add(this->button64);
			this->Controls->Add(this->button63);
			this->Controls->Add(this->button62);
			this->Controls->Add(this->button61);
			this->Controls->Add(this->button60);
			this->Controls->Add(this->button59);
			this->Controls->Add(this->button58);
			this->Controls->Add(this->button57);
			this->Controls->Add(this->button56);
			this->Controls->Add(this->button55);
			this->Controls->Add(this->button54);
			this->Controls->Add(this->button53);
			this->Controls->Add(this->button52);
			this->Controls->Add(this->button51);
			this->Controls->Add(this->button50);
			this->Controls->Add(this->button49);
			this->Controls->Add(this->button48);
			this->Controls->Add(this->button47);
			this->Controls->Add(this->button46);
			this->Controls->Add(this->button45);
			this->Controls->Add(this->button44);
			this->Controls->Add(this->button43);
			this->Controls->Add(this->button42);
			this->Controls->Add(this->button41);
			this->Controls->Add(this->button40);
			this->Controls->Add(this->button39);
			this->Controls->Add(this->button38);
			this->Controls->Add(this->button37);
			this->Controls->Add(this->button36);
			this->Controls->Add(this->button35);
			this->Controls->Add(this->button34);
			this->Controls->Add(this->button33);
			this->Controls->Add(this->button32);
			this->Controls->Add(this->button31);
			this->Controls->Add(this->button30);
			this->Controls->Add(this->button29);
			this->Controls->Add(this->button28);
			this->Controls->Add(this->button27);
			this->Controls->Add(this->button26);
			this->Controls->Add(this->button25);
			this->Controls->Add(this->button24);
			this->Controls->Add(this->button23);
			this->Controls->Add(this->button22);
			this->Controls->Add(this->button21);
			this->Controls->Add(this->button20);
			this->Controls->Add(this->button19);
			this->Controls->Add(this->button18);
			this->Controls->Add(this->button17);
			this->Controls->Add(this->button16);
			this->Controls->Add(this->button15);
			this->Controls->Add(this->button14);
			this->Controls->Add(this->button13);
			this->Controls->Add(this->button12);
			this->Controls->Add(this->button11);
			this->Controls->Add(this->button10);
			this->Controls->Add(this->button9);
			this->Controls->Add(this->button8);
			this->Controls->Add(this->button7);
			this->Controls->Add(this->button6);
			this->Controls->Add(this->button5);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
			this->MaximizeBox = false;
			this->MinimizeBox = false;
			this->Name = L"MyForm";
			this->Text = L"KBT";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button_GChe_Click(System::Object^  sender, System::EventArgs^  e) {
		StreamReader^ temp = gcnew StreamReader("data.txt");
		ChangeButtonForm ^ change_from = gcnew ChangeButtonForm();
		change_from->richTextBox1->Text = temp->ReadToEnd();
		temp->Close();
		if (change_from->richTextBox1->Text == "")
			MessageBox::Show("�|�������Τw�M��", "����", MessageBoxButtons::OK, MessageBoxIcon::Information);
		else{
			change_from->Location = Point(this->Location.X+250, this->Location.Y+60);
			change_from->ShowDialog();
		}
		delete change_from;
		delete temp;
	}
	private: System::Void button_GStr_Click(System::Object^  sender, System::EventArgs^  e) {
		useingTH = gcnew Thread(gcnew ThreadStart(CGetKey::StartGeting));
		useingTH->Start();
		button_GStr->Enabled = false;
		button_GStop->Enabled = true;
	}
	private: System::Void button_GStop_Click(System::Object^  sender, System::EventArgs^  e) {
		useingTH->Abort();
		delete useingTH;
		button_GStop->Enabled = false;
		button_GStr->Enabled = true;
	}
	private: System::Void button_GClr_Click(System::Object^  sender, System::EventArgs^  e) {
		CGetKey::clrFile();
		MessageBox::Show("�M�����\", "����", MessageBoxButtons::OK, MessageBoxIcon::Information);
	}
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
		if (usebutton!=nullptr)
			usebutton->BackColor = System::Drawing::Color::Plum;
		usebutton = (Button^)sender;
		usebutton->BackColor = System::Drawing::Color::Goldenrod;
		keyValue=getValue(usebutton->Text);
	}
	CHotkey::KeyFlags getHotkey(String^ theStr){
		if (theStr == "Alt")			return CHotkey::KeyFlags::MODALT;
		else if (theStr == "Ctrl")		return CHotkey::KeyFlags::MODCONTROL;
		else if (theStr == "Shift")		return CHotkey::KeyFlags::MODSHIFT;
		return CHotkey::KeyFlags::MODALT;
	}
	Keys getKey(String^ theStr){
		if (theStr == "1")			return System::Windows::Forms::Keys::D1;
		else if (theStr == "2")		return System::Windows::Forms::Keys::D2;
		else if (theStr == "3")		return System::Windows::Forms::Keys::D3;
		else if (theStr == "4")		return System::Windows::Forms::Keys::D4;
		else if (theStr == "5")		return System::Windows::Forms::Keys::D5;
		else if (theStr == "6")		return System::Windows::Forms::Keys::D6;
		else if (theStr == "7")		return System::Windows::Forms::Keys::D7;
		else if (theStr == "8")		return System::Windows::Forms::Keys::D8;
		else if (theStr == "9")		return System::Windows::Forms::Keys::D9;
		else if (theStr == "0")		return System::Windows::Forms::Keys::D0;
		else if (theStr == "Q")		return System::Windows::Forms::Keys::Q;
		else if (theStr == "W")		return System::Windows::Forms::Keys::W;
		else if (theStr == "E")		return System::Windows::Forms::Keys::E;
		else if (theStr == "R")		return System::Windows::Forms::Keys::R;
		else if (theStr == "T")		return System::Windows::Forms::Keys::T;
		else if (theStr == "Y")		return System::Windows::Forms::Keys::Y;
		else if (theStr == "U")		return System::Windows::Forms::Keys::U;
		else if (theStr == "I")		return System::Windows::Forms::Keys::I;
		else if (theStr == "O")		return System::Windows::Forms::Keys::O;
		else if (theStr == "P")		return System::Windows::Forms::Keys::P;
		else if (theStr == "A")		return System::Windows::Forms::Keys::A;
		else if (theStr == "S")		return System::Windows::Forms::Keys::S;
		else if (theStr == "D")		return System::Windows::Forms::Keys::D;
		else if (theStr == "F")		return System::Windows::Forms::Keys::F;
		else if (theStr == "G")		return System::Windows::Forms::Keys::G;
		else if (theStr == "H")		return System::Windows::Forms::Keys::H;
		else if (theStr == "J")		return System::Windows::Forms::Keys::J;
		else if (theStr == "K")		return System::Windows::Forms::Keys::K;
		else if (theStr == "L")		return System::Windows::Forms::Keys::L;
		else if (theStr == "Z")		return System::Windows::Forms::Keys::Z;
		else if (theStr == "X")		return System::Windows::Forms::Keys::X;
		else if (theStr == "C")		return System::Windows::Forms::Keys::C;
		else if (theStr == "V")		return System::Windows::Forms::Keys::V;
		else if (theStr == "B")		return System::Windows::Forms::Keys::B;
		else if (theStr == "N")		return System::Windows::Forms::Keys::N;
		else if (theStr == "M")		return System::Windows::Forms::Keys::M;
		else if (theStr == "F1")	return System::Windows::Forms::Keys::F1;
		else if (theStr == "F2")	return System::Windows::Forms::Keys::F2;
		else if (theStr == "F3")	return System::Windows::Forms::Keys::F3;
		else if (theStr == "F4")	return System::Windows::Forms::Keys::F4;
		else if (theStr == "F5")	return System::Windows::Forms::Keys::F5;
		else if (theStr == "F6")	return System::Windows::Forms::Keys::F6;
		else if (theStr == "F7")	return System::Windows::Forms::Keys::F7;
		else if (theStr == "F8")	return System::Windows::Forms::Keys::F8;
		else if (theStr == "F9")	return System::Windows::Forms::Keys::F9;
		else if (theStr == "F10")	return System::Windows::Forms::Keys::F10;
		else if (theStr == "F11")	return System::Windows::Forms::Keys::F11;
		else if (theStr == "F12")	return System::Windows::Forms::Keys::F12;
		return System::Windows::Forms::Keys::None;
		}
	int getValue(String^ theStr){
		if (theStr == "~")			return MSS;
		else if (theStr == "1")		return M1;
		else if (theStr == "2")		return M2;
		else if (theStr == "3")		return M3;
		else if (theStr == "4")		return M4;
		else if (theStr == "5")		return M5;
		else if (theStr == "6")		return M6;
		else if (theStr == "7")		return M7;
		else if (theStr == "8")		return M8;
		else if (theStr == "9")		return M9;
		else if (theStr == "0")		return M0;
		else if (theStr == "-")		return MDD;
		else if (theStr == "=")		return MEE;
		else if (theStr == "<-")	return MBA;
		else if (theStr == "Tab")	return MTAB;
		else if (theStr == "Q")		return MQ;
		else if (theStr == "W")		return MW;
		else if (theStr == "E")		return ME;
		else if (theStr == "R")		return MR;
		else if (theStr == "T")		return MT;
		else if (theStr == "Y")		return MY;
		else if (theStr == "U")		return MU;
		else if (theStr == "I")		return MI;
		else if (theStr == "O")		return MO;
		else if (theStr == "P")		return MP;
		else if (theStr == "[")		return Mlq;
		else if (theStr == "]")		return Mrq;
		else if (theStr == "|")		return MOR;
		else if (theStr == "CapsLock")		return MCap;
		else if (theStr == "A")		return MA;
		else if (theStr == "S")		return MS;
		else if (theStr == "D")		return MD;
		else if (theStr == "F")		return MF;
		else if (theStr == "G")		return MG;
		else if (theStr == "H")		return MH;
		else if (theStr == "J")		return MJ;
		else if (theStr == "K")		return MK;
		else if (theStr == "L")		return ML;
		else if (theStr == ";")		return MCC;
		else if (theStr == "'")		return MQQ;
		else if (theStr == "Enter")	return MEN;
		else if (theStr == "Shift1")return MLSh;
		else if (theStr == "Z")		return MZ;
		else if (theStr == "X")		return MX;
		else if (theStr == "C")		return MC;
		else if (theStr == "V")		return MV;
		else if (theStr == "B")		return MB;
		else if (theStr == "N")		return MN;
		else if (theStr == "M")		return MM;
		else if (theStr == ",")		return MCO;
		else if (theStr == ".")		return MDO;
		else if (theStr == "/")		return MSL;
		else if (theStr == "Shift2")return MRSh;
		else if (theStr == "Ctrl1")	return MLCt;
		else if (theStr == "win1")	return MLWn;
		else if (theStr == "Alt1")	return MLAl;
		else if (theStr == "space")	return MSP;
		else if (theStr == "Alt2")	return MRAl;
		else if (theStr == "win2")	return MRWn;
		else if (theStr == "�L��")	return 0x00;
		else if (theStr == "Ctrl2")	return MRCt;
		else if (theStr == "Esc")	return MESC;
		else if (theStr == "F1")	return MF1;
		else if (theStr == "F2")	return MF2;
		else if (theStr == "F3")	return MF3;
		else if (theStr == "F4")	return MF4;
		else if (theStr == "F5")	return MF5;
		else if (theStr == "F6")	return MF6;
		else if (theStr == "F7")	return MF7;
		else if (theStr == "F8")	return MF8;
		else if (theStr == "F9")	return MF9;
		else if (theStr == "F10")	return MF10;
		else if (theStr == "F11")	return MF11;
		else if (theStr == "F12")	return MF12;
		else if (theStr == "Print Screen")	return MPri;
		else if (theStr == "Scroll Lock")	return MScr;
		else if (theStr == "Pause")		return MPau;
		else if (theStr == "Insert")	return MIN;
		else if (theStr == "Home")		return MHO;
		else if (theStr == "Page  Up")	return MPUP;
		else if (theStr == "Delete")	return MDE;
		else if (theStr == "End")		return MEND;
		else if (theStr == "Page Down")	return MPDN;
		else if (theStr == "up")		return MUP;
		else if (theStr == "left")		return MLE;
		else if (theStr == "down")		return MDN;
		else if (theStr == "right")		return MRI;
		return 0x00;
	}
	private: System::Void button_Reset_Click(System::Object^  sender, System::EventArgs^  e) {
		for (count=count-1; count >= 0; count--){
			btnAry[count]->Text = strAry[count];
			btnAry[count] = nullptr;
			strAry[count] = nullptr;
		}
		count = 0;
		useChange->reset();
		MessageBox::Show("���\�M��", "����", MessageBoxButtons::OK, MessageBoxIcon::Information);
		button_Check->Enabled = false;
	}
	private: System::Void MyForm_Load(System::Object^  sender, System::EventArgs^  e) {
		useChange = gcnew CChangKey();
		count = 0;
		btnAry = gcnew array<Button^>(86);
		strAry = gcnew array<String^>(86);
		Note^ temp = gcnew Note();
		temp->ShowDialog();
		delete temp;
	}
	private: System::Void button_del_Click(System::Object^  sender, System::EventArgs^  e) {
		try{
			useChange->del();
		}
		catch (Exception^ e){
			MessageBox::Show("�w�O��t�]�w\n�Φ��{���|���֦��ϥΪ��v��", "����", MessageBoxButtons::OK, MessageBoxIcon::Error);
			return Void();
		}
		MessageBox::Show("���\�^�_", "����", MessageBoxButtons::OK, MessageBoxIcon::Information);
	}
	private: System::Void button_ChOk_Click(System::Object^  sender, System::EventArgs^  e) {
		if (comboBox1->Text == "" || usebutton == nullptr){
			MessageBox::Show("�п�ܫ���ξܿ�Q�ܦ�������", "����", MessageBoxButtons::OK, MessageBoxIcon::Warning);
			return Void();
		}
		btnAry[count] = usebutton;
		strAry[count++] = usebutton->Text;
		usebutton->Text = comboBox1->Text;
		int temp = getValue(comboBox1->Text);
		useChange->chKeys(keyValue, temp);
		MessageBox::Show("�s�W���\", "����", MessageBoxButtons::OK, MessageBoxIcon::Information);
		button_Check->Enabled = true;
	}
	private: System::Void button_Check_Click(System::Object^  sender, System::EventArgs^  e) {
		try{
			useChange->check();
		}
		catch (Exception^ e){
			MessageBox::Show("���{���|���֦��ϥΪ��v��", "����", MessageBoxButtons::OK, MessageBoxIcon::Error);
			return Void();
		}
		MessageBox::Show("�g�J���\", "����", MessageBoxButtons::OK, MessageBoxIcon::Information);
		usebutton->BackColor = System::Drawing::Color::Plum;
		usebutton = nullptr;
	}
	private: System::Void button88_Click(System::Object^  sender, System::EventArgs^  e) {
		if (hotkey == 1){
			Hotkey_ShotDown->UnregisterHotkeys();
			Hotkey_PrintFull->UnregisterHotkeys();
			Hotkey_LogOut->UnregisterHotkeys();
			Hotkey_Sleep->UnregisterHotkeys();
			Hotkey_Restart->UnregisterHotkeys();

			Hotkey_User1->UnregisterHotkeys();
			Hotkey_User2->UnregisterHotkeys();
			Hotkey_User3->UnregisterHotkeys();
			Hotkey_User4->UnregisterHotkeys();
			button88->Text = "�ҥμ���";
			hotkey = 0;
			button89->Enabled = true;

			MessageBox::Show("���Υ������");
		}
		else{
			msg = "";
			if (tempComboKey1 != "")
				msg += tempHotkey + "+" + tempComboKey1 + "\n";
			if (tempComboKey2 != "")
				msg += tempHotkey + "+" + tempComboKey2 + "\n";
			if (tempComboKey3 != "")
				msg += tempHotkey + "+" + tempComboKey3 + "\n";
			if (tempComboKey4 != "")
				msg += tempHotkey + "+" +tempComboKey4 + "\n";
			if (msg != ""){
				msg = "�ۭqComboKey:\n\n" + msg;
			}
			

			MessageBox::Show("���إ������:                                              \n\nCtrl+F1:�ù��I��\nCtrl+F2:����\nCtrl+F3:�n�X\nCtrl+F4:��v\nCtrl+F5:���s�}��\n\n" + msg);

			//===============================================================================
			Hotkey_PrintFull = gcnew CHotkey(this->Handle);
			CHotkey::Hotkey1 = Hotkey_PrintFull->RegisterHotkey(System::Windows::Forms::Keys::F1, CHotkey::KeyFlags::MODCONTROL);
			Hotkey_PrintFull->OnHotkey += gcnew HotkeyEventHandler(printfull);
			//===============================================================================
			Hotkey_ShotDown = gcnew CHotkey(this->Handle);
			CHotkey::Hotkey1 = Hotkey_ShotDown->RegisterHotkey(System::Windows::Forms::Keys::F2, CHotkey::KeyFlags::MODCONTROL);
			Hotkey_ShotDown->OnHotkey += gcnew HotkeyEventHandler(shutdown);
			//===============================================================================
			Hotkey_LogOut = gcnew CHotkey(this->Handle);
			CHotkey::Hotkey1 = Hotkey_LogOut->RegisterHotkey(System::Windows::Forms::Keys::F3, CHotkey::KeyFlags::MODCONTROL);
			Hotkey_LogOut->OnHotkey += gcnew HotkeyEventHandler(logout);
			//===============================================================================
			Hotkey_Sleep = gcnew CHotkey(this->Handle);
			CHotkey::Hotkey1 = Hotkey_Sleep->RegisterHotkey(System::Windows::Forms::Keys::F4, CHotkey::KeyFlags::MODCONTROL);
			Hotkey_Sleep->OnHotkey += gcnew HotkeyEventHandler(sleep);
			//===============================================================================
			Hotkey_Restart = gcnew CHotkey(this->Handle);
			CHotkey::Hotkey1 = Hotkey_Restart->RegisterHotkey(System::Windows::Forms::Keys::F5, CHotkey::KeyFlags::MODCONTROL);
			Hotkey_Restart->OnHotkey += gcnew HotkeyEventHandler(restart);
			//===============================================================================
			Hotkey_User1 = gcnew CHotkey(this->Handle);
			if (HotkeyPath1 != "")
				CHotkey::Hotkey1 = Hotkey_User1->RegisterHotkey(combokey1, hotkeyflags);
			Hotkey_User1->OnHotkey += gcnew HotkeyEventHandler(user1);
			//===============================================================================
			Hotkey_User2 = gcnew CHotkey(this->Handle);
			if (HotkeyPath1 != "")
				CHotkey::Hotkey1 = Hotkey_User2->RegisterHotkey(combokey2, hotkeyflags);
			Hotkey_User2->OnHotkey += gcnew HotkeyEventHandler(user2);
			//===============================================================================
			Hotkey_User3 = gcnew CHotkey(this->Handle);
			if (HotkeyPath1 != "")
				CHotkey::Hotkey1 = Hotkey_User3->RegisterHotkey(combokey3, hotkeyflags);
			Hotkey_User3->OnHotkey += gcnew HotkeyEventHandler(user3);
			//===============================================================================
			Hotkey_User4 = gcnew CHotkey(this->Handle);
			if (HotkeyPath1 != "")
				CHotkey::Hotkey1 = Hotkey_User4->RegisterHotkey(combokey4, hotkeyflags);
			Hotkey_User4->OnHotkey += gcnew HotkeyEventHandler(user4);
			//===============================================================================

			hotkey = 1;
			button88->Text = "���μ���";
			button89->Enabled = false;
		}
	}
	private: System::Void button89_Click(System::Object^  sender, System::EventArgs^  e) {
		HotkeyChange^ fm = gcnew HotkeyChange();

		fm->comboBox1->Text = tempHotkey;

		fm->comboBox2->Text = tempComboKey1;
		fm->comboBox3->Text = tempComboKey2;
		fm->comboBox4->Text = tempComboKey3;
		fm->comboBox5->Text = tempComboKey4;

		fm->textBox1->Text = HotkeyPath1;
		fm->textBox2->Text = HotkeyPath2;
		fm->textBox3->Text = HotkeyPath3;
		fm->textBox4->Text = HotkeyPath4;

		fm->Location = Point(this->Location.X + 450, this->Location.Y + 60);
		fm->ShowDialog();
		
		if (fm->textBox1->Text != "" && fm->comboBox2->Text != "" & fm->comboBox1->Text != ""){
			HotkeyPath1 = fm->textBox1->Text;
			tempComboKey1 = fm->comboBox2->Text;
			combokey1 = getKey(fm->comboBox2->Text);
		}
		else{
			HotkeyPath1 = "";
			tempComboKey1 = "";
			combokey1 = System::Windows::Forms::Keys::None;
		}

		if (fm->textBox2->Text != "" && fm->comboBox3->Text != "" & fm->comboBox1->Text != ""){
			HotkeyPath2 = fm->textBox2->Text;
			tempComboKey2 = fm->comboBox3->Text;
			combokey2 = getKey(fm->comboBox3->Text);
		}
		else{
			HotkeyPath2 = "";
			tempComboKey2 = "";
			combokey2 = System::Windows::Forms::Keys::None;
		}


		if (fm->textBox3->Text != "" && fm->comboBox4->Text != "" & fm->comboBox1->Text != ""){
			HotkeyPath3 = fm->textBox3->Text;
			tempComboKey3 = fm->comboBox4->Text;
			combokey3 = getKey(fm->comboBox4->Text);
		}
		else{
			HotkeyPath3 = "";
			tempComboKey3 = "";
			combokey3 = System::Windows::Forms::Keys::None;
		}

		if (fm->textBox4->Text != "" && fm->comboBox5->Text != "" & fm->comboBox1->Text != ""){
			HotkeyPath4 = fm->textBox4->Text;
			tempComboKey4 = fm->comboBox5->Text;
			combokey4 = getKey(fm->comboBox5->Text);
		}
		else{
			HotkeyPath4 = "";
			tempComboKey4 = "";
			combokey4 = System::Windows::Forms::Keys::None;
		}
		tempHotkey = fm->comboBox1->Text;
		hotkeyflags = getHotkey(fm->comboBox1->Text);

	}
};
}
