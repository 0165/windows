#include "MyForm.h" 

using namespace FinalProject;
[STAThread]
int main(){

	MyForm fm;

	fm.ShowDialog();

	return 0;

}
