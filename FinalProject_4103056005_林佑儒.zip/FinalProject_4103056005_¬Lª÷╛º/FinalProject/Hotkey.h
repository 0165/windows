﻿#include "MyForm.h" 
#pragma once
using namespace System;
using namespace System::Collections::Generic;
using namespace System::ComponentModel;
using namespace System::Data;
using namespace System::Drawing;
using namespace System::Text;
//using namespace System::Windows::Forms;
using namespace System::Runtime::InteropServices;
using namespace System::Collections;

namespace FinalProject
{
	
	delegate void HotkeyEventHandler(int HotKeyID);

	ref class CHotkey : public System::Windows::Forms::IMessageFilter
	{
		Hashtable^ keyIDs = gcnew Hashtable();
		IntPtr hWnd;

	public:
		[DllImport("user32.dll")]
		static UInt32 RegisterHotKey(IntPtr hWnd, UInt32 id, UInt32 fsModifiers, UInt32 vk);

		[DllImport("user32.dll")]
		static UInt32 UnregisterHotKey(IntPtr hWnd, UInt32 id);

		[DllImport("kernel32.dll")]
		static UInt32 GlobalAddAtom(String ^lpString);

		[DllImport("kernel32.dll")]
		static UInt32 GlobalDeleteAtom(UInt32 nAtom);

		static int Hotkey1;

		HotkeyEventHandler^ OnHotkey;
		
		enum class KeyFlags
		{
			MODALT = 0x1,
			MODCONTROL = 0x2,
			MODSHIFT = 0x4,
			MODWIN = 0x8
		};
		
		CHotkey(IntPtr hWnd)
		{
			this->hWnd = hWnd;
			Application::AddMessageFilter(this);
		}

		int RegisterHotkey(Keys Key, KeyFlags keyflags)
		{
			UInt32 hotkeyid = GlobalAddAtom(System::Guid::NewGuid().ToString());
			RegisterHotKey((IntPtr)hWnd, hotkeyid, (UInt32)keyflags, (UInt32)Key);
			keyIDs->Add(hotkeyid, hotkeyid);
			return (int)hotkeyid;
		}

		void UnregisterHotkeys()
		{
			Application::RemoveMessageFilter(this);
			for each(UInt32 key in keyIDs->Values)
			{
				UnregisterHotKey(hWnd, key);
				GlobalDeleteAtom(key);
			}
		}

		virtual bool PreFilterMessage(Message % m)
		{
			if (m.Msg == 0x312)
			{
				if (OnHotkey != nullptr)
				{
					for each(UInt32 key in keyIDs->Values)
					{
						if ((int)m.WParam == key)
						{
							OnHotkey((int)m.WParam);
							return true;
						}
					}
				}
			}
			return false;
		}
		
	};
}