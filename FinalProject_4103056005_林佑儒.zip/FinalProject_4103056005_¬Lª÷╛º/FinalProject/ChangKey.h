#pragma once // �O�Ҥޥ��� (*.h) �u�|�Q�ޥΤ@���A�p���N���ݭn�Ρu�ޤJ���@�v�F�C
using namespace System;
using namespace System::Security::Permissions;
using namespace Microsoft::Win32;
//===============================================================================
ref class CChangKey{
public:
	String^ start;
	String^ chang;
	String^ endSt;
	int^ 	count;
//===============================================================================
public:
	CChangKey(void);
	~CChangKey(void);
	bool chKeys(int,int);
	bool check();
	bool reset();
	bool get();
	bool del();
//===============================================================================
};