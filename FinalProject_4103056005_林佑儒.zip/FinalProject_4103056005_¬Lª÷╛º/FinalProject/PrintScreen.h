#pragma once // �O�Ҥޥ��� (*.h) �u�|�Q�ޥΤ@���A�p���N���ݭn�Ρu�ޤJ���@�v�F�C

using namespace System;
using namespace System::ComponentModel;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;
using namespace System::Collections::Generic;
using namespace System::Text;//print screen needed
//===============================================================================
ref class CPrintScreen{
//===============================================================================
public:
	static void FullScreen(int);
	static void WinFormScreen(Form^);
//===============================================================================
};