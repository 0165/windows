#include "ChangKey.h"
//===============================================================================
CChangKey::CChangKey(void){
	start=gcnew String("0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,");
	endSt=gcnew String(",0x00,0x00,0x00,0x00");
	chang=gcnew String("");
	count=gcnew int(1);
}
//===============================================================================
CChangKey::~CChangKey(void){
	delete start;
	delete endSt;
	delete chang;
	delete count;
}
//===============================================================================
bool CChangKey::chKeys(int target,int hope){
	String^ a=Convert::ToString(hope, 16);
	if(a->Length==1)
		a="0"+a;
	chang=chang+",0x"+a+",0x00,";
	a=Convert::ToString(target, 16);
	if (a->Length == 1)
		a = "0x0" + a;
	else
		a = "0x" + a;
	chang=chang+a+",0x00";
	(*count)++;
	delete a;
	return true;
}
//===============================================================================
bool CChangKey::check(){
	String^ a=Convert::ToString(*count, 16);
	if (a->Length == 1)
		a = "0x0" + a;
	else
		a = "0x" + a;
	a=start+a+",0x00,0x00,0x00"+chang+endSt;
	array<String^>^ words;
	words = a->Split(',');
	array<Byte>^ mydata=gcnew array<Byte>(words->Length);
	for (int i = 0; i < words->Length; i++)
		mydata[i] = Convert::ToByte(words[i],16);
	String^ name =gcnew String("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Keyboard Layout");
	Registry::SetValue(name, "Scancode Map", mydata, RegistryValueKind::Binary);
	delete name;
	delete a;
	return true;
}
//===============================================================================
bool CChangKey::reset(){
	*count=1;
	chang="";
	return true;
}
//===============================================================================
bool CChangKey::del(){
	RegistryKey ^aaa = Registry::LocalMachine->OpenSubKey("SYSTEM\\CurrentControlSet\\Control\\Keyboard Layout",true);
	aaa->DeleteValue("Scancode Map",true);
	aaa->Close();
	delete aaa;
	return true;
}
//===============================================================================
bool CChangKey::get(){
	array<Byte>^ mydata = (array<Byte>^)Registry::GetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Keyboard Layout", "Scancode Map", nullptr);
	return true;
}
//===============================================================================