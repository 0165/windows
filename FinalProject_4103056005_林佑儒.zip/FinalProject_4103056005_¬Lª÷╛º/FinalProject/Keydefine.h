# define MESC 0X01//ESC
# define MF1  0X3B//F1
# define MF2  0X3C//F2
# define MF3  0X3D//F3
# define MF4  0X3E//F4
# define MF5  0X3F//F5
# define MF6  0X40//F6
# define MF7  0X41//F7
# define MF8  0X42//F8
# define MF9  0X43//F9
# define MF10 0X44//F10
# define MSS  0X29//~
# define M1   0X02//1
# define M2   0X03//2
# define M3   0X04//3
# define M4   0X05//4
# define M5   0X06//5
# define M6   0X07//6
# define M7   0X08//7
# define M8   0X09//8
# define M9   0X0A//9
# define M0   0X0B//0
# define MDD  0X0C//-
# define MEE  0X0D//= 
# define MOR  0X2B//| 
# define MBA  0X0E//backspace 
# define MTAB 0X0F//TAB 
# define MQ   0X10//q 
# define MW   0X11//w
# define ME   0X12//e
# define MR   0X13//r
# define MT   0X14//t
# define MY   0X15//y
# define MU   0X16//u
# define MI   0X17//i
# define MO   0X18//o
# define MP   0X19//p
# define Mlq  0X1A//{ 
# define Mrq  0X1B//} 
# define MA   0X1E//a 
# define MS   0X1F//s
# define MD   0X20//d 
# define MF   0X21//f
# define MG   0X22//g
# define MH   0X23//h
# define MJ   0X24//j
# define MK   0X25//k
# define ML   0X26//l
# define MCC  0X27//;
# define MQQ  0X28//" 
# define MEN  0X1C//enter 
# define MZ   0X2C//z
# define MX   0X2D//x
# define MC   0X2E//c
# define MV   0X2F//v
# define MB   0X30//b
# define MN   0X31//n
# define MM   0X32//m
# define MCO  0X33//, 
# define MDO  0X34//. 
# define MSL  0X35// / 
# define MSP  0X39//space
# define MIN  0X52//insert 
# define MHO  0X47//home
# define MPUP 0X49//page up 
# define MDE  0X53//delete 
# define MEND 0X4F//end
# define MPDN 0X51//page down
# define MUP  0X48//up 
# define MLE  0X4B//left 
# define MDN  0X50//down 
# define MRI  0X4D//right
# define MCap 0X3A//CapsLock
# define MLSh 0X2A//Left Shift
# define MLCt 0X1D//Left Ctrl
# define MLAl 0X38//Left Alt
# define MPri 0X37//PrtSc
# define MRAl 0X38//Right Alt
# define MRCt 0X1D//Right Ctrl
# define MRSh 0X36//Right Shift
# define MScr 0X46//Scroll Lock
# define MLWn 0X5B//left win
# define MF11 0X57//F11
# define MF12 0X58//F12
# define MPau 0X22//pause
# define MRWn 0X5C//Right win