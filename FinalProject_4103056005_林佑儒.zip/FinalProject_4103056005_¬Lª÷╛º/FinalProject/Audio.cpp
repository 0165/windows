#include "Audio.h"
//===============================================================================
CAudio::CAudio(void){
	PPCOMMAND_VOLUME_MUTE = gcnew int(0x80000);
	PPCOMMAND_VOLUME_UP = gcnew int(0x0a0000);
	PPCOMMAND_VOLUME_DOWN = gcnew int(0x090000);
	M_APPCOMMAND = gcnew int(0x319);
}
//===============================================================================
	
void CAudio::AudioUp(Form^ form){//AudioUp
	SendMessageW(form->Handle, *M_APPCOMMAND, form->Handle, (IntPtr)*PPCOMMAND_VOLUME_UP);
}

void CAudio::AudioDown(Form^ form){//AudioDown
	SendMessageW(form->Handle, *M_APPCOMMAND, form->Handle, (IntPtr)*PPCOMMAND_VOLUME_DOWN);
}

void CAudio::AudioQuite(Form^ form){//AudioQuite
	SendMessageW(form->Handle, *M_APPCOMMAND, form->Handle, (IntPtr)*PPCOMMAND_VOLUME_MUTE);
}
