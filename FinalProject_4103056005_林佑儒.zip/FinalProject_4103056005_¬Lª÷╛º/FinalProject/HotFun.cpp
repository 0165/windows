#include "HotFun.h"
void CHotFun::ShotDown(){
	System::Diagnostics::Process::Start("C:\\WINDOWS\\system32\\shutdown.exe", "-f -s -t 0");
}
void CHotFun::Restart(){
	System::Diagnostics::Process::Start("C:\\WINDOWS\\system32\\shutdown.exe", "-f -r -t 0");
}
void CHotFun::LogOut(){
	System::Diagnostics::Process::Start("C:\\WINDOWS\\system32\\shutdown.exe", "-l");
}
void CHotFun::Sleep(){
	System::Diagnostics::Process::Start("C:\\WINDOWS\\system32\\mspaint.exe", "powrprof.dll,SetSuspendState");
}
void CHotFun::User1(String^ path){
	System::Diagnostics::Process::Start(path);
}
void CHotFun::User2(String^ path){
	System::Diagnostics::Process::Start(path);
}
void CHotFun::User3(String^ path){
	System::Diagnostics::Process::Start(path);
}
void CHotFun::User4(String^ path){
	System::Diagnostics::Process::Start(path);
}