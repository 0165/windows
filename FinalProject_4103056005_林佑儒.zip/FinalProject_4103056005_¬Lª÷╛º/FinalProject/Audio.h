#pragma once // �O�Ҥޥ��� (*.h) �u�|�Q�ޥΤ@���A�p���N���ݭn�Ρu�ޤJ���@�v�F�C

using namespace System;
using namespace System::ComponentModel;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;
using namespace System::Runtime::InteropServices;
using namespace System::Collections::Generic;
using namespace System::Text;//print screen needed
//===============================================================================
ref class CAudio{
public:
	static int^ PPCOMMAND_VOLUME_MUTE;
	static int^ PPCOMMAND_VOLUME_UP;
	static int^ PPCOMMAND_VOLUME_DOWN;
	static int^ M_APPCOMMAND;
//===============================================================================
	[DllImport("user32.dll")]
	static IntPtr SendMessageW(IntPtr hWnd, int Msg, IntPtr wParam, IntPtr lParam);
//===============================================================================
public:
	CAudio(void);
//===============================================================================
public:
	static void AudioUp(Form^);
	static void AudioDown(Form^);
	static void AudioQuite(Form^);
//===============================================================================
};