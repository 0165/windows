#include "PrintScreen.h"
//===============================================================================
void CPrintScreen::WinFormScreen(Form^ form){
	Bitmap^ FormImage = gcnew Bitmap(form->Width, form->Height);
	Graphics^ graphics = Graphics::FromImage(FormImage);
	graphics->CopyFromScreen(form->Location.X, form->Location.Y, 0, 0, System::Drawing::Size(form->Width, form->Height));

	FormImage->Save("FormScreenShot.jpg", System::Drawing::Imaging::ImageFormat::Jpeg);
	delete graphics, FormImage;
}
//===============================================================================
void CPrintScreen::FullScreen(int cc){
	System::Drawing::Rectangle workingRectangle = Screen::PrimaryScreen->Bounds;
	Bitmap^ Image = gcnew Bitmap(workingRectangle.Width, workingRectangle.Height);
	Graphics^ graphics = Graphics::FromImage(Image);
	graphics->CopyFromScreen(0, 0, 0, 0, System::Drawing::Size(workingRectangle.Width, workingRectangle.Height));

	Image->Save("FullScreen"+cc+".jpg", System::Drawing::Imaging::ImageFormat::Jpeg);
	delete graphics, Image;
}