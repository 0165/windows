#pragma once

namespace FinalProject {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Security::Permissions;

	/// <summary>
	/// HotkeyChange ���K�n
	/// </summary>
	public ref class HotkeyChange : public System::Windows::Forms::Form
	{
	public:
		HotkeyChange(void)
		{
			InitializeComponent();
			//
			//TODO:  �b���[�J�غc�禡�{���X
			//
		}
		
	protected:
		/// <summary>
		/// �M������ϥΤ����귽�C
		/// </summary>
		~HotkeyChange()
		{
			if (components)
			{
				delete components;
			}
		}
	public: System::Windows::Forms::ComboBox^  comboBox1;
	private: System::Windows::Forms::Label^  label1;
	public: System::Windows::Forms::TextBox^  textBox1;
	public: System::Windows::Forms::TextBox^  textBox2;
	public: System::Windows::Forms::TextBox^  textBox3;
	private: System::Windows::Forms::Button^  button1;
	public: System::Windows::Forms::TextBox^  textBox4;
	public: System::Windows::Forms::ComboBox^  comboBox2;
	public: System::Windows::Forms::ComboBox^  comboBox3;
	public: System::Windows::Forms::ComboBox^  comboBox4;
	public: System::Windows::Forms::ComboBox^  comboBox5;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::OpenFileDialog^  openFileDialog1;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::Button^  button4;
	private: System::Windows::Forms::Button^  button5;


	private:
		/// <summary>
		/// �]�p�u��һݪ��ܼơC
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// �����]�p�u��䴩�һݪ���k - �ФŨϥε{���X�s�边
		/// �ק�o�Ӥ�k�����e�C
		/// </summary>
		void InitializeComponent(void)
		{
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->textBox3 = (gcnew System::Windows::Forms::TextBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->textBox4 = (gcnew System::Windows::Forms::TextBox());
			this->comboBox2 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox3 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox4 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox5 = (gcnew System::Windows::Forms::ComboBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->openFileDialog1 = (gcnew System::Windows::Forms::OpenFileDialog());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// comboBox1
			// 
			this->comboBox1->BackColor = System::Drawing::Color::Plum;
			this->comboBox1->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Items->AddRange(gcnew cli::array< System::Object^  >(3) { L"Alt", L"Ctrl", L"Shift" });
			this->comboBox1->Location = System::Drawing::Point(144, 22);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(121, 23);
			this->comboBox1->TabIndex = 0;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"�s�ө���", 12));
			this->label1->Location = System::Drawing::Point(23, 25);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(114, 20);
			this->label1->TabIndex = 1;
			this->label1->Text = L"��ܲզX��:";
			// 
			// textBox1
			// 
			this->textBox1->BackColor = System::Drawing::Color::Plum;
			this->textBox1->Location = System::Drawing::Point(152, 90);
			this->textBox1->Name = L"textBox1";
			this->textBox1->ReadOnly = true;
			this->textBox1->Size = System::Drawing::Size(193, 25);
			this->textBox1->TabIndex = 2;
			// 
			// textBox2
			// 
			this->textBox2->BackColor = System::Drawing::Color::Plum;
			this->textBox2->Location = System::Drawing::Point(152, 121);
			this->textBox2->Name = L"textBox2";
			this->textBox2->ReadOnly = true;
			this->textBox2->Size = System::Drawing::Size(193, 25);
			this->textBox2->TabIndex = 3;
			// 
			// textBox3
			// 
			this->textBox3->BackColor = System::Drawing::Color::Plum;
			this->textBox3->Location = System::Drawing::Point(152, 153);
			this->textBox3->Name = L"textBox3";
			this->textBox3->ReadOnly = true;
			this->textBox3->Size = System::Drawing::Size(193, 25);
			this->textBox3->TabIndex = 4;
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(162, 225);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(88, 34);
			this->button1->TabIndex = 5;
			this->button1->Text = L"�T�w";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &HotkeyChange::button1_Click);
			// 
			// textBox4
			// 
			this->textBox4->BackColor = System::Drawing::Color::Plum;
			this->textBox4->Location = System::Drawing::Point(152, 184);
			this->textBox4->Name = L"textBox4";
			this->textBox4->ReadOnly = true;
			this->textBox4->Size = System::Drawing::Size(193, 25);
			this->textBox4->TabIndex = 6;
			// 
			// comboBox2
			// 
			this->comboBox2->BackColor = System::Drawing::Color::Plum;
			this->comboBox2->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox2->FormattingEnabled = true;
			this->comboBox2->Items->AddRange(gcnew cli::array< System::Object^  >(36) {
				L"1", L"2", L"3", L"4", L"5", L"6", L"7", L"8",
					L"9", L"0", L"Q", L"W", L"E", L"R", L"T", L"Y", L"U", L"I", L"O", L"P", L"A", L"S", L"D", L"F", L"G", L"H", L"J", L"K", L"L",
					L"Z", L"X", L"C", L"V", L"B", L"N", L"M"
			});
			this->comboBox2->Location = System::Drawing::Point(31, 90);
			this->comboBox2->Name = L"comboBox2";
			this->comboBox2->Size = System::Drawing::Size(106, 23);
			this->comboBox2->TabIndex = 7;
			// 
			// comboBox3
			// 
			this->comboBox3->BackColor = System::Drawing::Color::Plum;
			this->comboBox3->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox3->FormattingEnabled = true;
			this->comboBox3->Items->AddRange(gcnew cli::array< System::Object^  >(36) {
				L"0", L"1", L"2", L"3", L"4", L"5", L"6", L"7",
					L"8", L"9", L"A", L"B", L"C", L"D", L"E", L"F", L"G", L"H", L"I", L"J", L"K", L"L", L"M", L"N", L"O", L"P", L"Q", L"R", L"S",
					L"T", L"U", L"V", L"W", L"X", L"Y", L"Z"
			});
			this->comboBox3->Location = System::Drawing::Point(31, 121);
			this->comboBox3->Name = L"comboBox3";
			this->comboBox3->Size = System::Drawing::Size(106, 23);
			this->comboBox3->Sorted = true;
			this->comboBox3->TabIndex = 8;
			// 
			// comboBox4
			// 
			this->comboBox4->BackColor = System::Drawing::Color::Plum;
			this->comboBox4->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox4->FormattingEnabled = true;
			this->comboBox4->Items->AddRange(gcnew cli::array< System::Object^  >(36) {
				L"0", L"1", L"2", L"3", L"4", L"5", L"6", L"7",
					L"8", L"9", L"A", L"B", L"C", L"D", L"E", L"F", L"G", L"H", L"I", L"J", L"K", L"L", L"M", L"N", L"O", L"P", L"Q", L"R", L"S",
					L"T", L"U", L"V", L"W", L"X", L"Y", L"Z"
			});
			this->comboBox4->Location = System::Drawing::Point(31, 153);
			this->comboBox4->Name = L"comboBox4";
			this->comboBox4->Size = System::Drawing::Size(106, 23);
			this->comboBox4->Sorted = true;
			this->comboBox4->TabIndex = 9;
			// 
			// comboBox5
			// 
			this->comboBox5->BackColor = System::Drawing::Color::Plum;
			this->comboBox5->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox5->FormattingEnabled = true;
			this->comboBox5->Items->AddRange(gcnew cli::array< System::Object^  >(36) {
				L"0", L"1", L"2", L"3", L"4", L"5", L"6", L"7",
					L"8", L"9", L"A", L"B", L"C", L"D", L"E", L"F", L"G", L"H", L"I", L"J", L"K", L"L", L"M", L"N", L"O", L"P", L"Q", L"R", L"S",
					L"T", L"U", L"V", L"W", L"X", L"Y", L"Z"
			});
			this->comboBox5->Location = System::Drawing::Point(31, 184);
			this->comboBox5->Name = L"comboBox5";
			this->comboBox5->Size = System::Drawing::Size(106, 23);
			this->comboBox5->Sorted = true;
			this->comboBox5->TabIndex = 10;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(72, 62);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(37, 15);
			this->label2->TabIndex = 11;
			this->label2->Text = L"����";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(210, 62);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(67, 15);
			this->label3->TabIndex = 12;
			this->label3->Text = L"�ۭq���|";
			// 
			// openFileDialog1
			// 
			this->openFileDialog1->Title = L"��ܶ}�����ε{��";
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(351, 90);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(32, 27);
			this->button2->TabIndex = 13;
			this->button2->Text = L"...";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &HotkeyChange::button2_Click);
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(350, 121);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(33, 26);
			this->button3->TabIndex = 14;
			this->button3->Text = L"...";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &HotkeyChange::button3_Click);
			// 
			// button4
			// 
			this->button4->Location = System::Drawing::Point(351, 153);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(33, 25);
			this->button4->TabIndex = 15;
			this->button4->Text = L"...";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &HotkeyChange::button4_Click);
			// 
			// button5
			// 
			this->button5->Location = System::Drawing::Point(351, 183);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(32, 26);
			this->button5->TabIndex = 16;
			this->button5->Text = L"...";
			this->button5->UseVisualStyleBackColor = true;
			this->button5->Click += gcnew System::EventHandler(this, &HotkeyChange::button5_Click);
			// 
			// HotkeyChange
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 15);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::Plum;
			this->ClientSize = System::Drawing::Size(434, 303);
			this->ControlBox = false;
			this->Controls->Add(this->button5);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->comboBox5);
			this->Controls->Add(this->comboBox4);
			this->Controls->Add(this->comboBox3);
			this->Controls->Add(this->comboBox2);
			this->Controls->Add(this->textBox4);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->textBox3);
			this->Controls->Add(this->textBox2);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->comboBox1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
			this->MaximizeBox = false;
			this->MinimizeBox = false;
			this->Name = L"HotkeyChange";
			this->StartPosition = System::Windows::Forms::FormStartPosition::Manual;
			this->Text = L"����]�m";
			this->Load += gcnew System::EventHandler(this, &HotkeyChange::HotkeyChange_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}

#pragma endregion
	private: System::Void HotkeyChange_Load(System::Object^  sender, System::EventArgs^  e) {

	}
			 
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {

		this->Close();
	}
	private: System::Void openFileDialog1_FileOk(System::Object^  sender, System::ComponentModel::CancelEventArgs^  e) {
	}
	private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
		if (openFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK)
		{
			openFileDialog1->OpenFile();
		}
		textBox1->Text = openFileDialog1->FileName;
		openFileDialog1->FileName = "";
	}
	private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) {
		if (openFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK)
		{
			openFileDialog1->OpenFile();
		}
		textBox2->Text = openFileDialog1->FileName;
		openFileDialog1->FileName = "";
	}
	private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e) {
		if (openFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK)
		{
			openFileDialog1->OpenFile();
		}
		textBox3->Text = openFileDialog1->FileName;
		openFileDialog1->FileName = "";

	}
	private: System::Void button5_Click(System::Object^  sender, System::EventArgs^  e) {
		if (openFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK)
		{
			openFileDialog1->OpenFile();
		}
		textBox4->Text = openFileDialog1->FileName;
		openFileDialog1->FileName = "";
	}
};
}
