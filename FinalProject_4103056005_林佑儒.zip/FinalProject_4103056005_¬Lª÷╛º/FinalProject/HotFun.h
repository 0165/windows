#pragma once
using namespace System;
//===============================================================================
ref class CHotFun{
	//===============================================================================
public:
	static void ShotDown();
	static void Restart();
	static void LogOut();
	static void Sleep();
	static void User1(String^);
	static void User2(String^);
	static void User3(String^);
	static void User4(String^);
	//===============================================================================
};